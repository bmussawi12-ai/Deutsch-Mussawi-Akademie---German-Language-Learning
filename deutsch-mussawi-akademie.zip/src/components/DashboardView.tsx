import React, { useState, useMemo, useEffect } from 'react';
import { CEFRLevel, LanguageCode, MainTab } from '../types';
import { CURRICULUM_LESSONS } from '../data/curriculum';
import { GLOSSARY_DATA } from '../data/glossary';
import { GRAMMAR_RULES } from '../data/grammarRules';
import {
  ResponsiveContainer,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  Legend,
  Tooltip,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid
} from 'recharts';
import {
  TrendingUp,
  Award,
  BookOpen,
  Layers,
  FileText,
  CheckCircle2,
  BarChart3,
  Radar as RadarIcon,
  Sparkles,
  ArrowRight,
  GraduationCap,
  ChevronRight,
  RotateCcw
} from 'lucide-react';

interface DashboardViewProps {
  currentLevel: CEFRLevel;
  onSelectLevel: (level: CEFRLevel) => void;
  onNavigateToTab: (tab: MainTab, level?: CEFRLevel, lessonId?: string) => void;
  language: LanguageCode;
}

interface LevelProgress {
  level: CEFRLevel;
  macroLevel: 'A1' | 'A2' | 'B1' | 'B2' | 'C1' | 'C2';
  name: string;
  totalLessons: number;
  totalVocab: number;
  totalGrammar: number;
  vocabPercent: number;
  grammarPercent: number;
  examPercent: number;
  overallPercent: number;
}

const ALL_SUB_LEVELS: CEFRLevel[] = [
  'A1.1', 'A1.2',
  'A2.1', 'A2.2',
  'B1.1', 'B1.2',
  'B2.1', 'B2.2',
  'C1.1', 'C1.2',
  'C2.1', 'C2.2'
];

const MACRO_LEVELS: Array<'A1' | 'A2' | 'B1' | 'B2' | 'C1' | 'C2'> = [
  'A1', 'A2', 'B1', 'B2', 'C1', 'C2'
];

const LEVEL_DESCRIPTIONS: Record<string, { de: string; fa: string; en: string }> = {
  'A1': {
    de: 'Elementare Sprachverwendung (Anfänger & Alltag)',
    fa: 'استفاده ابتدایی از زبان (مکالمات روزمره و پایه)',
    en: 'Elementary Language Use (Everyday Basics)'
  },
  'A2': {
    de: 'Grundlegende Kenntnisse (Beruf & Umwelt)',
    fa: 'دانش پایه (محیط کار و ارتباطات روزمره گسترده)',
    en: 'Basic Knowledge (Work & Extended Social Life)'
  },
  'B1': {
    de: 'Selbstständige Sprachverwendung (B1-Zertifikat)',
    fa: 'استفاده مستقل از زبان (مدرک اقامت و شهروندی)',
    en: 'Independent Language Use (Citizenship & Work)'
  },
  'B2': {
    de: 'Fließende Kommunikation (Fachsprache & Beruf)',
    fa: 'ارتباطات روان و تخصصی (پذیرش شغلی و تحصیلی)',
    en: 'Upper Intermediate (Professional & Academic)'
  },
  'C1': {
    de: 'Fachkundige Sprachkenntnisse (Universitätsniveau)',
    fa: 'تسلط تخصصی و دانشگاهی (DSH / TestDaF)',
    en: 'Effective Operational Proficiency (University)'
  },
  'C2': {
    de: 'Annähernd muttersprachliche Kompetenz (Exzellenz)',
    fa: 'تسلط کامل در سطح زبان مادری (فلسفه و حقوق)',
    en: 'Mastery & Near-Native Fluency (Literature & Law)'
  }
};

const STORAGE_KEY = 'mussawi_cefr_progress_v2';

export const DashboardView: React.FC<DashboardViewProps> = ({
  currentLevel,
  onSelectLevel,
  onNavigateToTab,
  language
}) => {
  const [chartType, setChartType] = useState<'radar' | 'bar'>('radar');
  const [levelViewMode, setLevelViewMode] = useState<'macro' | 'all'>('macro');
  const [selectedInspectLevel, setSelectedInspectLevel] = useState<CEFRLevel>(currentLevel);

  // User completed tracking stored in localStorage
  const [completedItems, setCompletedItems] = useState<{
    lessons: Record<string, boolean>;
    vocab: Record<string, boolean>;
    grammar: Record<string, boolean>;
    exams: Record<string, boolean>;
  }>(() => {
    if (typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem(STORAGE_KEY);
        if (saved) return JSON.parse(saved);
      } catch (e) {
        // ignore
      }
    }
    // Default baseline realistic progress:
    // A1.1 is mostly completed, A1.2 in progress, subsequent levels unlocked
    return {
      lessons: {
        'A1.1_1': true, 'A1.1_2': true, 'A1.1_3': true, 'A1.1_4': true, 'A1.1_5': true,
        'A1.2_1': true, 'A1.2_2': true
      },
      vocab: {
        'A1.1_0': true, 'A1.1_1': true, 'A1.1_2': true, 'A1.1_3': true, 'A1.1_4': true,
        'A1.1_5': true, 'A1.1_6': true, 'A1.1_7': true, 'A1.2_0': true, 'A1.2_1': true
      },
      grammar: {
        '0': true, '1': true, '2': true, '3': true, '4': true, '5': true
      },
      exams: {
        'A1.1_review': true
      }
    };
  });

  // Save changes to localStorage
  useEffect(() => {
    if (typeof window !== 'undefined') {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(completedItems));
      } catch (e) {
        // ignore
      }
    }
  }, [completedItems]);

  // Compute detailed metrics for each sub-level
  const subLevelMetrics = useMemo<LevelProgress[]>(() => {
    return ALL_SUB_LEVELS.map((lvl) => {
      const lessons = CURRICULUM_LESSONS[lvl] || [];
      const vocabList = GLOSSARY_DATA[lvl] || [];
      const grammarList = GRAMMAR_RULES.filter(r => r.level === lvl);

      const totalLessons = Math.max(lessons.length, 1);
      const totalVocab = Math.max(vocabList.length, 1);
      const totalGrammar = Math.max(grammarList.length, 1);

      // Count completed
      let completedLessonsCount = 0;
      lessons.forEach((_, idx) => {
        if (completedItems.lessons[`${lvl}_${idx + 1}`]) {
          completedLessonsCount++;
        }
      });

      let completedVocabCount = 0;
      vocabList.forEach((_, idx) => {
        if (completedItems.vocab[`${lvl}_${idx}`]) {
          completedVocabCount++;
        }
      });

      let completedGrammarCount = 0;
      grammarList.forEach(r => {
        if (completedItems.grammar[r.id]) {
          completedGrammarCount++;
        }
      });

      const completedExamCount = completedItems.exams[`${lvl}_review`] ? 1 : 0;

      // Calculate percentages
      const lessonPct = Math.min(100, Math.round((completedLessonsCount / totalLessons) * 100));
      const vocabPct = Math.min(100, Math.round((completedVocabCount / totalVocab) * 100));
      const grammarPct = Math.min(100, Math.round((completedGrammarCount / totalGrammar) * 100));
      const examPct = completedExamCount ? 100 : Math.round((lessonPct * 0.7) + (grammarPct * 0.3));

      // Weighted overall percentage
      const overall = Math.round((vocabPct * 0.35) + (grammarPct * 0.35) + (examPct * 0.30));

      const macroLevel = lvl.split('.')[0] as 'A1' | 'A2' | 'B1' | 'B2' | 'C1' | 'C2';

      return {
        level: lvl,
        macroLevel,
        name: `Level ${lvl}`,
        totalLessons,
        totalVocab,
        totalGrammar,
        vocabPercent: vocabPct,
        grammarPercent: grammarPct,
        examPercent: examPct,
        overallPercent: overall
      };
    });
  }, [completedItems]);

  // Aggregate metrics into Macro Levels (A1, A2, B1, B2, C1, C2)
  const macroLevelMetrics = useMemo(() => {
    return MACRO_LEVELS.map((macro) => {
      const children = subLevelMetrics.filter(m => m.macroLevel === macro);
      const avgVocab = Math.round(children.reduce((acc, c) => acc + c.vocabPercent, 0) / children.length);
      const avgGrammar = Math.round(children.reduce((acc, c) => acc + c.grammarPercent, 0) / children.length);
      const avgExam = Math.round(children.reduce((acc, c) => acc + c.examPercent, 0) / children.length);
      const avgOverall = Math.round((avgVocab * 0.35) + (avgGrammar * 0.35) + (avgExam * 0.30));

      return {
        name: macro,
        macroLevel: macro,
        vocabPercent: avgVocab,
        grammarPercent: avgGrammar,
        examPercent: avgExam,
        overallPercent: avgOverall,
        fullLabel: `CEFR ${macro}`,
        description: LEVEL_DESCRIPTIONS[macro]
      };
    });
  }, [subLevelMetrics]);

  // Overall Global Stats
  const globalStats = useMemo(() => {
    const totalVocabMastered = Object.values(completedItems.vocab).filter(Boolean).length;
    const totalGrammarMastered = Object.values(completedItems.grammar).filter(Boolean).length;
    const totalLessonsMastered = Object.values(completedItems.lessons).filter(Boolean).length;
    const avgOverall = Math.round(
      subLevelMetrics.reduce((acc, c) => acc + c.overallPercent, 0) / subLevelMetrics.length
    );

    return {
      overallPercent: avgOverall,
      vocabMastered: totalVocabMastered,
      grammarMastered: totalGrammarMastered,
      lessonsMastered: totalLessonsMastered
    };
  }, [completedItems, subLevelMetrics]);

  // Prepare data for Radar Chart
  const radarData = useMemo(() => {
    if (levelViewMode === 'macro') {
      return macroLevelMetrics.map(m => ({
        subject: m.name,
        Wortschatz: m.vocabPercent,
        Grammatik: m.grammarPercent,
        Prüfung: m.examPercent,
        Gesamt: m.overallPercent
      }));
    } else {
      return subLevelMetrics.map(m => ({
        subject: m.level,
        Wortschatz: m.vocabPercent,
        Grammatik: m.grammarPercent,
        Prüfung: m.examPercent,
        Gesamt: m.overallPercent
      }));
    }
  }, [levelViewMode, macroLevelMetrics, subLevelMetrics]);

  // Prepare data for Bar Chart
  const barData = useMemo(() => {
    if (levelViewMode === 'macro') {
      return macroLevelMetrics.map(m => ({
        name: m.name,
        'Wortschatz (Vokabeln)': m.vocabPercent,
        'Grammatik (Formeln)': m.grammarPercent,
        'Prüfung & Übungen': m.examPercent
      }));
    } else {
      return subLevelMetrics.map(m => ({
        name: m.level,
        'Wortschatz (Vokabeln)': m.vocabPercent,
        'Grammatik (Formeln)': m.grammarPercent,
        'Prüfung & Übungen': m.examPercent
      }));
    }
  }, [levelViewMode, macroLevelMetrics, subLevelMetrics]);

  const toggleLessonCompleted = (lvl: CEFRLevel, lessonIdx: number) => {
    const key = `${lvl}_${lessonIdx + 1}`;
    setCompletedItems(prev => ({
      ...prev,
      lessons: {
        ...prev.lessons,
        [key]: !prev.lessons[key]
      }
    }));
  };

  const isPersian = language === 'fa' || language === 'prs';

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12" id="cefr-dashboard-view">
      {/* Top Banner & CEFR Milestone Card */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 sm:p-6 shadow-xs">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-blue-600 text-white tracking-wide">
                DEUTSCH MUSSAWI AKADEMIE
              </span>
              <span className="text-xs text-slate-500 font-medium">
                CEFR Standard (A1 - C2)
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              {isPersian ? 'داشبورد پیشرفت یادگیری و تسلط آزمون' : 'Lernfortschritt & CEFR-Dashboard'}
            </h1>
            <p className="text-xs sm:text-sm text-slate-600 mt-1 max-w-2xl">
              {isPersian
                ? 'نمای تحلیلی پیشرفت شما در تمام سطوح اروپایی برای واژگان، فرمول‌های گرامر و آمادگی آزمون‌های رسمی گوته و تِلک.'
                : 'Analytische Übersicht Ihres Kompetenzzuwachses in Wortschatz, Grammatik und Prüfungspraxis über alle CEFR-Stufen.'}
            </p>
          </div>

          <div className="flex items-center gap-2 self-stretch sm:self-auto">
            <button
              onClick={() => onNavigateToTab('lesson', currentLevel)}
              className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs sm:text-sm shadow-xs transition-colors cursor-pointer"
            >
              <BookOpen size={16} />
              <span>{isPersian ? `ادامه درس (${currentLevel})` : `Lektion fortsetzen (${currentLevel})`}</span>
            </button>
            <button
              onClick={() => onNavigateToTab('exams', currentLevel)}
              className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm shadow-xs transition-colors cursor-pointer"
            >
              <Award size={16} />
              <span>{isPersian ? 'آزمون شبیه‌سازی' : 'Prüfungssimulation'}</span>
            </button>
          </div>
        </div>

        {/* 4 Summary Metric Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4 mt-6">
          <div className="p-4 rounded-lg bg-slate-50 border border-slate-200">
            <div className="flex items-center justify-between text-slate-500 text-xs font-semibold mb-1">
              <span>{isPersian ? 'میانگین تسلط کل' : 'Gesamtfortschritt'}</span>
              <TrendingUp size={16} className="text-blue-600" />
            </div>
            <div className="text-2xl sm:text-3xl font-black text-slate-900">
              {globalStats.overallPercent}%
            </div>
            <div className="w-full bg-slate-200 h-1.5 rounded-full mt-2 overflow-hidden">
              <div
                className="bg-blue-600 h-full rounded-full transition-all duration-500"
                style={{ width: `${globalStats.overallPercent}%` }}
              />
            </div>
          </div>

          <div className="p-4 rounded-lg bg-slate-50 border border-slate-200">
            <div className="flex items-center justify-between text-slate-500 text-xs font-semibold mb-1">
              <span>{isPersian ? 'واژگان تثبیت‌شده' : 'Wortschatz-Meisterschaft'}</span>
              <FileText size={16} className="text-emerald-600" />
            </div>
            <div className="text-2xl sm:text-3xl font-black text-slate-900">
              {globalStats.vocabMastered} <span className="text-xs font-normal text-slate-500">لغت / Wörter</span>
            </div>
            <div className="text-[11px] text-emerald-600 font-semibold mt-1 flex items-center gap-1">
              <CheckCircle2 size={12} />
              <span>{isPersian ? 'همراه آرتیکل و تلفظ' : 'Mit Artikeln & Audio'}</span>
            </div>
          </div>

          <div className="p-4 rounded-lg bg-slate-50 border border-slate-200">
            <div className="flex items-center justify-between text-slate-500 text-xs font-semibold mb-1">
              <span>{isPersian ? 'فرمول‌های گرامر' : 'Grammatik-Formeln'}</span>
              <Layers size={16} className="text-indigo-600" />
            </div>
            <div className="text-2xl sm:text-3xl font-black text-slate-900">
              {globalStats.grammarMastered} <span className="text-xs font-normal text-slate-500">قاعده / Regeln</span>
            </div>
            <div className="text-[11px] text-indigo-600 font-semibold mt-1 flex items-center gap-1">
              <Sparkles size={12} />
              <span>{isPersian ? 'فرمول‌های مصور ریاضی' : 'Systematische Didaktik'}</span>
            </div>
          </div>

          <div className="p-4 rounded-lg bg-slate-50 border border-slate-200">
            <div className="flex items-center justify-between text-slate-500 text-xs font-semibold mb-1">
              <span>{isPersian ? 'سطح کنونی' : 'Aktives Level'}</span>
              <GraduationCap size={16} className="text-amber-600" />
            </div>
            <div className="text-2xl sm:text-3xl font-black text-slate-900">
              Level {currentLevel}
            </div>
            <div className="text-[11px] text-amber-600 font-semibold mt-1 flex items-center gap-1">
              <Award size={12} />
              <span>{isPersian ? 'آماده امتحان تِلک و گوته' : 'Goethe / telc Vorbereitung'}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Chart Visualization Section with Recharts */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 sm:p-6 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
          <div>
            <h2 className="text-base sm:text-lg font-bold text-slate-900 flex items-center gap-2">
              <BarChart3 size={18} className="text-blue-600" />
              <span>
                {chartType === 'radar'
                  ? isPersian ? 'نمودار راداری شایستگی‌های CEFR' : 'CEFR-Kompetenz-Radardiagramm'
                  : isPersian ? 'نمودار ستونی مقایسه مهارت‌ها' : 'Balkendiagramm: Kompetenzvergleich'}
              </span>
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              {isPersian
                ? 'مقایسه درصد پیشرفت در ۳ بعد: واژگان (سبز)، گرامر (آبی) و تمرین آزمون (زرد)'
                : 'Vergleich in 3 Dimensionen: Wortschatz (Grün), Grammatik (Blau) und Prüfungspraxis (Gelb)'}
            </p>
          </div>

          {/* Controls: Chart Type Toggle & Level Granularity Switcher */}
          <div className="flex flex-wrap items-center gap-2">
            <div className="inline-flex rounded-lg border border-slate-200 bg-slate-50 p-0.5 text-xs font-bold">
              <button
                onClick={() => setChartType('radar')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md transition-colors cursor-pointer ${
                  chartType === 'radar'
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
                title="نمایش راداری (Radar)"
              >
                <RadarIcon size={14} />
                <span>رادار (Radar)</span>
              </button>
              <button
                onClick={() => setChartType('bar')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md transition-colors cursor-pointer ${
                  chartType === 'bar'
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
                title="نمایش ستونی (Bar)"
              >
                <BarChart3 size={14} />
                <span>ستونی (Bar)</span>
              </button>
            </div>

            <div className="inline-flex rounded-lg border border-slate-200 bg-slate-50 p-0.5 text-xs font-bold">
              <button
                onClick={() => setLevelViewMode('macro')}
                className={`px-2.5 py-1.5 rounded-md transition-colors cursor-pointer ${
                  levelViewMode === 'macro'
                    ? 'bg-slate-800 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {isPersian ? 'سطوح اصلی (A1-C2)' : 'Hauptstufen (A1-C2)'}
              </button>
              <button
                onClick={() => setLevelViewMode('all')}
                className={`px-2.5 py-1.5 rounded-md transition-colors cursor-pointer ${
                  levelViewMode === 'all'
                    ? 'bg-slate-800 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {isPersian ? 'ریزسطوح (۱۲ سطح)' : 'Alle 12 Unterstufen'}
              </button>
            </div>
          </div>
        </div>

        {/* Recharts Canvas */}
        <div className="w-full h-[360px] sm:h-[420px] pt-2">
          {chartType === 'radar' ? (
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart data={radarData} outerRadius="75%">
                <PolarGrid stroke="#cbd5e1" strokeDasharray="3 3" />
                <PolarAngleAxis
                  dataKey="subject"
                  tick={{ fill: '#334155', fontSize: 12, fontWeight: 700 }}
                />
                <PolarRadiusAxis
                  angle={30}
                  domain={[0, 100]}
                  tick={{ fill: '#64748b', fontSize: 10 }}
                />
                <Radar
                  name="Wortschatz (واژگان)"
                  dataKey="Wortschatz"
                  stroke="#10b981"
                  fill="#10b981"
                  fillOpacity={0.25}
                  strokeWidth={2}
                />
                <Radar
                  name="Grammatik (گرامر)"
                  dataKey="Grammatik"
                  stroke="#3b82f6"
                  fill="#3b82f6"
                  fillOpacity={0.25}
                  strokeWidth={2}
                />
                <Radar
                  name="Prüfung (آزمون)"
                  dataKey="Prüfung"
                  stroke="#f59e0b"
                  fill="#f59e0b"
                  fillOpacity={0.25}
                  strokeWidth={2}
                />
                <Tooltip
                  formatter={(value: any) => [`${value}%`, '']}
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    border: '1px solid #334155',
                    borderRadius: '8px',
                    color: '#f8fafc',
                    fontSize: '12px'
                  }}
                />
                <Legend
                  wrapperStyle={{ paddingTop: '10px', fontSize: '12px' }}
                />
              </RadarChart>
            </ResponsiveContainer>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={barData}
                margin={{ top: 20, right: 20, left: -10, bottom: 20 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
                <XAxis
                  dataKey="name"
                  tick={{ fill: '#334155', fontSize: 12, fontWeight: 600 }}
                  axisLine={{ stroke: '#cbd5e1' }}
                />
                <YAxis
                  domain={[0, 100]}
                  tick={{ fill: '#64748b', fontSize: 11 }}
                  unit="%"
                  axisLine={{ stroke: '#cbd5e1' }}
                />
                <Tooltip
                  formatter={(value: any) => [`${value}%`, '']}
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    border: '1px solid #334155',
                    borderRadius: '8px',
                    color: '#f8fafc',
                    fontSize: '12px'
                  }}
                />
                <Legend wrapperStyle={{ paddingTop: '10px', fontSize: '12px' }} />
                <Bar
                  dataKey="Wortschatz (Vokabeln)"
                  fill="#10b981"
                  radius={[4, 4, 0, 0]}
                  maxBarSize={40}
                />
                <Bar
                  dataKey="Grammatik (Formeln)"
                  fill="#3b82f6"
                  radius={[4, 4, 0, 0]}
                  maxBarSize={40}
                />
                <Bar
                  dataKey="Prüfung & Übungen"
                  fill="#f59e0b"
                  radius={[4, 4, 0, 0]}
                  maxBarSize={40}
                />
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>
      </div>

      {/* Detailed CEFR Level Cards with Progress Breakdown & Action Controls */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-bold text-slate-900">
              {isPersian ? 'جزئیات پیشرفت سطوح اروپایی (A1 - C2)' : 'Detailübersicht der CEFR-Stufen'}
            </h3>
            <p className="text-xs text-slate-500">
              {isPersian
                ? 'برای باز کردن درس‌ها یا تمرین هر سطح، روی کارت مربوطه کلیک کنید.'
                : 'Klicken Sie auf eine Stufe, um direkt zu den entsprechenden Lerneinheiten zu springen.'}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {subLevelMetrics.map((lvlProg) => {
            const isCurrent = currentLevel === lvlProg.level;
            const macroDesc = LEVEL_DESCRIPTIONS[lvlProg.macroLevel];

            return (
              <div
                key={lvlProg.level}
                className={`bg-white rounded-xl border p-4 transition-all duration-200 shadow-xs flex flex-col justify-between ${
                  isCurrent
                    ? 'border-blue-500 ring-2 ring-blue-100'
                    : 'border-slate-200 hover:border-slate-300'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <span className={`w-8 h-8 rounded-lg flex items-center justify-center font-black text-xs ${
                        isCurrent
                          ? 'bg-blue-600 text-white'
                          : 'bg-slate-100 text-slate-800'
                      }`}>
                        {lvlProg.level}
                      </span>
                      <div>
                        <h4 className="font-bold text-sm text-slate-900">
                          {lvlProg.level} {isCurrent && <span className="text-[10px] text-blue-600 font-bold bg-blue-50 px-1.5 py-0.5 rounded border border-blue-200">سطح فعال</span>}
                        </h4>
                        <span className="text-[11px] text-slate-500">
                          {lvlProg.totalLessons} Lektionen
                        </span>
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="text-lg font-black text-slate-900">
                        {lvlProg.overallPercent}%
                      </span>
                    </div>
                  </div>

                  <p className="text-[11px] text-slate-600 line-clamp-1 mb-3">
                    {macroDesc ? (isPersian ? macroDesc.fa : macroDesc.de) : ''}
                  </p>

                  {/* 3 Component Progress Bars */}
                  <div className="space-y-2 text-xs">
                    <div>
                      <div className="flex justify-between text-[11px] text-slate-600 mb-0.5">
                        <span className="flex items-center gap-1 font-medium">
                          <FileText size={11} className="text-emerald-600" />
                          <span>Wortschatz</span>
                        </span>
                        <span className="font-bold text-emerald-700">{lvlProg.vocabPercent}%</span>
                      </div>
                      <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                        <div
                          className="bg-emerald-500 h-full rounded-full"
                          style={{ width: `${lvlProg.vocabPercent}%` }}
                        />
                      </div>
                    </div>

                    <div>
                      <div className="flex justify-between text-[11px] text-slate-600 mb-0.5">
                        <span className="flex items-center gap-1 font-medium">
                          <Layers size={11} className="text-blue-600" />
                          <span>Grammatik</span>
                        </span>
                        <span className="font-bold text-blue-700">{lvlProg.grammarPercent}%</span>
                      </div>
                      <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                        <div
                          className="bg-blue-600 h-full rounded-full"
                          style={{ width: `${lvlProg.grammarPercent}%` }}
                        />
                      </div>
                    </div>

                    <div>
                      <div className="flex justify-between text-[11px] text-slate-600 mb-0.5">
                        <span className="flex items-center gap-1 font-medium">
                          <Award size={11} className="text-amber-600" />
                          <span>Prüfung & Übung</span>
                        </span>
                        <span className="font-bold text-amber-700">{lvlProg.examPercent}%</span>
                      </div>
                      <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                        <div
                          className="bg-amber-500 h-full rounded-full"
                          style={{ width: `${lvlProg.examPercent}%` }}
                        />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Card Action Buttons */}
                <div className="pt-4 mt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                  <button
                    onClick={() => {
                      onSelectLevel(lvlProg.level);
                      onNavigateToTab('lesson', lvlProg.level);
                    }}
                    className="flex-1 py-1.5 px-2.5 rounded-lg bg-blue-50 hover:bg-blue-100 text-blue-700 font-bold text-xs transition-colors flex items-center justify-center gap-1 cursor-pointer"
                  >
                    <span>{isPersian ? 'ورود به درس‌ها' : 'Lektionen'}</span>
                    <ChevronRight size={13} />
                  </button>

                  <button
                    onClick={() => {
                      onSelectLevel(lvlProg.level);
                      onNavigateToTab('glossary', lvlProg.level);
                    }}
                    className="py-1.5 px-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium text-xs transition-colors cursor-pointer"
                    title="واژگان این سطح"
                  >
                    Wortschatz
                  </button>

                  <button
                    onClick={() => {
                      onSelectLevel(lvlProg.level);
                      onNavigateToTab('exams', lvlProg.level);
                    }}
                    className="py-1.5 px-2 rounded-lg bg-amber-50 hover:bg-amber-100 text-amber-800 font-medium text-xs transition-colors cursor-pointer"
                    title="آزمون این سطح"
                  >
                    Prüfung
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
