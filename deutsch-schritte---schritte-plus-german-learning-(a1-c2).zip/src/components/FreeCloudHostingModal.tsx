import React, { useState } from 'react';
import { 
  Cloud, 
  Github, 
  Globe, 
  Server, 
  CheckCircle2, 
  Copy, 
  Check, 
  ExternalLink, 
  X, 
  Smartphone, 
  HardDrive, 
  ShieldCheck, 
  Zap,
  Download
} from 'lucide-react';
import { LanguageCode } from '../types';

interface FreeCloudHostingModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: LanguageCode;
}

export const FreeCloudHostingModal: React.FC<FreeCloudHostingModalProps> = ({
  isOpen,
  onClose,
  language
}) => {
  const [activeTab, setActiveTab] = useState<'google_cloud' | 'github_pages' | 'vercel_netlify' | 'apple_google_drive' | 'pwa_offline'>('google_cloud');
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCode(id);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  const isFaOrPrs = language === 'fa' || language === 'prs';

  return (
    <div className="fixed inset-0 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 z-50 animate-fadeIn">
      <div 
        className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-4xl max-h-[92vh] flex flex-col overflow-hidden"
        dir={isFaOrPrs ? 'rtl' : 'ltr'}
      >
        {/* Modal Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-blue-700 via-indigo-700 to-slate-800 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-white/15 rounded-lg backdrop-blur-xs">
              <Cloud size={24} className="text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-bold">
                  {isFaOrPrs ? 'راهنمای استقرار و هاستینگ ۱۰۰٪ رایگان (Google Cloud & Free Web)' : 'Free Cloud & Hosting Deployment Guide'}
                </h2>
                <span className="bg-emerald-500/30 text-emerald-300 border border-emerald-400/40 text-[10px] font-bold px-2 py-0.5 rounded-full">
                  {isFaOrPrs ? 'رایگان دائمی ($0)' : '100% Free'}
                </span>
              </div>
              <p className="text-xs text-blue-100 mt-0.5">
                {isFaOrPrs 
                  ? 'آموزش گام‌به‌گام اضافه کردن اپ به گوگل کلود، گیت‌هاب، ورسل، آی‌کلود و گوگل درایو بدون پرداخت هیچ هزینه‌ای'
                  : 'Step-by-step instructions to host and share this app completely free on Google Cloud, GitHub Pages, Vercel & iCloud'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-white/80 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X size={20} />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex border-b border-slate-200 bg-slate-50 px-3 sm:px-5 gap-1 sm:gap-2 overflow-x-auto no-scrollbar shrink-0">
          {[
            { id: 'google_cloud', labelFa: 'گوگل کلود (Google Cloud Run)', labelEn: 'Google Cloud Run', icon: Cloud },
            { id: 'github_pages', labelFa: 'گیت‌هاب پیجز (GitHub Pages)', labelEn: 'GitHub Pages', icon: Github },
            { id: 'vercel_netlify', labelFa: 'ورسل و نتلیفای (Vercel / Netlify)', labelEn: 'Vercel & Netlify', icon: Zap },
            { id: 'apple_google_drive', labelFa: 'آی‌کلود و گوگل درایو (iCloud / Drive)', labelEn: 'iCloud & Drive', icon: HardDrive },
            { id: 'pwa_offline', labelFa: 'نصب رایگان موبایل (PWA Offline)', labelEn: 'Mobile App (PWA)', icon: Smartphone }
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`py-3 px-3 text-xs font-bold border-b-2 transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                  isActive
                    ? 'border-blue-600 text-blue-700 bg-white shadow-xs'
                    : 'border-transparent text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                <Icon size={15} className={isActive ? 'text-blue-600' : 'text-slate-400'} />
                <span>{isFaOrPrs ? tab.labelFa : tab.labelEn}</span>
              </button>
            );
          })}
        </div>

        {/* Modal Body */}
        <div className="flex-1 p-4 sm:p-6 overflow-y-auto space-y-5 text-slate-800 text-xs sm:text-sm leading-relaxed">
          {/* PROMINENT LIVE PUBLIC LINK CARD - NO PAYMENT / NO CREDIT CARD NEEDED */}
          <div className="p-4 sm:p-5 bg-gradient-to-r from-emerald-50 via-teal-50 to-emerald-100 border-2 border-emerald-500/70 rounded-xl shadow-xs">
            <div className="flex items-center justify-between gap-2 flex-wrap">
              <div className="flex items-center gap-2">
                <span className="flex h-3 w-3 relative">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
                </span>
                <h3 className="font-bold text-emerald-950 text-sm sm:text-base">
                  {isFaOrPrs ? 'وب‌سایت عمومی شما فعال و منتشر شده است (۱۰۰٪ رایگان و دائمی)' : 'Your Public Web App is Already Published and Live (100% Free)'}
                </h3>
              </div>
              <span className="bg-emerald-700 text-white text-[10px] font-bold px-2.5 py-1 rounded-full shadow-xs">
                {isFaOrPrs ? '✓ بدون نیاز به پرداخت یا کارت بانکی' : 'No Payment or Card Required'}
              </span>
            </div>

            <p className="text-emerald-900 text-xs mt-2.5 leading-relaxed">
              {isFaOrPrs
                ? 'راهنمای رفع مشکل درخواست پرداخت ماهانه: اگر در منوی بالای گوگل روی گزینه «Deploy to Cloud Run» کلیک کنید، سیستم گوگل از شما درخواست اطلاعات کارت بانکی و هزینه ماهانه می‌کند. در حالی که اصلاً نیازی به آن ندارید! گوگل این وب‌سایت را از طریق بخش «Share (اشتراک‌گذاری)» به صورت کاملاً رایگان، بدون تاریخ انقضا و بدون نیاز به ورود کاربر منتشر کرده است. شما و هر شخص دیگری در دنیا می‌توانید مستقیماً از لینک زیر استفاده نمایید:'
                : 'Why does Google ask for payment? Clicking "Deploy to Cloud Run" prompts for a GCP billing credit card. However, you DO NOT need to pay anything! Via the Google AI Studio Share workflow, this web application is already deployed 100% free, publicly accessible with zero credentials required:'}
            </p>

            <div className="mt-3.5 flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
              <div className="flex-1 bg-white border border-emerald-300 px-3.5 py-2.5 rounded-lg font-mono text-xs text-blue-800 font-bold select-all break-all shadow-xs flex items-center justify-between">
                <span>https://ais-pre-b4vgvhmdgl5ogwcx6o7ohe-644517703235.europe-west1.run.app</span>
              </div>
              <button
                onClick={() => handleCopy('https://ais-pre-b4vgvhmdgl5ogwcx6o7ohe-644517703235.europe-west1.run.app', 'live_url')}
                className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer shadow-xs shrink-0"
              >
                {copiedCode === 'live_url' ? <Check size={14} /> : <Copy size={14} />}
                <span>{copiedCode === 'live_url' ? (isFaOrPrs ? 'کپی شد!' : 'Copied!') : (isFaOrPrs ? 'کپی لینک عمومی' : 'Copy Public Link')}</span>
              </button>
              <a
                href="https://ais-pre-b4vgvhmdgl5ogwcx6o7ohe-644517703235.europe-west1.run.app"
                target="_blank"
                rel="noopener noreferrer"
                className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-bold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer shadow-xs shrink-0"
              >
                <ExternalLink size={14} />
                <span>{isFaOrPrs ? 'باز کردن وب‌سایت' : 'Open Web App'}</span>
              </a>
            </div>
          </div>
          {/* TAB 1: GOOGLE CLOUD RUN */}
          {activeTab === 'google_cloud' && (
            <div className="space-y-4">
              <div className="p-3.5 bg-blue-50 border border-blue-200 rounded-lg flex items-start gap-3">
                <Cloud size={20} className="text-blue-600 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold text-blue-900">
                    {isFaOrPrs ? 'طرح کاملاً رایگان گوگل کلود (Always Free Tier)' : 'Google Cloud Run Always Free Tier'}
                  </h4>
                  <p className="text-blue-800 text-xs mt-1">
                    {isFaOrPrs
                      ? 'شرکت گوگل ماهانه ۲,۰۰۰,۰۰۰ (دو میلیون) درخواست، ۳۶۰,۰۰۰ گیگابایت-ثانیه حافظه و ۱۸۰,۰۰۰ گیگاهرتز پردازنده را به صورت ۱۰۰٪ رایگان و بدون انقضا در اختیار شما می‌گذارد.'
                      : 'Google Cloud provides 2 million requests per month, 360,000 GB-seconds of memory and 180,000 vCPU-seconds 100% free every single month.'}
                  </p>
                </div>
              </div>

              <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                <CheckCircle2 size={16} className="text-emerald-600" />
                <span>{isFaOrPrs ? 'روش اول: استقرار مستقیم از داخل Google AI Studio (ساده‌ترین روش)' : 'Method 1: Direct Deploy from Google AI Studio'}</span>
              </h3>

              <ol className="list-decimal list-inside space-y-2.5 text-slate-700 pr-2">
                <li>
                  <strong>{isFaOrPrs ? 'منوی بالا سمت راست:' : 'Top-Right Settings Menu:'}</strong> {isFaOrPrs ? 'در بالای همین صفحه در منوی هوش مصنوعی گوگل روی علامت سه نقطه یا Settings بزنید.' : 'Click on the Settings / Action menu at the top right of Google AI Studio.'}
                </li>
                <li>
                  <strong>{isFaOrPrs ? 'انتخاب Deploy to Cloud Run:' : 'Select Deploy to Cloud Run:'}</strong> {isFaOrPrs ? 'گزینه Deploy to Cloud Run را انتخاب نمایید. این سرویس در لایه Always Free گوگل قرار دارد و نیازی به پرداخت وجه ندارد.' : 'Choose "Deploy to Cloud Run". It uses Google Cloud Always Free tier with 0 cost.'}
                </li>
                <li>
                  <strong>{isFaOrPrs ? 'دریافت آدرس عمومی:' : 'Get Public HTTPS URL:'}</strong> {isFaOrPrs ? 'گوگل یک آدرس دائمی و رمزنگاری‌شده HTTPS اختصاصی به شما می‌دهد که می‌توانید آن را با همه شاگردان و دوستان به اشتراک بگذارید.' : 'Google provides an authentic HTTPS URL that never expires and can be shared with anyone worldwide.'}
                </li>
              </ol>

              <div className="bg-slate-900 text-slate-200 p-3 rounded-lg font-mono text-[11px] space-y-1">
                <div className="flex justify-between items-center text-slate-400 text-[10px] pb-1 border-b border-slate-800">
                  <span>Google Cloud CLI Deploy Command (در صورت استفاده از ترمینال)</span>
                  <button
                    onClick={() => handleCopy('gcloud run deploy deutsch-meister --source . --platform managed --allow-unauthenticated', 'gcloud')}
                    className="hover:text-white flex items-center gap-1 cursor-pointer"
                  >
                    {copiedCode === 'gcloud' ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
                    <span>{copiedCode === 'gcloud' ? 'کپی شد' : 'کپی دستور'}</span>
                  </button>
                </div>
                <code className="text-emerald-400">
                  gcloud run deploy deutsch-meister --source . --platform managed --allow-unauthenticated
                </code>
              </div>
            </div>
          )}

          {/* TAB 2: GITHUB PAGES */}
          {activeTab === 'github_pages' && (
            <div className="space-y-4">
              <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-lg flex items-start gap-3">
                <Github size={20} className="text-emerald-700 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold text-emerald-950">
                    {isFaOrPrs ? 'گیت‌هاب پیجز (GitHub Pages) - رایگان همیشگی بدون تاریخ انقضا' : 'GitHub Pages - 100% Free Forever'}
                  </h4>
                  <p className="text-emerald-900 text-xs mt-1">
                    {isFaOrPrs
                      ? 'گیت‌هاب وبسایت شما را به شکل مادام‌العمر و بدون نیاز به هیچ‌گونه کارت بانکی روی آدرس username.github.io میزبانی می‌کند.'
                      : 'GitHub hosts your application for life on your personal domain (username.github.io) without requiring any credit card.'}
                  </p>
                </div>
              </div>

              <ol className="list-decimal list-inside space-y-2 text-slate-700 pr-2">
                <li>
                  {isFaOrPrs ? 'از منوی بالای AI Studio گزینه ' : 'From AI Studio top menu, click '}
                  <strong className="text-blue-700">Export to GitHub</strong>
                  {isFaOrPrs ? ' را بزنید تا کل پروژه در ریپازیتوری شخصی شما در گیت‌هاب ذخیره شود.' : ' to create a repository in your GitHub account.'}
                </li>
                <li>
                  {isFaOrPrs ? 'در گیت‌هاب وارد مخزن پروژه شده و به برگه ' : 'Go to your repository on GitHub and click '}
                  <strong>Settings &gt; Pages</strong>
                  {isFaOrPrs ? ' بروید.' : '.'}
                </li>
                <li>
                  {isFaOrPrs ? 'در بخش Build and deployment گزینه ' : 'Under "Build and deployment", choose '}
                  <strong>GitHub Actions</strong>
                  {isFaOrPrs ? ' یا شاخه gh-pages را انتخاب کنید.' : ' or Vite deploy workflow.'}
                </li>
                <li>
                  {isFaOrPrs ? 'سایت شما فوراً روی آدرس اختصاصی منتشر می‌شود و بدون پرداخت حتی ۱ سنت همیشه آنلاین خواهد بود.' : 'Your site will be live instantly with a free SSL certificate!'}
                </li>
              </ol>

              <div className="bg-slate-900 text-slate-200 p-3 rounded-lg font-mono text-[11px] space-y-1">
                <div className="flex justify-between items-center text-slate-400 text-[10px] pb-1 border-b border-slate-800">
                  <span>کامپایل پروژه برای هاست استاتیک (Build Command)</span>
                  <button
                    onClick={() => handleCopy('npm run build', 'build_cmd')}
                    className="hover:text-white flex items-center gap-1 cursor-pointer"
                  >
                    {copiedCode === 'build_cmd' ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
                    <span>{copiedCode === 'build_cmd' ? 'کپی شد' : 'کپی'}</span>
                  </button>
                </div>
                <code className="text-amber-300">npm run build</code>
                <p className="text-[10px] text-slate-400 mt-1">
                  {isFaOrPrs ? 'پوشه خروجی dist آماده قرار دادن روی هر هاست دلخواهی است.' : 'The resulting "dist" folder can be hosted anywhere.'}
                </p>
              </div>
            </div>
          )}

          {/* TAB 3: VERCEL & NETLIFY */}
          {activeTab === 'vercel_netlify' && (
            <div className="space-y-4">
              <div className="p-3.5 bg-amber-50 border border-amber-200 rounded-lg flex items-start gap-3">
                <Zap size={20} className="text-amber-700 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold text-amber-950">
                    {isFaOrPrs ? 'ورسل و نتلیفای (Vercel & Netlify) - سریع‌ترین هاست رایگان ابری' : 'Vercel & Netlify - Fastest 1-Click Cloud Hosting'}
                  </h4>
                  <p className="text-amber-900 text-xs mt-1">
                    {isFaOrPrs
                      ? 'ساده‌ترین روش دنیا: فقط کشیدن و رها کردن (Drag & Drop) پوشه برنامه بدون نوشتن حتی یک خط کد!'
                      : 'Drag and drop the built "dist" folder directly into Netlify Drop, or connect your GitHub to Vercel.'}
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="p-3 bg-white border border-slate-200 rounded-lg space-y-2">
                  <div className="font-bold text-slate-900 flex items-center gap-1.5">
                    <Globe size={16} className="text-blue-600" />
                    <span>روش اول: Netlify Drop (بدون نیاز به ثبت نام سخت)</span>
                  </div>
                  <p className="text-xs text-slate-600">
                    ۱. دستور <code className="bg-slate-100 px-1 py-0.5 rounded font-mono">npm run build</code> را اجرا کنید یا فایل ZIP را دانلود کنید.<br />
                    ۲. به سایت <a href="https://app.netlify.com/drop" target="_blank" rel="noreferrer" className="text-blue-600 font-bold underline">netlify.com/drop</a> بروید.<br />
                    ۳. پوشه <strong>dist</strong> را بکشید و در کادر رها کنید.<br />
                    ۴. ظرف ۵ ثانیه سایت شما با دامنه اختصاصی رایگان بالا می‌آید!
                  </p>
                </div>

                <div className="p-3 bg-white border border-slate-200 rounded-lg space-y-2">
                  <div className="font-bold text-slate-900 flex items-center gap-1.5">
                    <Zap size={16} className="text-amber-600" />
                    <span>روش دوم: Vercel (متصل به گیت‌هاب با آپدیت خودکار)</span>
                  </div>
                  <p className="text-xs text-slate-600">
                    ۱. در سایت <a href="https://vercel.com" target="_blank" rel="noreferrer" className="text-blue-600 font-bold underline">vercel.com</a> ثبت‌نام رایگان کنید.<br />
                    ۲. دکمه "Add New Project" را بزنید و ریپازیتوری گیت‌هاب را انتخاب کنید.<br />
                    ۳. دکمه <strong>Deploy</strong> را فشار دهید. تمام! هر تغییری بدهید خودکار آپدیت می‌شود.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: APPLE ICLOUD & GOOGLE DRIVE */}
          {activeTab === 'apple_google_drive' && (
            <div className="space-y-4">
              <div className="p-3.5 bg-purple-50 border border-purple-200 rounded-lg flex items-start gap-3">
                <HardDrive size={20} className="text-purple-700 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold text-purple-950">
                    {isFaOrPrs ? 'ذخیره در گوگل درایو (Google Drive) و اپل آی‌کلود (Apple iCloud)' : 'Store in Google Drive & Apple iCloud'}
                  </h4>
                  <p className="text-purple-900 text-xs mt-1">
                    {isFaOrPrs
                      ? 'چگونه کل کدهای برنامه، کتاب‌ها، صداها و درس‌ها را در فضای ابری گوگل درایو یا آی‌کلود برای همیشه نگه دارید:'
                      : 'How to safely archive all code, lessons, audio and assets into your personal cloud storage.'}
                  </p>
                </div>
              </div>

              <ol className="list-decimal list-inside space-y-2.5 text-slate-700 pr-2">
                <li>
                  <strong>{isFaOrPrs ? 'دانلود فایل فشرده ZIP کامل برنامه:' : 'Download Complete Project ZIP:'}</strong> {isFaOrPrs ? 'در منوی بالای صفحه گزینه "Export to ZIP" یا "Download ZIP" را بزنید.' : 'Click "Download ZIP" or "Export to ZIP" from the top menu.'}
                </li>
                <li>
                  <strong>{isFaOrPrs ? 'آپلود در Google Drive یا iCloud:' : 'Upload to Drive or iCloud:'}</strong> {isFaOrPrs ? 'فایل دانلود شده را مستقیماً داخل گوگل درایو یا iCloud Drive در پوشه‌ای به نام "Deutsch Meister App" آپلود کنید.' : 'Upload the zip package to your personal Google Drive or iCloud folder.'}
                </li>
                <li>
                  <strong>{isFaOrPrs ? 'دسترسی ابری همیشگی:' : 'Permanent Cloud Access:'}</strong> {isFaOrPrs ? 'فایل‌های شما همیشه ایمن خواهند بود و با هر کامپیوتر یا گوشی می‌توانید آن را باز کرده و با یک کلیک اجرا فرمایید.' : 'Your educational materials and application logic remain backed up permanently at zero cost.'}
                </li>
              </ol>
            </div>
          )}

          {/* TAB 5: PWA OFFLINE */}
          {activeTab === 'pwa_offline' && (
            <div className="space-y-4">
              <div className="p-3.5 bg-indigo-50 border border-indigo-200 rounded-lg flex items-start gap-3">
                <Smartphone size={20} className="text-indigo-700 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold text-indigo-950">
                    {isFaOrPrs ? 'استفاده به عنوان اپلیکیشن واقعی موبایل بدون نیاز به پرداخت اپ‌استور یا پلی‌استور' : 'Mobile App Installation without App Store fees'}
                  </h4>
                  <p className="text-indigo-900 text-xs mt-1">
                    {isFaOrPrs
                      ? 'این برنامه مجهز به معماری پیشرفته PWA است و نیازی به پرداخت هزینه ۹۹ دلاری اپل یا ۲۵ دلاری گوگل پلی ندارد!'
                      : 'Using Progressive Web App (PWA) standards, this app installs directly to home screens without store fees.'}
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-lg space-y-2">
                  <div className="font-bold text-slate-900 flex items-center gap-1.5">
                    <span className="text-xs bg-slate-200 px-1.5 py-0.5 rounded font-mono">iOS</span>
                    <span>روی گوشی‌های آیفون (iPhone Safari)</span>
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    ۱. لینک برنامه را در مرورگر <strong>Safari</strong> باز کنید.<br />
                    ۲. دکمه اشتراک‌گذاری (<strong className="text-blue-600">Share</strong> که آیکون مربع با فلش رو به بالا است) در پایین صفحه را بزنید.<br />
                    ۳. گزینه <strong className="text-slate-900">Add to Home Screen (افزودن به صفحه اصلی)</strong> را انتخاب کنید.<br />
                    ۴. آیکون برنامه روی صفحه آیفون قرار می‌گیرد و به شکل ۱۰۰٪ آفلاین و مستقل از اینترنت باز می‌شود.
                  </p>
                </div>

                <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-lg space-y-2">
                  <div className="font-bold text-slate-900 flex items-center gap-1.5">
                    <span className="text-xs bg-slate-200 px-1.5 py-0.5 rounded font-mono">Android</span>
                    <span>روی گوشی‌های اندروید (Chrome / Samsung)</span>
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    ۱. لینک برنامه را در <strong>Chrome</strong> باز کنید.<br />
                    ۲. روی منوی سه‌نقطه بالای مرورگر بزنید.<br />
                    ۳. دکمه <strong className="text-blue-600">Install app</strong> یا <strong>افزودن به صفحه اصلی</strong> را فشار دهید.<br />
                    ۴. برنامه با تمام درس‌ها، صداها و آزمون‌ها روی حافظه گوشی ذخیره می‌شود.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-3 sm:p-4 bg-slate-50 border-t border-slate-200 flex flex-wrap items-center justify-between gap-2 shrink-0">
          <div className="flex items-center gap-1.5 text-xs text-slate-500">
            <ShieldCheck size={16} className="text-emerald-600" />
            <span>
              {isFaOrPrs 
                ? 'تمام گزینه‌های فوق ۱۰۰٪ تضمین‌شده، رسمی و کاملاً رایگان هستند.'
                : 'All listed options are 100% official, secure and permanently free.'}
            </span>
          </div>
          <button
            onClick={onClose}
            className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg text-xs shadow-xs transition-colors cursor-pointer"
          >
            {isFaOrPrs ? 'بستن راهنما و بازگشت به درس‌ها' : 'Close Guide'}
          </button>
        </div>
      </div>
    </div>
  );
};
