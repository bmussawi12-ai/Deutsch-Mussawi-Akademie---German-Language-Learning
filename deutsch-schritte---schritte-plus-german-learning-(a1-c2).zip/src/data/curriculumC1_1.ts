import { Lesson } from '../types';

export const CURRICULUM_C1_1: Lesson[] = [
  {
    id: 'c1_1_lek1',
    lektionNumber: 1,
    level: 'C1.1',
    title: 'Wissenschaftsdiskurs und Gesellschaftswandel',
    subTitle: 'Akademische Texte, FAZ-Feuilleton und erweiterte Partizipialattribute (C1 Niveau)',
    topic: 'Klimaethik, wissenschaftliche Methodik und syntaktische Verdichtung',
    fotoHoergeschichte: {
      title: 'Foto-Hörgeschichte: Symposium an der Humboldt-Universität zu Berlin',
      imagePrompt: 'A historic grand lecture hall at Humboldt University Berlin where scholars from various disciplines attend an interdisciplinary colloquium.',
      imageTheme: 'Wissenschaftskolloquium in Berlin',
      audioDuration: '03:45',
      transcript: [
        { speaker: 'Prof. Dr. von Weizsäcker', text: 'Die von der Forschungsgruppe vorgelegten Befunde belegen unmissverständlich, dass die bisherigen Annahmen über klimatische Kipppunkte revidiert werden müssen.' },
        { speaker: 'Dr. Al-Mansoor', text: 'In Anbetracht der methodischen Validität der herangezogenen empirischen Daten stimme ich dieser Einschätzung vollumfänglich zu.' },
        { speaker: 'Prof. Dr. von Weizsäcker', text: 'Entscheidend ist nun, welche transformativen Maßnahmen von der politischen Administration abgeleitet werden.' }
      ],
      summary: {
        en: 'Scholars at Humboldt University Berlin debate empirical climatological methodologies and systemic transformation strategies.',
        fa: 'اساتید و پژوهشگران دانشگاه هومبولت برلین روش‌شناسی‌های تجربی اقلیم‌شناسی و راهبردهای تحول ساختاری را به بحث گذاشته‌اند.',
        prs: 'پوهان و محققان پوهنتون هومبولت برلین روش‌های علمی اقلیم‌شناسی و تغییرات اساسی جامعه را به تحلیل گرفته‌اند.',
        tr: 'Humboldt Üniversitesi\'ndeki bilim insanları ampirik iklim metodolojilerini ve sistemsel dönüşüm adımlarını tartışıyor.',
        ar: 'يناقش باحثون في جامعة هومبولت في برلين المنهجيات المناخية التجريبية واستراتيجيات التحول المجتمعي.',
        es: 'Científicos en la Universidad Humboldt de Berlín debaten sobre metodologías empíricas y estrategias de transformación sistémica.'
      }
    },
    sectionA: {
      title: 'Mussawi A: Sprechen & Dialog',
      focus: 'Sprechen & Hören (Akademische Vorträge & Disputationen)',
      description: {
        en: 'Articulate complex hypotheses, refute opposing empirical theories, and engage in high-level intellectual debate.',
        fa: 'بیان فرضیه‌های پیچیده علمی، رد نظریه‌های تجربی مخالف و مشارکت در مناظرات فکری سطح بالا.',
        prs: 'فرضیه‌های پیچیده علمی را مطرح کرده و در مباحثات علمی دانشگاهی سهم بگیرید.',
        tr: 'Karmaşık bilimsel hipotezleri savunun, karşıt ampirik tezleri çürütün ve yüksek düzeyli entelektüel münazaralara katılın.',
        ar: 'صياغة الفرضيات العلمية المعقدة، ودحض النظريات التجريبية المضادة، والمشاركة في سجالات فكرية رفيعة المستوى.',
        es: 'Formula hipótesis científicas complejas, rebate teorías empíricas opuestas y participa en debates intelectuales de alto nivel.'
      },
      content: 'Es steht außer Frage, dass die zugrunde gelegten Prämissen einer methodenkritischen Überprüfung bedürfen.',
      audioText: 'In Anbetracht der aktuellen Forschungslage lässt sich die Hypothese nicht länger aufrechterhalten.',
      practiceTasks: [
        'Halten Sie einen fünfminütigen wissenschaftlichen Impulsvortrag zu einem aktuellen Forschungsthema.',
        'Nutzen Sie differenzierte Redemittel wie "Dies lässt den Schluss zu, dass...", "Hieran anknüpfend...".'
      ]
    },
    sectionB: {
      title: 'Mussawi B: Wortschatz & Hören',
      focus: 'Hören & Wortschatz (Wissenschaftliche Interviews & Radiobeiträge)',
      description: {
        en: 'Comprehend nuanced radio interviews on Deutschlandfunk concerning philosophy of science and epistemology.',
        fa: 'درک مصاحبه‌های رادیویی عمیق شبکه دویچلندفونک در باب فلسفه علم و معرفت‌شناسی.',
        prs: 'فهم مصاحبه‌های تخصصی رادیویی علمی در مورد فلسفه علم و شناخت.',
        tr: 'Deutschlandfunk\'taki bilim felsefesi ve epistemoloji üzerine derinlikli radyo mülakatlarını kavrayın.',
        ar: 'فهم المقابلات الإذاعية المتعمقة عبر إذاعة دويتشلاندفونك حول فلسفة العلوم ونظرية المعرفة.',
        es: 'Comprende entrevistas radiofónicas de Deutschlandfunk sobre filosofía de la ciencia y epistemología.'
      },
      content: 'Das Spannungsverhältnis zwischen technologischem Determinismus und anthropologischer Handlungsautonomie.',
      practiceTasks: [
        'Dekodieren Sie implizite Haltungen und ironische Nuancen im Radio-Feature.',
        'Analysieren Sie Nomen-Verb-Verbindungen wie "zur Disposition stellen", "in Betracht ziehen".'
      ]
    },
    sectionC: {
      title: 'Mussawi C: Alltagskommunikation',
      focus: 'Sprechen & Dialoge (Wissenschaftliche Kolloquien & Moderation)',
      description: {
        en: 'Moderate academic panel sessions, synthesize contradictory viewpoints, and formulate overarching conclusions.',
        fa: 'مدیریت نشست‌های هم‌اندیشی دانشگاهی، ترکیب دیدگاه‌های متناقض و استنتاج جمع‌بندی‌های جامع.',
        prs: 'مدیریت سیمینارهای علمی، هماهنگی دیدگاه‌های مختلف و نتیجه‌گیری کلی.',
        tr: 'Akademik oturumları yönetin, çelişkili görüşleri sentezleyin ve kapsamlı sonuçlar çıkarın.',
        ar: 'إدارة الجلسات الحوارية الأكاديمية، والجمع بين وجهات النظر المتناقضة، وصياغة استنتاجات شاملة.',
        es: 'Modera paneles académicos, sintetiza opiniones contrapuestas y formula conclusiones globales.'
      },
      content: 'Darf ich die Diskussion dahingehend zusammenfassen, dass Einigkeit hinsichtlich der Dringlichkeit besteht?',
      audioText: 'Lassen Sie uns nun die methodischen Einwände der Kollegin im Detail erörtern.',
      practiceTasks: [
        'Moderieren Sie eine simulierte Diskussionsrunde über Bioethik und Gentechnik.',
        'Strukturieren Sie Beiträge durch metakommunikative Überleitungen.'
      ]
    },
    sectionD: {
      title: 'Mussawi D: Leseverstehen & Text',
      focus: 'Lesen & Textanalyse (FAZ-Feuilleton & Wissenschaftsessays)',
      description: {
        en: 'Deconstruct a sophisticated essay from the Frankfurter Allgemeine Zeitung (FAZ) regarding public sphere transformation.',
        fa: 'تحلیل موشکافانه مقاله‌ای عمیق از بخش اندیشه روزنامه معتبر فرانکفورتر آلگماینه درباره تحول دیجیتال حوزه عمومی.',
        prs: 'تحلیل مقاله مسلکی روزنامه مشهور FAZ درباره تاثیر انترنت بر جامعه و دموکراسی.',
        tr: 'Frankfurter Allgemeine Zeitung (FAZ) kültür sayfasındaki kamusal alanın dijitalleşmesi makalesini çözümleyin.',
        ar: 'تحليل مقال فكري معمق من صحيفة فرانكفورتر ألغماينه حول التحولات الرقمية للفضاء العام.',
        es: 'Analiza un ensayo de la sección cultural de FAZ sobre la esfera pública digital.'
      },
      content: 'Feuilletonistischer Essay über Habermas und die deliberative Demokratie im Netzzeitalter.',
      readingText: {
        type: 'Feuilleton der Frankfurter Allgemeinen Zeitung (FAZ)',
        title: 'Die Fragmentierung der Öffentlichkeit: Deliberation im Zeitalter der Algorithmen',
        body: 'Die vordem von klassischen Leitmedien strukturierte öffentliche Meinungsbildung weicht zunehmend einer von intransparenten Feedbackschleifen gesteuerten Partikularisierung. Wo einst der zwanglose Zwang des besseren Arguments galt, dominieren heute affektgeladene Aufmerksamkeitsökonomien.'
      },
      practiceTasks: [
        'Erörtern Sie den Begriff "affektgeladene Aufmerksamkeitsökonomien" im Kontext des Textes.',
        'Verfassen Sie einen kritischen Kommentar zur Relevanz der Diskurstheorie für Online-Plattformen.'
      ]
    },
    sectionE: {
      title: 'Mussawi E: Grammatik & Schreiben',
      focus: 'Grammatik & Schreiben (Erweiterte Partizipialattribute)',
      description: {
        en: 'Transform complex relative clauses into dense participial attributes placed between article and noun.',
        fa: 'تبدیل جملات موصولی فرعی به صفات فاعلی و مفعولی گسترش‌یافته واقع در بین آرتیکل و اسم.',
        prs: 'تبدیل جملات نسبتی فرعی به صفات مفعولی و فاعلی پربار مابین آرتیکل و اسم.',
        tr: 'İlgi cümlelerini isim ve artikeli arasına yerleşen zengin ortaç öbeklerine dönüştürün.',
        ar: 'تحويل الجمل الموصولة المعقدة إلى صفات اسمية ممتدة موضوعة بين أداة التعريف والاسم.',
        es: 'Transforma subordinadas de relativo en atributos participiales densos entre artículo y sustantivo.'
      },
      content: 'Partizipialattribut: Artikel + [Erweiterung + Partizip I / II (dekliniert)] + Nomen.',
      grammarRule: {
        id: 'c1_1_partizip_rule',
        level: 'C1.1',
        germanTitle: 'Erweiterte Partizipialattribute (Verdichtung von Relativsätzen)',
        formula: 'Artikel + [Erweiterung / Adverbiale Bestimmung + Partizip I/II (dekliniert)] + Nomen',
        explanation: {
          en: 'Compress relative clauses into attributive participial constructions situated between the definite/indefinite article and the head noun.',
          fa: 'فشرده‌سازی جملات موصولی به ساختارهای وصفی پیوسته که مابین حرف تعریف و اسم اصلی جای می‌گیرند.',
          prs: 'خلاصه کردن جملات توضیحی فرعی به ترکیب‌های صفتی پیش از اسم اصلی.',
          tr: 'İlgi cümlelerini artikel ile isim arasına sıkıştırılan genişletilmiş ortaç yapılarına dönüştürün.',
          ar: 'ضغط الجمل الموصولة إلى تراكيب نعتية اسمية موضوعة بين أداة التعريف والاسم الأساسي.',
          es: 'Condensa oraciones de relativo en estructuras participiales atributivas entre el artículo y el sustantivo.'
        },
        examples: [
          {
            german: 'Die seit mehreren Jahren kontrovers debattierte Reform wurde schließlich verabschiedet.',
            formulaBreakdown: 'Die (Art) + [seit mehreren Jahren kontrovers (Adv) + debattierte (Partizip II)] + Reform (Nomen) + wurde verabschiedet.',
            literalTranslation: {
              en: 'The since several years controversially debated reform was finally adopted.',
              fa: 'اصلاحات از چندین سال به صورت بحث‌برانگیز مورد مناقشه واقع شده سرانجام تصویب شد.',
              prs: 'اصلاحاتی که از سال‌ها پیش مورد اختلاف بود، بالاخره تصویب شد.',
              tr: 'Birkaç yıldır tartışmalı şekilde münazara edilen reform nihayet kabul edildi.',
              ar: 'تمت أخيراً المصادقة على الإصلاح الذي نوقش بشكل مثير للجدل منذ سنوات عدة.',
              es: 'La desde hace varios años controvertidamente debatida reforma fue finalmente aprobada.'
            },
            fluentTranslation: {
              en: 'The reform, which had been the subject of contentious debate for several years, was ultimately passed.',
              fa: 'اصلاحاتی که چندین سال موضوع مباحثات جنجالی بود، سرانجام به تصویب رسید.',
              prs: 'طرح اصلاحی که سال‌ها بحث روی آن جریان داشت، سرانجام منظور گردید.',
              tr: 'Yıllardır hararetli tartışmalara konu olan yasa tasarısı nihayet onaylandı.',
              ar: 'أُقرَّ في نهاية المطاف مشروع الإصلاح الذي كان محل نقاش محتدم على مدار سنوات.',
              es: 'La reforma, ampliamente debatida durante varios años, fue finalmente aprobada.'
            }
          }
        ]
      },
      practiceTasks: [
        'Formen Sie vier Relativsätze in erweiterte Partizipialattribute um.',
        'Verfassen Sie ein akademisches Abstract (150 Wörter) zu einer soziologischen Untersuchung.'
      ]
    },
    vocabularies: [
      { id: 'c1_1_v1', word: 'das Paradigma', article: 'das', plural: 'die Paradigmen', ipa: '/paʁaˈdɪɡma/', translation: { en: 'paradigm', fa: 'پارادایم / الگوی فکری بنیادین', prs: 'چارچوب فکری و نظریه اساسی', tr: 'paradigma', ar: 'النموذج الفكري / النموذج الإرشادي', es: 'paradigma' } },
      { id: 'c1_1_v2', word: 'die Prämisse', article: 'die', plural: 'die Prämissen', ipa: '/pʁɛˈmɪsə/', translation: { en: 'premise', fa: 'پیش‌فرض / مقدمه استدلال', prs: 'پیش‌شرط یا فرض اولیه', tr: 'öncül / varsayım', ar: 'المقدمة المنطقية / الفرضية', es: 'premisa' } },
      { id: 'c1_1_v3', word: 'die Intersubjektivität', article: 'die', plural: '-', ipa: '/ˌɪntɐzʊbjɛktiviˈtɛːt/', translation: { en: 'intersubjectivity', fa: 'بین‌الاذهانی بودن', prs: 'توافق فکری جمعی دانشمندان', tr: 'öznelerarasılık', ar: 'الذاتية المشتركة / التذاوت', es: 'intersubjetividad' } }
    ],
    exercises: [
      {
        id: 'ex_c1_1_1',
        type: 'multiple_choice',
        instruction: {
          en: 'Select the grammatically accurate extended participial attribute.',
          fa: 'صفت گسترش‌یافته فاعلی یا مفعولی صحیح را انتخاب نمایید.',
          prs: 'ساختار دستوری درست صفت پیش از اسم را تعیین کنید.',
          tr: 'Gramer açısından kusursuz genişletilmiş ortaç yapısını seçiniz.',
          ar: 'حدد النعت الممتد الدقيق لغوياً.',
          es: 'Selecciona el atributo participial extendido gramaticalmente correcto.'
        },
        prompt: 'Which construction correctly translates "the report published yesterday by the institute"?',
        options: [
          'der gestern vom Institut veröffentlichte Bericht',
          'der gestern veröffentlichte vom Institut Bericht',
          'der Bericht gestern vom Institut veröffentlicht',
          'der vom Institut gestern Bericht veröffentlichte'
        ],
        correctAnswer: 'der gestern vom Institut veröffentlichte Bericht',
        explanation: {
          en: 'The entire adverbial specification (gestern vom Institut) and the declined participle (veröffentlichte) must stand strictly between the definite article (der) and the noun (Bericht).',
          fa: 'تمامی متمم‌های قیدی و صفت مفعولی صرف‌شده باید دقیقاً بین آرتیکل و اسم قرار گیرند.',
          prs: 'تمامی کلمات قیدی و صفت مفعولی باید بین آرتیکل و اسم اصلی واقع شوند.',
          tr: 'Tüm belirteçler ve çekimlenmiş Partizip II ("veröffentlichte"), artikel ("der") ile isim ("Bericht") arasına yerleşmelidir.',
          ar: 'يجب أن تقع كافة الظروف وشبه الجمل والاسم المفعول المصرف بين أداة التعريف والاسم الرئيسي حصراً.',
          es: 'Todos los complementos adverbiales y el participio declinado ("veröffentlichte") deben ubicarse estrictamente entre el artículo ("der") y el sustantivo ("Bericht").'
        }
      }
    ]
  },
  {
    id: 'c1_1_lek2',
    lektionNumber: 2,
    level: 'C1.1',
    title: 'Makroökonomie, Geldpolitik und Außenhandel',
    subTitle: 'Zentralbankpolitik, Handelsbilanzen und Nomen-Verb-Verbindungen (C1 Niveau)',
    topic: 'Leitzins, Währungsstabilität, Fiskalpolitik und Funktionsverbgefüge im Wirtschaftsdeutsch',
    fotoHoergeschichte: {
      title: 'Foto-Hörgeschichte: Pressekonferenz der Europäischen Zentralbank in Frankfurt',
      imagePrompt: 'The modern glass auditorium of the European Central Bank in Frankfurt am Main where financial journalists attend an interest rate policy press briefing.',
      imageTheme: 'EZB Frankfurt am Main',
      audioDuration: '03:20',
      transcript: [
        { speaker: 'EZB-Präsidentin', text: 'Der EZB-Rat hat heute beschlossen, die Leitzinsen um 25 Basispunkte anzuheben, um der hartnäckigen Teuerungsrate Einhalt zu gebieten.' },
        { speaker: 'Handelsblatt-Korrespondent', text: 'Frau Präsidentin, ziehen Sie in Erwägung, dass diese geldpolitische Straffung die Investitionstätigkeit des produzierenden Gewerbes empfindlich schwächen könnte?' },
        { speaker: 'EZB-Präsidentin', text: 'Wir behalten sämtliche volkswirtschaftlichen Indikatoren im Blick und bringen vorrangig die Preisstabilität zur Geltung.' }
      ],
      summary: {
        en: 'The ECB press conference in Frankfurt discusses interest rate hikes, inflation targeting, and economic stabilization using fixed noun-verb collocations.',
        fa: 'نشست خبری بانک مرکزی اروپا در فرانکفورت به بحث درباره افزایش نرخ بهره، مهار تورم و ثبات اقتصادی با استفاده از اصطلاحات اسمی-فعلی می‌پردازد.',
        prs: 'کنفرانس مطبوعاتی بانک مرکزی اروپا در فرانکفورت درباره بالا بردن مفاد بانکی و کنترول تورم اقتصادی بحث می‌کند.',
        tr: 'Frankfurt\'taki AMB basın toplantısında faiz artışları, enflasyon hedeflemesi ve ekonomik istikrar ele alınır.',
        ar: 'المؤتمر الصحفي للبنك المركزي الأوروبي في فرانكفورت يناقش رفع أسعار الفائدة واستهداف التضخم والاستقرار الاقتصادي.',
        es: 'Rueda de prensa del BCE en Fráncfort sobre tipos de interés, control inflacionario y estabilidad económica.'
      }
    },
    sectionA: {
      title: 'Mussawi A: Sprechen & Dialog',
      focus: 'Sprechen & Hören (Wirtschaftsanalysen & Debatten)',
      description: {
        en: 'Analyze macroeconomic policies, interest rate mechanisms, and fiscal interventions with executive fluency.',
        fa: 'تحلیل سیاست‌های اقتصاد کلان، سازوکارهای نرخ بهره و مداخلات مالی دولت با فصاحت در سطح مدیران ارشد.',
        prs: 'تحلیل دقیق مسایل اقتصاد کلان و سیاست‌های پولی و مالی در سطح عالی مسلکی.',
        tr: 'Makroekonomik politikaları, faiz mekanizmalarını ve mali müdahaleleri yönetici akıcılığında analiz edin.',
        ar: 'تحليل السياسات الاقتصادية الكلية، وآليات أسعار الفائدة، والتدخلات المالية بفصاحة تنفيذية رفيعة.',
        es: 'Análisis de políticas macroeconómicas, mecanismos de tipos de interés y medidas fiscales.'
      },
      content: 'Die Zinspolitik der Notenbank übt beträchtlichen Einfluss auf die Kreditvergabe aus.',
      audioText: 'Es gilt zu prüfen, inwieweit die fiskalischen Anreize zu einer nachhaltigen Belebung des Binnenmarkts beitragen.',
      practiceTasks: [
        'Diskutieren Sie die Vor- und Nachteile einer expansiven Geldpolitik.',
        'Verwenden Sie Nomen-Verb-Verbindungen wie "zur Sprache bringen", "eine Entscheidung treffen".'
      ]
    },
    sectionB: {
      title: 'Mussawi B: Wortschatz & Hören',
      focus: 'Hören & Wortschatz (Finanzmärkte & Volkswirtschaft)',
      description: {
        en: 'High-level financial vocabulary: fiscal stimulus, stagflation, foreign direct investment, and trade surplus.',
        fa: 'واژگان سطح بالای مالی: بسته‌های محرک مالی، رکود تورمی، سرمایه‌گذاری مستقیم خارجی و مازاد تراز تجاری.',
        prs: 'لغات پیشرفته مالی: سرمایه‌گذاری خارجی، رشد تورم و تراز تجارتی بین‌المللی.',
        tr: 'İleri düzey finansal terimler: mali teşvik, stagflasyon, doğrudan yabancı yatırım ve ticaret fazlası.',
        ar: 'المصطلحات المالية الرفيعة: التحفيز المالي، الركود التضخمي، الاستثمار الأجنبي المباشر، وفائض الميزان التجاري.',
        es: 'Léxico financiero de alto nivel: estímulo fiscal, estanflación, inversión extranjera directa y superávit comercial.'
      },
      content: 'die Stagflation, die Handelsbilanz, der Leitzins, die Bonität, die Konjunkturprognose.',
      practiceTasks: [
        'Erläutern Sie die Kausalität zwischen Zinserhöhungen und Wechselkursbewegungen.',
        'Erstellen Sie eine Synopse zu den aktuellen Konjunkturindikatoren.'
      ]
    },
    sectionC: {
      title: 'Mussawi C: Alltagskommunikation',
      focus: 'Sprechen & Dialoge (Strategiemeetings & Vorstandspräsentationen)',
      description: {
        en: 'Boardroom interactions, articulating financial risk assessments and strategic hedging options.',
        fa: 'تعاملات اتاق جلسات هیئت مدیره، تبیین ارزیابی ریسک‌های مالی و راهکارهای پوشش ریسک ارزی.',
        prs: 'جلسات رهبری شرکت‌ها، توضیح خطرات مالی و پلان‌های احتیاطی اقتصادی.',
        tr: 'Yönetim kurulu toplantılarında finansal risk değerlendirmeleri ve riskten korunma stratejileri sunma.',
        ar: 'تفاعلات مجالس الإدارة، وصياغة تقييمات المخاطر المالية واستراتيجيات التحوط المالي.',
        es: 'Reuniones de consejo directivo, evaluación de riesgos financieros y coberturas estratégicas.'
      },
      content: 'Wir müssen die möglichen Währungsrisiken zwingend in Rechnung stellen.',
      audioText: 'Angesichts der geopolitischen Friktionen sollten wir eine Diversifizierung unserer Beschaffungsmärkte ins Auge fassen.',
      practiceTasks: [
        'Simulieren Sie eine Vorstandssitzung zur Verabschiedung des Investitionsbudgets.',
        'Entkräften Sie skeptische Nachfragen zu Renditeerwartungen.'
      ]
    },
    sectionD: {
      title: 'Mussawi D: Leseverstehen & Text',
      focus: 'Lesen & Textanalyse (Handelsblatt & Bundesbank-Monatsbericht)',
      description: {
        en: 'Analyze comprehensive articles from the Deutsche Bundesbank Monthly Report and Handelsblatt.',
        fa: 'تحلیل مقالات تفصیلی گزارش ماهانه دویچه بوندس‌بانک (بانک مرکزی آلمان) و روزنامه اقتصادی هندلزبلات.',
        prs: 'مطالعه و تحلیل گزارش‌های ماهوار بانک فدرال آلمان و نشریات اقتصادی بین‌المللی.',
        tr: 'Deutsche Bundesbank Aylık Raporu ve Handelsblatt\'tan kapsamlı analizleri irdeleme.',
        ar: 'تحليل المقالات المتعمقة من التقرير الشهري للبنك المركزي الألماني وصحيفة هاندلسبلات.',
        es: 'Análisis de artículos exhaustivos del Informe Mensual del Deutsche Bundesbank y Handelsblatt.'
      },
      content: 'Wirtschaftsanalytischer Text zur Transformation der deutschen Exportwirtschaft.',
      readingText: {
        type: 'Monatsbericht der Deutschen Bundesbank',
        title: 'Strukturwandel im verarbeitenden Gewerbe unter dem Einfluss globaler Zinszyklen',
        body: 'Die deutsche Exportindustrie sieht sich mit mehrfachen Herausforderungen konfrontiert. Neben der verhaltenen Weltkonjunktur belasten höhere Finanzierungskosten die Investitionsbereitschaft mittelständischer Unternehmen. Dennoch erweist sich die technologische Innovationskraft als resilienter Stützpfeiler.'
      },
      practiceTasks: [
        'Destillieren Sie die drei primären Wachstumshemmnisse aus dem Text heraus.',
        'Verfassen Sie ein Executive Summary für die Geschäftsleitung.'
      ]
    },
    sectionE: {
      title: 'Mussawi E: Grammatik & Schreiben',
      focus: 'Grammatik & Schreiben (Nomen-Verb-Verbindungen / Funktionsverbgefüge)',
      description: {
        en: 'Master sophisticated noun-verb collocations (Funktionsverbgefüge) essential for executive German and C1 exams.',
        fa: 'تسلط بر اصطلاحات اسمی-فعلی با افعال خنثی (Funktionsverbgefüge) ضروری برای آلمانی تجاری و آزمون‌های C1.',
        prs: 'تسلط بر افعال ترکیبی اسمی پیشرفته برای محیط‌های کاری رسمی و امتحانات سطح C1.',
        tr: 'Yönetici düzeyinde Almanca ve C1 sınavları için hayati önem taşıyan kalıplaşmış isim-fiil bağdaşımları.',
        ar: 'إتقان التراكيب الاسمية الفعلية الاصطلاحية (Funktionsverbgefüge) اللازمة للألمانية الإدارية وامتحانات C1.',
        es: 'Dominio de combinaciones léxicas nominales con verbos funcionales esenciales en nivel C1.'
      },
      content: 'Nomen-Verb-Verbindungen: in Erwägung ziehen (= erwägen), zur Verfügung stehen (= verfügbar sein), Kritik üben an (= kritisieren).',
      grammarRule: {
        id: 'c1_1_nvv_rule',
        level: 'C1.1',
        germanTitle: 'Nomen-Verb-Verbindungen (Funktionsverbgefüge)',
        formula: 'Präposition + Nomen + Funktionsverb (z. B. "in Anspruch nehmen", "in Zweifel ziehen")',
        explanation: {
          en: 'Noun-verb combinations replace simple verbs in administrative, journalistic, and academic language to express subtle nuances of aspect, inception, or causation.',
          fa: 'ترکیب‌های اسم و فعل، جایگزین افعال ساده در متون اداری، دانشگاهی و ژورنالیستی می‌شوند تا مفاهیم ظریف دستوری، آغازین یا سببی را با دقت بیان کنند.',
          prs: 'این ساختارهای اسمی-فعلی در نوشتار اداری و دانشگاهی جای افعال ساده را می‌گیرند تا متن را شسته‌ورفته و مسلکی بسازند.',
          tr: 'İsim-fiil kalıpları, resmi, akademik ve basın dilinde sade fiillerin yerini alarak anlamı inceltir.',
          ar: 'تحل التراكيب الاسمية الفعلية محل الأفعال البسيطة في اللغة الإدارية والصحفية والأكاديمية لإضفاء دقة أسلوبية رفيعة.',
          es: 'Las colocaciones nominal-verbales sustituyen a los verbos simples en registros administrativos, formales y académicos.'
        },
        examples: [
          {
            german: 'Die Geschäftsführung zog eine Umstrukturierung des Unternehmens ernsthaft in Erwägung.',
            formulaBreakdown: 'Die Geschäftsführung (S) + zog (Funktionsverb) + [eine Umstrukturierung (Akk)] + in Erwägung (Nomen-Verb-Verbindung = erwog).',
            literalTranslation: {
              en: 'The executive management pulled a restructuring of the enterprise seriously into consideration.',
              fa: 'هیئت مدیره تجدید ساختار شرکت را به طور جدی مد نظر قرار داد.',
              prs: 'رهبری شرکت تغییرات در ساختار اداره را به گونه جدی زیر بررسی گرفت.',
              tr: 'Yönetim şirketin yeniden yapılandırılmasını ciddi biçimde değerlendirmeye aldı.',
              ar: 'وضعت الإدارة العليا إعادة هيكلة الشركة في دائرة الاعتبار الجاد.',
              es: 'La dirección tomó seriamente en consideración una reestructuración de la empresa.'
            },
            fluentTranslation: {
              en: 'The executive management gave serious consideration to restructuring the company.',
              fa: 'هیئت مدیره تجدید ساختار شرکت را با دقت تمام مورد بررسی و ارزیابی قرار داد.',
              prs: 'رهبری نهاد ساختار جدید تشکیلات را به دقت ارزیابی نمود.',
              tr: 'Şirket yönetimi kurumsal yeniden yapılanmayı derinlemesine değerlendirdi.',
              ar: 'درست الإدارة التنفيذية خيار إعادة هيكلة المؤسسة دراسة متأنية وشاملة.',
              es: 'La directiva consideró minuciosamente acometer una reestructuración de la compañía.'
            }
          }
        ]
      },
      practiceTasks: [
        'Ersetzen Sie in einem Text 8 einfache Verben durch adäquate Nomen-Verb-Verbindungen.',
        'Schreiben Sie eine Wirtschaftskolumne (250 Wörter) über die Geldpolitik der EZB.'
      ]
    },
    vocabularies: [
      { id: 'c1_1_v4', word: 'der Leitzins', article: 'der', plural: 'die Leitzinsen', ipa: '/ˈlaɪ̯tˌt͡sɪns/', translation: { en: 'key interest rate / benchmark rate', fa: 'نرخ بهره پایه / نرخ بهره مبنا', prs: 'نرخ مفاد اساسی بانک مرکزی', tr: 'politika faizi / gösterge faiz', ar: 'سعر الفائدة الرئيسي', es: 'tipo de interés básico / tipo rector' } },
      { id: 'c1_1_v5', word: 'die Konjunkturbelebung', article: 'die', plural: 'die Konjunkturbelebungen', ipa: '/kɔnjʊŋkˈtuːɐ̯bəˌleːbʊŋ/', translation: { en: 'economic recovery / stimulus', fa: 'رونق و احیای مجدد اقتصادی', prs: 'شکوفایی و بهبود وضعیت اقتصادی', tr: 'ekonomik canlanma', ar: 'الانتعاش الاقتصادي', es: 'reactivación coyuntural' } },
      { id: 'c1_1_v6', word: 'in Erwägung ziehen', article: '', plural: '-', ipa: '/ɪn ɛɐ̯ˈvɛːɡʊŋ ˈt͡siːən/', translation: { en: 'to consider / take into account', fa: 'مد نظر قرار دادن / بررسی کردن', prs: 'در نظر گرفتن / سنجیدن', tr: 'dikkate almak / hesaba katmak', ar: 'يأخذ بعين الاعتبار', es: 'tomar en consideración' } }
    ],
    exercises: [
      {
        id: 'ex_c1_1_2',
        type: 'multiple_choice',
        instruction: {
          en: 'Select the equivalent Noun-Verb collocation for "kritisieren".',
          fa: 'معادل اسمی-فعلی (Funktionsverbgefüge) برای فعل "kritisieren" را برگزینید.',
          prs: 'معادل اصطلاح اسمی برای فعل انتقاد کردن (kritisieren) را انتخاب کنید.',
          tr: '"kritisieren" fiiline denk gelen doğru isim-fiil bağdaşımını seçiniz.',
          ar: 'اختر التركيب الاسمي الفعلي المرادف للفعل "kritisieren".',
          es: 'Selecciona la colocación verbal equivalente a "kritisieren".'
        },
        prompt: 'Welche Nomen-Verb-Verbindung bedeutet "kritisieren"?',
        options: [
          'Kritik üben an (+ Dativ)',
          'in Kritik stehen für',
          'zur Kritik bringen',
          'auf Kritik beharren'
        ],
        correctAnswer: 'Kritik üben an (+ Dativ)',
        explanation: {
          en: '"Kritik üben an (+ Dativ)" is the standard high-register collocation meaning "jemanden/etwas kritisieren".',
          fa: 'ترکیب "Kritik üben an (+ Dativ)" فرم رسمی و فاخر در سطح C1 برای انتقاد کردن از چیزی یا کسی است.',
          prs: 'اصطلاح "Kritik üben an" دقیق‌ترین ترکیب رسمی به معنای انتقاد نمودن می‌باشد.',
          tr: '"Kritik üben an (+ Dativ)", "birini/bir şeyi eleştirmek" anlamında standart üst düzey ifadedir.',
          ar: 'التركيب "Kritik üben an (+ Dativ)" هو المصطلح الرصين المعتمد في الفصحى بمعنى "ينتقد فلاناً أو أمراً ما".',
          es: '"Kritik üben an (+ Dativo)" es la colocación formal habitual para "criticar a alguien/algo".'
        }
      }
    ]
  },
  {
    id: 'c1_1_lek3',
    lektionNumber: 3,
    level: 'C1.1',
    title: 'Bioethik, Biomedizin und Rechtsethik',
    subTitle: 'Genom-Editierung, Organallokation und Passiversatzformen (C1 Niveau)',
    topic: 'Klonen, CRISPR-Cas, Ethikrat und modale Infinitive (sein/haben + zu + Infinitiv)',
    fotoHoergeschichte: {
      title: 'Foto-Hörgeschichte: Plenarsitzung des Deutschen Ethikrates in Berlin',
      imagePrompt: 'The solemn meeting chamber of the German Ethics Council in Berlin where medical ethicists, legal scholars, and geneticists debate ethical boundaries.',
      imageTheme: 'Deutscher Ethikrat Berlin',
      audioDuration: '03:10',
      transcript: [
        { speaker: 'Vorsitzende des Ethikrates', text: 'Die ethischen Implikationen der Keimbahntherapie sind von herausragender Tragweite für künftige Generationen.' },
        { speaker: 'Prof. Dr. Molekularbiologe', text: 'Diese Methoden sind als potenziell lebensrettende Meilensteine bei monogenetischen Erbkrankheiten einzustufen.' },
        { speaker: 'Frau Dr. Philosophin', text: 'Gleichwohl ist der Vorrang der Menschenwürde strikt zu wahren; instrumentalisierende Eingriffe sind unter allen Umständen zu unterlassen.' }
      ],
      summary: {
        en: 'The German Ethics Council debates germline editing, human dignity, and regulatory safeguards using passive substitute forms.',
        fa: 'شورای اخلاق زیستی آلمان به بحث درباره اصلاح ژنتیکی جنین، کرامت انسانی و مرزهای قانونی با ساختارهای جانشین مجهول می‌پردازد.',
        prs: 'شورای اخلاقی آلمان روی مسایل ژنتیکی و کرامت انسانی با ساختارهای پیشرفته بدل مجهول بحث می‌نماید.',
        tr: 'Alman Etik Kurulu, kök hücre müdahalelerini ve insan onurunu edilgen çatı alternatifleriyle ele alıyor.',
        ar: 'يناقش المجلس الألماني للأخلاقيات التعديل الجيني والكرامة الإنسانية باستخدام صيغ بدائل المجهول.',
        es: 'El Consejo de Ética Alemán debate sobre edición genética y dignidad humana con sustitutos de la pasiva.'
      }
    },
    sectionA: {
      title: 'Mussawi A: Sprechen & Dialog',
      focus: 'Sprechen & Hören (Ethische Dilemmata & Argumentation)',
      description: {
        en: 'Defend moral philosophical arguments in bioethical debates with nuanced ethical vocabulary.',
        fa: 'دفاع از استدلال‌های فلسفه اخلاق در مناظرات اخلاق زیستی با واژگان عمیق فلسفی.',
        prs: 'دفاع از ارزش‌های اخلاقی و حقوق بشری در مباحثات مسلکی با اصطلاحات فلسفی.',
        tr: 'Biyoetik tartışmalarda ahlak felsefesi savlarını incelikli kavramlarla savunma.',
        ar: 'الدفاع عن الحجج الفلسفية الأخلاقية في مناظرات الأخلاقيات الحيوية بمفردات فلسفية راقية.',
        es: 'Defensa de argumentos de filosofía moral en dilemas bioéticos con léxico conceptual.'
      },
      content: 'Aus deontologischer Perspektive verbietet sich eine Güterabwägung gegen die Unantastbarkeit der Menschenwürde.',
      audioText: 'Es ist unabdingbar zu klären, welche Eingriffe gesellschaftlich konsensfähig sind.',
      practiceTasks: [
        'Erläutern Sie den Unterschied zwischen Utilitarismus und Pflichtethik anhand eines Fallbeispiels.',
        'Verfassen Sie eine Stellungnahme zu den Grenzen der Pränataldiagnostik.'
      ]
    },
    sectionB: {
      title: 'Mussawi B: Wortschatz & Hören',
      focus: 'Hören & Wortschatz (Biotechnologie & Bioethik)',
      description: {
        en: 'Terminology of genetics, clinical trials, ethical review boards, and jurisprudence.',
        fa: 'واژگان تخصصی ژنتیک، کارآزمایی‌های بالینی، کمیته‌های اخلاق پزشکی و فلسفه حقوق.',
        prs: 'لغات تخصصی ژنتیک، آزمایش‌های کلینیکی و حقوق انسانی در علم طبابت.',
        tr: 'Genetik, klinik araştırmalar, etik kurullar ve hukuk felsefesi terminolojisi.',
        ar: 'مصطلحات علم الوراثة، التجارب السريرية، لجان الأخلاقيات الطبية وفلسفة القانون.',
        es: 'Léxico especializado en genética, ensayos clínicos, comités de ética y jurisprudencia.'
      },
      content: 'die Keimbahntherapie, die Menschenwürde, die Güterabwägung, das Klonen, der Gesetzesentwurf.',
      practiceTasks: [
        'Unterscheiden Sie deskriptive von normativen Aussagen in einem Fachtext.',
        'Ordnen Sie bioethische Fallstudien den entsprechenden Grundrechten zu.'
      ]
    },
    sectionC: {
      title: 'Mussawi C: Alltagskommunikation',
      focus: 'Sprechen & Dialoge (Parlamentarische Anhörung im Bundestag)',
      description: {
        en: 'Testify as an expert witness in parliamentary hearings regarding bioethics legislation.',
        fa: 'شهادت کارشناسی در جلسات استماع پارلمانی بوندس‌تاگ پیرامون قوانین اخلاق زیستی.',
        prs: 'ارائه نظر تخصصی در جلسات پارلمان درباره قوانین جدید علمی و صحی.',
        tr: 'Biyoetik mevzuatı üzerine meclis komisyonunda bilirkişi olarak ifade verme.',
        ar: 'تقديم شهادة الخبراء في جلسات الاستماع البرلمانية بشأن تشريعات الأخلاقيات الحيوية.',
        es: 'Intervención como perito en audiencias parlamentarias sobre bioética y salud.'
      },
      content: 'Die Risiken sind als unkalkulierbar einzustufen, weshalb ein Moratorium geboten erscheint.',
      audioText: 'Der Gesetzgeber ist aufgerufen, verbindliche ethische Leitplanken zu definieren.',
      practiceTasks: [
        'Simulieren Sie ein Sachverständigengutachten vor dem Bundestagsausschuss.',
        'Entgegnen Sie juristischen Bedenken souverän und präzise.'
      ]
    },
    sectionD: {
      title: 'Mussawi D: Leseverstehen & Text',
      focus: 'Lesen & Textanalyse (Stellungnahme des Ethikrates)',
      description: {
        en: 'Analyze official statements and policy recommendations published by the German Ethics Council.',
        fa: 'تحلیل بیانیه‌های رسمی و توصیه‌های سیاستی منتشرشده توسط شورای اخلاق زیستی آلمان.',
        prs: 'بررسی بیانیه‌های حقوقی و علمی شورای عالی اخلاق آلمان.',
        tr: 'Alman Etik Kurulu\'nun yayımladığı resmi görüşleri ve tavsiye kararlarını inceleme.',
        ar: 'تحليل البيانات الرسمية وتوصيات السياسات الصادرة عن المجلس الألماني للأخلاقيات.',
        es: 'Análisis de dictámenes oficiales y recomendaciones del Consejo de Ética Alemán.'
      },
      content: 'Auszug aus einer Ad-hoc-Empfehlung des Deutschen Ethikrates.',
      readingText: {
        type: 'Empfehlung des Deutschen Ethikrates',
        title: 'Mensch und Maschine: Herausforderungen durch generative KI und autonome Systeme',
        body: 'Die Zuschreibung von Handlungsfähigkeit und moralischer Verantwortung an Algorithmen ist kategorisch zurückzuweisen. Verantwortlich bleibt stets das handelnde menschliche Subjekt. Der Gesetzgeber hat dafür Sorge zu tragen, dass die Kontrollierbarkeit autonomer Systeme zu jedem Zeitpunkt gewährleistet ist.'
      },
      practiceTasks: [
        'Analysieren Sie die Argumentationskette der Stellungnahme.',
        'Schreiben Sie eine kritische Erörterung zum Thema "KI in der klinischen Diagnostik".'
      ]
    },
    sectionE: {
      title: 'Mussawi E: Grammatik & Schreiben',
      focus: 'Grammatik & Schreiben (Passiversatzformen: sein + zu + Infinitiv, -bar, -lich, sich lassen)',
      description: {
        en: 'Master sophisticated alternatives to passive voice: "sein + zu + Infinitiv" (müssen/können), "sich lassen + Infinitiv", and suffixes "-bar" and "-lich".',
        fa: 'تسلط بر ساختارهای جایگزین مجهول: ترکیب "sein + zu + مصدر" (بیانگر ضرورت یا امکان)، "sich lassen + مصدر" و پسوندهای "-bar" و "-lich".',
        prs: 'تسلط بر بدل‌های ساختار مجهول: sein + zu + مصدر و پسوندهای علمی مانند bar و lich.',
        tr: 'Edilgen çatı alternatifleri: "sein + zu + mastar", "sich lassen + mastar" ve "-bar / -lich" yapılarında ustalaşma.',
        ar: 'إتقان بدائل صيغة المبني للمجهول: التركيب "sein + zu + المصدر" وصيغة "sich lassen" واللواحق "-bar" و"-lich".',
        es: 'Dominio de sustitutos de la pasiva: "sein + zu + infinitivo", "sich lassen" y adjetivos en "-bar/-lich".'
      },
      content: 'Passiversatzformen: "Das Problem ist zu lösen" (= muss/kann gelöst werden) / "Die Daten lassen sich verifizieren" (= können verifiziert werden).',
      grammarRule: {
        id: 'c1_1_passiversatz_rule',
        level: 'C1.1',
        germanTitle: 'Die Passiversatzformen (Passivalternativen)',
        formula: 'sein + zu + Infinitiv | sich lassen + Infinitiv | Adjektive auf -bar / -lich',
        explanation: {
          en: '"sein + zu + Infinitiv" expresses necessity (müssen) or possibility (können). "sich lassen + Infinitiv" expresses possibility (können). Adjectives ending in -bar or -lich express capability.',
          fa: 'ترکیب "sein + zu + مصدر" بیانگر الزام (müssen) یا امکان (können) است. ترکیب "sich lassen + مصدر" معادل مجهول با können است. صفات مختوم به -bar و -lich قابلیت انجام کار را نشان می‌دهند.',
          prs: 'ترکیب sein + zu + مصدر الزام یا امکان انجام کار را به شیوه بسیار رسمی نشان می‌دهد.',
          tr: '"sein + zu + mastar" zorunluluk (müssen) veya olasılık (können) bildirir. "sich lassen" ise olasılık ifade eder.',
          ar: 'التركيب "sein + zu + المصدر" يعبر عن الضرورة (müssen) أو الإمكانية (können)، وتركيب "sich lassen" يعبر عن الإمكانية.',
          es: '"sein + zu + infinitivo" expresa obligación o posibilidad; "sich lassen" denota posibilidad pasiva.'
        },
        examples: [
          {
            german: 'Diese ethischen Grundfragen sind im Lichte des Grundgesetzes neu zu bewerten.',
            formulaBreakdown: 'Diese Grundfragen (S) + sind (sein) + im Lichte des Grundgesetzes + neu zu bewerten (zu + Infinitiv = müssen neu bewertet werden).',
            literalTranslation: {
              en: 'These fundamental questions are in the light of the Basic Law newly to evaluate.',
              fa: 'این پرسش‌های بنیادین اخلاقی باید در پرتو قانون اساسی مجدداً ارزیابی شوند.',
              prs: 'این سوالات اساسی باید در روشنایی قانون اساسی از نو ارزیابی گردند.',
              tr: 'Bu temel sorular Anayasa ışığında yeniden değerlendirilmelidir.',
              ar: 'يتعين إعادة تقييم هذه المسائل الأخلاقية الجوهرية في ضوء أحكام القانون الأساسي.',
              es: 'Estas cuestiones éticas fundamentales deben ser evaluadas de nuevo a la luz de la Ley Fundamental.'
            },
            fluentTranslation: {
              en: 'These foundational ethical questions must be re-evaluated in the light of constitutional jurisprudence.',
              fa: 'این پرسش‌های بنیادین اخلاقی باید در پرتو احکام حقوق اساسی مجدداً ارزیابی و بازنگری شوند.',
              prs: 'این پرسش‌های اساسی اخلاق طبابت باید بر اساس اصول قانون اساسی دوباره سنجیده شوند.',
              tr: 'Bu temel ahlaki sorular anayasa ilkeleri çerçevesinde mutlak surette yeniden ele alınmalıdır.',
              ar: 'يجب بالضرورة إعادة تقييم هذه القضايا الأخلاقية الجوهرية على ضوء مبادئ الدستور.',
              es: 'Estas cuestiones morales primordiales han de reevaluarse preceptivamente conforme al marco constitucional.'
            }
          }
        ]
      },
      practiceTasks: [
        'Formulieren Sie vier Passivsätze mit "müssen" in "sein + zu + Infinitiv" um.',
        'Wandeln Sie "kann berechnet werden" in ein Adjektiv auf "-bar" um.'
      ]
    },
    vocabularies: [
      { id: 'c1_1_v7', word: 'die Güterabwägung', article: 'die', plural: 'die Güterabwägungen', ipa: '/ˈɡyːtɐʔapˌvɛːɡʊŋ/', translation: { en: 'balancing of conflicting interests/goods', fa: 'سنجش و موازنه‌سازی منافع متعارض در حقوق', prs: 'سنجش منافع متضاد بر بنیاد اصول قانون', tr: 'menfaatler dengesi / hukuki dengeleme', ar: 'الموازنة بين المصالح القانونية المتعارضة', es: 'ponderación de bienes jurídicos' } },
      { id: 'c1_1_v8', word: 'die Keimbahn', article: 'die', plural: 'die Keimbahnen', ipa: '/ˈkaɪ̯mˌbaːn/', translation: { en: 'germline', fa: 'خط زایای ژنتیکی جنین', prs: 'خط ژنتیکی بنیادی سلول‌های تکثیری', tr: 'eşey hattı', ar: 'الخط الجرثومي الوراثي', es: 'línea germinal' } },
      { id: 'c1_1_v9', word: 'unabdingbar', article: '', plural: '-', ipa: '/ˈʊnʔapˌdɪŋbaːɐ̯/', translation: { en: 'indispensable / imperative', fa: 'اجتناب‌ناپذیر / کاملاً ضروری', prs: 'حتمی و غیرقابل اجتناب', tr: 'vazgeçilmez / zorunlu', ar: 'لا غنى عنه / إلزامي قطعي', es: 'indispensable / imperativo' } }
    ],
    exercises: [
      {
        id: 'ex_c1_1_3',
        type: 'multiple_choice',
        instruction: {
          en: 'Transform the sentence into the passive substitute form "sein + zu + Infinitiv".',
          fa: 'جمله را با ساختار جانشین مجهول "sein + zu + Infinitiv" بازنویسی کنید.',
          prs: 'جمله را به شکل رسمی بدل مجهول تبدیل نمایید.',
          tr: 'Cümleyi "sein + zu + mastar" yapısına dönüştürünüz.',
          ar: 'حول الجملة إلى صيغة بديل المجهول "sein + zu + المصدر".',
          es: 'Transforma la oración empleando la estructura pasiva alternativa "sein + zu + infinitivo".'
        },
        prompt: 'Formen Sie um: "Man muss die Versuchsergebnisse sorgfältig dokumentieren."',
        options: [
          'Die Versuchsergebnisse sind sorgfältig zu dokumentieren.',
          'Die Versuchsergebnisse haben sorgfältig dokumentiert zu werden.',
          'Die Versuchsergebnisse lassen sich sorgfältig dokumentieren.',
          'Die Versuchsergebnisse werden zu dokumentieren sein.'
        ],
        correctAnswer: 'Die Versuchsergebnisse sind sorgfältig zu dokumentieren.',
        explanation: {
          en: '"sein + zu + Infinitiv" expresses necessity/obligation ("müssen dokumentiert werden"), producing high-register scientific German.',
          fa: 'ترکیب "sein + zu + مصدر" بیانگر ضرورت و الزام قانونی ("باید مستندسازی شوند") در زبان رسمی دانشگاهی و علمی است.',
          prs: 'ساختار sein + zu + مصدر به بهترین وجه معنای ضرورت را در سبک رسمی افاده می‌کند.',
          tr: '"sein + zu + mastar", zorunluluk ("müssen") bildirerek üst düzey bilimsel Almancada edilgen çatı yerine geçer.',
          ar: 'التركيب "sein + zu + المصدر" يفيد الوجوب والإلزام كبديل للمجهول في الأسلوب العلمي الرفيع.',
          es: '"sein + zu + infinitivo" expresa obligatoriedad sustituyendo a la pasiva con modal en el registro culto.'
        }
      }
    ]
  }
];
