import { Lesson } from '../types';

export const CURRICULUM_C2_1: Lesson[] = [
  {
    id: 'c2_1_lek1',
    lektionNumber: 1,
    level: 'C2.1',
    title: 'Philosophische Diskurse und Sprachkritik',
    subTitle: 'Hermeneutik, Nominalstil und stilistische Meisterung (C2 Niveau)',
    topic: 'Erkenntnistheorie, Ästhetik und elaborierter Nominalstil in Wissenschaft und Recht',
    fotoHoergeschichte: {
      title: 'Foto-Hörgeschichte: Das Symposium zur Sprachphilosophie in Heidelberg',
      imagePrompt: 'An atmospheric academic amphitheater in historic Heidelberg overlooking the Neckar river, where international philologists debate linguistic relativity.',
      imageTheme: 'Philosophisches Kolleg in Heidelberg',
      audioDuration: '04:20',
      transcript: [
        { speaker: 'Prof. Dr. Gadamer-Forscher', text: 'Die Sprache ist kein bloßes Zeichensystem zur Abbildung präexistenter Entitäten, sondern das Vollzugsorgan unserer Welterschlossenheit.' },
        { speaker: 'Prof. Dr. Wittgenstein-Spezialistin', text: 'Insofern markieren die Grenzen meiner Sprache die Grenzen meiner Welt; jegliche Sinnkonstitution vollzieht sich unausweichlich im Medium intersubjektiver Sprachspiele.' },
        { speaker: 'Prof. Dr. Gadamer-Forscher', text: 'Die hermeneutische Applikation verlangt mithin die permanente Reflexion unseres eigenen geschichtlichen Vorverständnisses.' }
      ],
      summary: {
        en: 'Eminent philosophers in Heidelberg examine philosophical hermeneutics, linguistic relativity, and the epistemological boundaries of language.',
        fa: 'فیلسوفان برجسته در هایدلبرگ به بررسی هرمنوتیک فلسفی، نسبیت زبانی و مرزهای معرفت‌شناختی زبان می‌پردازند.',
        prs: 'فیلسوفان در هایدلبرگ درباره فلسفه زبان، شناخت جهان و تفکر نقدی بحث‌های عمیق اکادمیک دارند.',
        tr: 'Heidelberg\'deki felsefeciler felsefi yorumbilimi, dilsel göreliliği ve dilin epistemolojik sınırlarını irdeliyor.',
        ar: 'يبحث فلاسفة بارزون في هايدلبرغ علم التأويل الفلسفي، والنسبية اللغوية، والحدود المعرفية للغة.',
        es: 'Filósofos de renombre en Heidelberg examinan la hermenéutica filosófica, la relatividad lingüística y los límites epistemológicos del lenguaje.'
      }
    },
    sectionA: {
      title: 'Mussawi A: Sprechen & Dialog',
      focus: 'Sprechen & Hören (Philosophische Reflexion & Rhetorik)',
      description: {
        en: 'Demonstrate effortless rhetorical fluency, subtle irony, and conceptual precision at the highest native standard.',
        fa: 'تسلط بی‌نقص بر فصاحت بلاغی، کاربرد کنایه‌های ظریف و دقت مفهومی در بالاترین سطح زبانی.',
        prs: 'تسلط کامل بر سخنرانی فصیح، استدلال‌های دقیق فلسفی و بلاغت کلامی در سطح زبان مادری.',
        tr: 'Doğal akıcılıkta retorik ustalık, ince imalar ve en üst düzeyde kavramsal kesinlik sergileyin.',
        ar: 'إظهار فصاحة بيانية مطلقة، واستخدام التلميحات البلاغية الدقيقة، والإحكام المفاهيمي في أرقى مستويات اللغة.',
        es: 'Demuestra elocuencia retórica impecable, ironía sutil y precisión conceptual al más alto nivel.'
      },
      content: 'Die These ist insofern restringiert zu betrachten, als sie wesentliche ontologische Prämissen ausblendet.',
      audioText: 'In der philosophischen Tradition seit Kant ist die Frage nach den Bedingungen der Möglichkeit von Erkenntnis konstitutiv.',
      practiceTasks: [
        'Dekonstruieren Sie eine erkenntnistheoretische Argumentation in freier Rede.',
        'Setzen Sie feine Nuancen der Ironie und der rhetorischen Distanzierung gekonnt ein.'
      ]
    },
    sectionB: {
      title: 'Mussawi B: Wortschatz & Hören',
      focus: 'Hören & Wortschatz (Wissenschaftliche Traktate & Feuilleton)',
      description: {
        en: 'Master esoteric, archaic, and nuanced intellectual lexicon across German philosophy and literature.',
        fa: 'تسلط بر گنجینه واژگان فلسفی، ادبی و واژه‌سازی‌های خلاقانه در بالاترین سطح زبان آلمانی.',
        prs: 'فراگیری عمیق لغات فلسفی، ادبی و اصطلاحات اصیل اندیشه آلمانی.',
        tr: 'Alman felsefesi ve edebiyatındaki derinlikli, arkaik ve incelikli entelektüel sözcük dağarcığına hakim olun.',
        ar: 'إتقان المعجم الفلسفي والأدبي التراثي والمصطلحات الفكرية الدقيقة في أرقى مراجع الفكر الألماني.',
        es: 'Domina el léxico intelectual, arcaico y matizado de la filosofía y literatura alemanas.'
      },
      content: 'die Aporie, die Hermeneutik, der Solipsismus, die Kontingenz, das Postulat.',
      practiceTasks: [
        'Erläutern Sie philosophische Termini und deren geschichtlichen Bedeutungswandel.',
        'Verfassen Sie Glossen zu zeitgenössischen sprachphilosophischen Streitfragen.'
      ]
    },
    sectionC: {
      title: 'Mussawi C: Alltagskommunikation',
      focus: 'Sprechen & Dialoge (Akademische Disputationen & Fachvorträge)',
      description: {
        en: 'Engage in academic disputations with professors, navigating nuanced epistemological objections.',
        fa: 'مشارکت در مناظرات دانشگاهی با اساتید صاحب‌کرسی و پاسخ‌گویی به پیچیده‌ترین نقدهای معرفت‌شناختی.',
        prs: 'مناظره علمی با استادان دانشگاه و دفاع از نظریات عمیق فلسفی و تحلیلی.',
        tr: 'Kürsü sahibi profesörlerle epistemolojik itirazları yöneterek akademik münazaralara katılın.',
        ar: 'خوض المناظرات الأكاديمية الرفيعة مع أساتذة الكراسي العلمية وتفنيد الاعتراضات المعرفية المعقدة.',
        es: 'Participa en disputas académicas con catedráticos abordando objeciones epistemológicas sutiles.'
      },
      content: 'Mit Verlaub, Ihre Reduktion des Diskurses auf bloße Pragmatik verkennt die transzendentale Dimension.',
      audioText: 'Hierbei ist zu bedenken, dass jede Hermeneutik einen Zirkel des Vorverständnisses voraussetzt.',
      practiceTasks: [
        'Führen Sie eine 10-minütige Disputation über Adornos Kulturkritik.',
        'Synthetisieren Sie dialektische Gegensätze zu einer tragfähigen These.'
      ]
    },
    sectionD: {
      title: 'Mussawi D: Leseverstehen & Text',
      focus: 'Lesen & Textanalyse (Wissenschaftliche Monografien)',
      description: {
        en: 'Deconstruct original philosophical texts from Kant, Hegel, Gadamer, and Habermas.',
        fa: 'تحلیل و ساختارشکنی متون فلسفی اصیل از کانت، هگل، گادامر و هابرماس.',
        prs: 'مطالعه و تحلیل متون دست‌اول فلسفی کانت، هگل و فیلسوفان معاصر آلمان.',
        tr: 'Kant, Hegel, Gadamer ve Habermas\'ın özgün felsefi metinlerini yapıbozuma uğratın.',
        ar: 'تفكيك وتحليل النصوص الفلسفية الأصلية لكانط، وهيغل، وغادامير، وهابرماس.',
        es: 'Deconstruye textos filosóficos originales de Kant, Hegel, Gadamer y Habermas.'
      },
      content: 'Auszug aus der Erkenntnistheorie und Sprachphilosophie.',
      readingText: {
        type: 'Wissenschaftliche Abhandlung aus der "Zeitschrift für philosophische Forschung"',
        title: 'Die Unhintergehbarkeit der Sprache: Zur Kritik des reinen Semantizismus',
        body: 'Wer die sprachliche Verfasstheit menschlicher Vernunft als kontingentes Beiwerk abtut, verkennt das dialektische Verhältnis von Denken und sprachlicher Artikulation. Nicht das Subjekt bedient sich der Sprache als eines beliebig austauschbaren Werkzeugs; vielmehr konstituiert sich die Subjektivität allererst im Vollzug sprachlicher Artikulation.'
      },
      practiceTasks: [
        'Exzerpieren Sie die Argumentationsstruktur des philosophischen Traktats.',
        'Verfassen Sie eine 200 Wörter lange Replik unter Verwendung von Konjunktiv I in der indirekten Rede.'
      ]
    },
    sectionE: {
      title: 'Mussawi E: Grammatik & Schreiben',
      focus: 'Grammatik & Schreiben (Der elaborierte Nominalstil & Genitivkonstruktionen)',
      description: {
        en: 'Condense complex verbal propositions into master-level nominal structures featuring prepositional Genitives (infolge, mangels, anlässlich).',
        fa: 'تبدیل گزاره‌های فعلی چندبخشی به ساختارهای اسمی غنی (Nominalstil) با حروف اضافه حاکم بر حالت ملکی (مانند infolge, mangels, anlässlich).',
        prs: 'تبدیل جملات فعلی به سبک اسمی غنی و شیوا با حروف اضافه اضافه ملکی (Genitiv).',
        tr: 'Fiil odaklı cümleleri Genitiv edatlı seçkin isimleştirme yapılarına (Nominalstil) dönüştürün.',
        ar: 'تكثيف العبارات الفعلية وتحويلها إلى الأسلوب الاسمي الرفيع (Nominalstil) مع حروف جر المضاف إليه.',
        es: 'Condensa proposiciones verbales en estructuras de estilo nominal con preposiciones en genitivo.'
      },
      content: 'Nominalstil: Präposition + [Genitivattribut / Adjektiv] + Nomen (vom Verb abgeleitet).',
      grammarRule: {
        id: 'c2_1_nominalstil_rule',
        level: 'C2.1',
        germanTitle: 'Der elaborierte Nominalstil in Wissenschaft und Recht',
        formula: 'Präposition (Genitiv) + [Attribut] + Substantiviertes Nomen + (...)',
        explanation: {
          en: 'In high administrative, legal, and academic German, verbal clauses are systematically replaced with prepositional nominal phrases governing the genitive case.',
          fa: 'در متون رسمی اداری، حقوقی و دانشگاهی، جملات فعلی به صورت روشمند با عبارات اسمی و حروف اضافه ملکی جایگزین می‌شوند.',
          prs: 'در سبک رسمی دانشگاهی و اداری، افعال به اسم‌های مشتق همراه با اضافه‌های ملکی تبدیل می‌گردند.',
          tr: 'Resmi yazışmalarda ve akademik Almancada eylemsel cümleler edatlı isim öbeklerine dönüştürülür.',
          ar: 'في الأسلوب الإداري والأكاديمي الرفيع، يتم استبدال الجمل الفعلية بعبارات اسمية مشتقة مسبوقة بأدوات الجر.',
          es: 'En el alemán académico y administrativo culto, las oraciones verbales se sustituyen sistemáticamente por sintagmas nominales preposicionales.'
        },
        examples: [
          {
            german: 'Anlässlich der feierlichen Verleihung des Bundesverdienstkreuzes hielt der Bundespräsident eine programmatische Rede.',
            formulaBreakdown: 'Anlässlich (Präp + Gen) + der feierlichen Verleihung (Nomen) + des Bundesverdienstkreuzes (Genitiv) + hielt der Bundespräsident eine Rede.',
            literalTranslation: {
              en: 'On the occasion of the ceremonial conferral of the Federal Cross of Merit held the Federal President a programmatic speech.',
              fa: 'به مناسبت اعطای تشریفاتی نشان لیاقت فدرال ایراد کرد رئیس‌جمهور فدرال نطقی راهبردی.',
              prs: 'به مناسبت اهدای رسمی نشان شایستگی، رئیس‌جمهور سخنرانی همه‌جانبه‌ای ارائه کرد.',
              tr: 'Federal Liyakat Nişanı\'nın resmi tevdi töreni vesilesiyle Federal Cumhurbaşkanı vizyoner bir konuşma yaptı.',
              ar: 'بمناسبة التقليد الاحتفالي لوسام الاستحقاق الاتحادي، ألقى رئيس الجمهورية الاتحادية خطاباً برنامجياً.',
              es: 'Con motivo de la solemne entrega de la Cruz del Mérito Federal pronunció el Presidente Federal un discurso programático.'
            },
            fluentTranslation: {
              en: 'On the occasion of conferring the Federal Cross of Merit, the Federal President delivered a keynote address.',
              fa: 'به مناسبت آیین اهدای نشان شایستگی، رئیس‌جمهور سخنرانی جامعی در تشریح برنامه‌ها ایراد کرد.',
              prs: 'در محفل اهدای مدال لیاقت، رئیس‌جمهور سخنرانی اساسی خط‌مشی آینده را ایراد نمود.',
              tr: 'Federal Liyakat Nişanı\'nın takdimi vesilesiyle Cumhurbaşkanı temel ilkeleri içeren bir konuşma gerçekleştirdi.',
              ar: 'بمناسبة مراسم منح وسام الاستحقاق الفيدرالي، ألقى الرئيس الاتحادي خطاباً توجيهياً شاملاً.',
              es: 'Con ocasión de la entrega de la Cruz del Mérito, el Presidente Federal pronunció un discurso programático.'
            }
          }
        ]
      },
      practiceTasks: [
        'Formulieren Sie fünf verbale Nebensätze mit "weil", "indem" und "obwohl" in präpositionale Nominalgefüge um.',
        'Verfassen Sie eine juristische Stellungnahme oder ein wissenschaftliches Gutachten (300 Wörter).'
      ]
    },
    vocabularies: [
      { id: 'c2_1_v1', word: 'die Unhintergehbarkeit', article: 'die', plural: '-', ipa: '/ˈʊnhɪntɐˌɡeːbaːɐ̯kaɪ̯t/', translation: { en: 'inescapability / ontological impossibility of bypassing', fa: 'گریزناپذیری وجودی / غیرقابل دور زدن بودن', prs: 'گریزناپذیری / واقعیتی که نمی‌توان از آن عبور کرد', tr: 'kaçınılmazlık / aşılamazlık', ar: 'الحتيمة / الاستحالة الوجودية للتجاوز', es: 'ineludibilidad / carácter insoslayable' } },
      { id: 'c2_1_v2', word: 'die Kontingenz', article: 'die', plural: 'die Kontingenzen', ipa: '/kɔntɪŋˈɡɛnt͡s/', translation: { en: 'contingency (philosophical)', fa: 'امکان خاص / امکانی بودن (در برابر وجوب یا امتناع)', prs: 'امکان وقوعی پدیده‌ها در فلسفه', tr: 'olumsallık / rastlantısallık', ar: 'الإمكانية / العَرَضية الفلسفية', es: 'contingencia ontológica' } },
      { id: 'c2_1_v3', word: 'die Aporie', article: 'die', plural: 'die Aporien', ipa: '/apoˈʁiː/', translation: { en: 'aporia / insolvable philosophical impasse', fa: 'آپوریا / بن‌بست لاینحل فکری و دیالکتیکی', prs: 'بن‌بست فکری و تناقض حل‌ناشدنی فلسفی', tr: 'çıkmaz / apori', ar: 'المأزق الفلسفي المستعصي / الأبوريا', es: 'aporía / dilema irresoluble' } }
    ],
    exercises: [
      {
        id: 'ex_c2_1_1',
        type: 'multiple_choice',
        instruction: {
          en: 'Select the optimal nominal transformation in advanced scientific style.',
          fa: 'بهترین تبدیل اسمی در سبک علمی پیشرفته را انتخاب نمایید.',
          prs: 'بهترین تبدیل جمله فعلی به سبک اسمی را تعیین کنید.',
          tr: 'İleri bilimsel üsluptaki en yetkin isimleştirme dönüşümünü seçiniz.',
          ar: 'اختر التحويل الاسمي الأنسب وفق أسلوب الصياغة العلمية المتقدمة.',
          es: 'Selecciona la transformación nominal óptima en estilo científico avanzado.'
        },
        prompt: 'Transform: "Weil der Versuch unerwartet scheiterte, mussten die Forscher umplanen."',
        options: [
          'Infolge des unerwarteten Scheiterns des Versuchs mussten die Forscher umplanen.',
          'Wegen scheitern unerwartet vom Versuch planten Forscher um.',
          'Für das Scheitern des Versuchs machten die Forscher Pläne neu.',
          'Aus Grund des unerwarteten Scheitern Forscher umplanten.'
        ],
        correctAnswer: 'Infolge des unerwarteten Scheiterns des Versuchs mussten die Forscher umplanen.',
        explanation: {
          en: '"Infolge" requires the Genitive case ("des unerwarteten Scheiterns des Versuchs"), demonstrating authentic high-register C2 nominal style.',
          fa: 'حرف اضافه "Infolge" نیازمند حالت ملکی (Genitiv) بوده و نشانه بارز سبک فاخر C2 است.',
          prs: 'حرف اضافه Infolge با حالت ملکی Genitiv سبک اسمی عالی سطح C2 را می‌سازد.',
          tr: '"Infolge" edatı tamlayan durumunu (Genitiv) gerektirir ve ileri düzey C2 isimleştirme stilini yansıtır.',
          ar: 'أداة الجر "Infolge" تتطلب المضاف إليه (Genitiv)، مجسدة الأسلوب الاسمي الرصين المعتمد في مستوى C2.',
          es: 'La preposición "Infolge" exige genitivo ("des unerwarteten Scheiterns des Versuchs"), reflejando el estilo nominal refinado propio de C2.'
        }
      }
    ]
  },
  {
    id: 'c2_1_lek2',
    lektionNumber: 2,
    level: 'C2.1',
    title: 'Verfassungsgerichtsbarkeit und Normenkontrolle',
    subTitle: 'Grundrechte, Bundesverfassungsgericht und richterliche Urteilsbegründung (C2)',
    topic: 'Normenhierarchie, Verhältnismäßigkeitsprüfung, Grundrechte und modale Infinitive',
    fotoHoergeschichte: {
      title: 'Foto-Hörgeschichte: Urteilsverkündung am Bundesverfassungsgericht in Karlsruhe',
      imagePrompt: 'The iconic courtroom of the Federal Constitutional Court in Karlsruhe with scarlet-robed judges delivering a landmark constitutional ruling.',
      imageTheme: 'Bundesverfassungsgericht Karlsruhe',
      audioDuration: '03:40',
      transcript: [
        { speaker: 'Präsident des Bundesverfassungsgerichts', text: 'Im Namen des Volkes: Das zur Prüfung vorgelegte Bundesgesetz ist mit Artikel 2 Absatz 1 in Verbindung mit Artikel 1 Absatz 1 des Grundgesetzes unvereinbar und mithin nichtig.' },
        { speaker: 'Berichterstattende Richterin', text: 'Der Gesetzgeber hat es versäumt, die widerstreitenden Schutzgüter in ein verfassungsrechtlich tragfähiges Ausgleichsverhältnis zu bringen.' },
        { speaker: 'Präsident des Bundesverfassungsgerichts', text: 'Dem Parlament wird aufgegeben, bis zum Ende der laufenden Legislaturperiode eine verfassungskonforme Neuregelung zu treffen.' }
      ],
      summary: {
        en: 'The Federal Constitutional Court in Karlsruhe delivers a landmark ruling declaring federal legislation void due to incompatibility with fundamental constitutional rights.',
        fa: 'دیوان عالی قانون اساسی فدرال در کارلسروهه حکمی تاریخی صادر کرده و قانونی فدرال را به دلیل تعارض با حقوق بنیادین قانون اساسی باطل اعلام می‌کند.',
        prs: 'محکمه عالی قانون اساسی آلمان در کارلسروهه یک قانون فدرال را خلاف حقوق اساسی دانسته و آن را باطل اعلام می‌نماید.',
        tr: 'Karlsruhe\'deki Federal Anayasa Mahkemesi, temel haklarla bağdaşmadığı gerekçesiyle bir federal yasayı iptal eden tarihi kararını açıklıyor.',
        ar: 'المحكمة الدستورية الاتحادية في كارلسروه تصدر حكماً تاريخياً ببطلان قانون اتحادي لتعارضه مع الحقوق الدستورية الأساسية.',
        es: 'El Tribunal Constitucional Federal en Karlsruhe dicta una sentencia histórica declarando nula una ley federal por inconstitucionalidad.'
      }
    },
    sectionA: {
      title: 'Mussawi A: Sprechen & Dialog',
      focus: 'Sprechen & Hören (Juristische Plädoyers & Verfassungsbeschwerden)',
      description: {
        en: 'Deliver persuasive legal pleadings, dissecting constitutional review standards with judicial precision.',
        fa: 'ایراد لوایح دفاعیه حقوقی پرقدرت و کالبدشکافی استانداردهای کنترل اساسی با دقت قاضیان عالی‌رتبه.',
        prs: 'بیان لوایح حقوقی و ارزیابی عمیق قوانین بر اساس اصول قانون اساسی.',
        tr: 'Anayasal denetim standartlarını yargısal kesinlikle çözümleyen ikna edici hukuki savunmalar sunun.',
        ar: 'إلقاء المرافعات القانونية الرصينة وتفكيك معايير الرقابة الدستورية بدقة قضائية فائقة.',
        es: 'Exposición de alegatos jurídicos persuasivos y análisis de constitucionalidad con rigor jurisprudencial.'
      },
      content: 'Der angegriffene Hoheitsakt verletzt die Beschwerdeführerin in ihrem Grundrecht auf informationelle Selbstbestimmung.',
      audioText: 'Die Verhältnismäßigkeit im engeren Sinne verlangt eine strikte Angemessenheit des gesetzgeberischen Mittels.',
      practiceTasks: [
        'Tragen Sie die Begründung einer Verfassungsbeschwerde mündlich vor.',
        'Prüfen Sie einen Grundrechtseingriff anhand des vierstufigen Verhältnismäßigkeitsprinzips.'
      ]
    },
    sectionB: {
      title: 'Mussawi B: Wortschatz & Hören',
      focus: 'Hören & Wortschatz (Juristisches Fachdeutsch & Verfassungsrecht)',
      description: {
        en: 'Highly specialized legal and constitutional terminology: judicial review, proportional balance, and core rights.',
        fa: 'واژگان فوق‌تخصصی حقوقی و قضایی: کنترل هنجاری، اصل تناسب، خودتعیین‌گری اطلاعاتی و مصونیت ذاتی.',
        prs: 'لغات عالی و تخصصی حقوقی: نظارت بر قانون اساسی، اصل تناسب در مجازات و حقوق اساسی شهروندان.',
        tr: 'İleri düzey anayasa hukuku terminolojisi: norm denetimi, ölçülülük ilkesi ve anayasal öz güvencesi.',
        ar: 'المصطلحات الدستورية والقانونية بالغة التخصص: رقابة دستورية القوانين، مبدأ التناسب، والضمانات الجوهرية للحقوق.',
        es: 'Léxico jurídico y constitucional de alta especialización: control de normas, principio de proporcionalidad y contenido esencial.'
      },
      content: 'die Verhältnismäßigkeit, die Normenkontrolle, der Wesensgehalt, die Nichtigkeit, das Zitiergebot.',
      practiceTasks: [
        'Erläutern Sie die vier Prüfungsstufen der Verhältnismäßigkeit (Legitimer Zweck, Geeignetheit, Erforderlichkeit, Angemessenheit).',
        'Analysieren Sie juristische Leitsätze aus BVerfGE-Entscheidungen.'
      ]
    },
    sectionC: {
      title: 'Mussawi C: Alltagskommunikation',
      focus: 'Sprechen & Dialoge (Richterliche Beratung & Urteilsfindung)',
      description: {
        en: 'Collegiate judicial deliberations among constitutional judges, drafting majority opinions and dissents.',
        fa: 'مشورت شورایی میان قضات دادگاه قانون اساسی، تدوین نظرات اکثریت و ثبت آرای مخالف (Dissenting Opinion).',
        prs: 'جلسات مشورتی قاضیان محکمه عالی و تدوین فیصله‌های نهایی بر اساس قانون اساسی.',
        tr: 'Anayasa yargıçları arasında heyet müzakereleri, çoğunluk gerekçesi ve karşı oy yazısı hazırlama.',
        ar: 'المداولات القضائية الجماعية بين قضاة المحكمة الدستورية، وصياغة حيثيات الأغلبية والآراء المخالفة.',
        es: 'Deliberaciones judiciales colegiadas, redacción de fundamentos de la mayoría y votos particulares.'
      },
      content: 'Ich teile die Auffassung des Senats im Grundsatz, verfasse jedoch ein Sondervotum zur Begründung.',
      audioText: 'In der mündlichen Verhandlung wurde offenkundig, dass der Schutzzweck der Norm verfehlt wurde.',
      practiceTasks: [
        'Simulieren Sie eine Senatsberatung am Bundesverfassungsgericht.',
        'Formulieren Sie ein juristisches Sondervotum zu einer strittigen Grundrechtsfrage.'
      ]
    },
    sectionD: {
      title: 'Mussawi D: Leseverstehen & Text',
      focus: 'Lesen & Textanalyse (Leitentscheidungen des Bundesverfassungsgerichts)',
      description: {
        en: 'Analyze canonical decisions of the Federal Constitutional Court (BVerfGE) with complex legal reasoning.',
        fa: 'تحلیل آرای مرجع و ماندگار دیوان عالی قانون اساسی آلمان (BVerfGE) با استدلال‌های حقوقی تراز اول.',
        prs: 'خواندن و تحلیل فیصله‌های تاریخی محکمه عالی قانون اساسی آلمان با ادبیات حقوقی استثنایی.',
        tr: 'Federal Anayasa Mahkemesi\'nin karmaşık gerekçeli emsal kararlarını analiz etme.',
        ar: 'تحليل الأحكام القضائية المرجعية للمحكمة الدستورية الاتحادية وما تحويه من أسباب معللة رصينة.',
        es: 'Análisis de resoluciones emblemáticas del Tribunal Constitucional Federal (BVerfGE).'
      },
      content: 'Auszug aus dem Klimabeschluss des Bundesverfassungsgerichts.',
      readingText: {
        type: 'Amtliche Entscheidungssammlung (BVerfGE 157, 30)',
        title: 'Leitsatz zum Beschluss des Ersten Senats: Intertemporale Freiheitssicherung',
        body: 'Die Grundrechte schützen vor einer einseitigen Verlagerung der Treibhausgas-Minderungslasten in die Zukunft. Der Gesetzgeber muss vorausschauend Vorkehrungen treffen, um diese hohen Lasten abzumildern. Von den Grundrechten geschützte Freiheitsspielräume dürfen nicht zu einem späteren Zeitpunkt radikal beschnitten werden müssen.'
      },
      practiceTasks: [
        'Erläutern Sie das Rechtskonzept der "intertemporalen Freiheitssicherung".',
        'Fassen Sie die verfassungsrechtlichen Vorgaben für den Gesetzgeber prägnant zusammen.'
      ]
    },
    sectionE: {
      title: 'Mussawi E: Grammatik & Schreiben',
      focus: 'Grammatik & Schreiben (Der modale Infinitiv mit "haben / sein + zu + Infinitiv")',
      description: {
        en: 'Master modal infinitives: "haben + zu + Infinitiv" (active obligation: müssen) and "sein + zu + Infinitiv" (passive necessity/possibility).',
        fa: 'تسلط بر مصادر وجهی: ترکیب "haben + zu + مصدر" (بیان الزام فاعلی: müssen) و "sein + zu + مصدر" (بیان ضرورت یا امکان مجهول).',
        prs: 'یادگیری کامل مصادر وجهی در زبان اداری: haben + zu برای وظیفه فاعلی و sein + zu برای مجهول.',
        tr: 'Modal mastar kullanımları: "haben + zu" (etken zorunluluk) ve "sein + zu" (edilgen gereklilik/olasılık).',
        ar: 'إتقان المصادر الجهية: التركيب "haben + zu + المصدر" (إلزام للمعلوم) والتركيب "sein + zu + المصدر" (إلزام أو إمكانية للمجهول).',
        es: 'Dominio de infinitivos modales: "haben + zu + infinitivo" (obligación activa) y "sein + zu + infinitivo" (necesidad pasiva).'
      },
      content: 'Modale Infinitive: "Der Kläger hat die Beweislast zu tragen" (= muss tragen) / "Das Urteil ist sofort zu vollstrecken" (= muss vollstreckt werden).',
      grammarRule: {
        id: 'c2_1_modaler_infinitiv',
        level: 'C2.1',
        germanTitle: 'Der modale Infinitiv mit "haben / sein + zu + Infinitiv"',
        formula: 'Subjekt (Aktiv) + haben + zu + Infinitiv | Subjekt (Passiv) + sein + zu + Infinitiv',
        explanation: {
          en: '"haben + zu + Infinitiv" expresses an active obligation of the subject (= müssen/sollen). "sein + zu + Infinitiv" expresses passive obligation or possibility (= müssen/können + Partizip II + werden).',
          fa: 'ترکیب "haben + zu + مصدر" نشان‌دهنده وظیفه و الزام مستقیم فاعل است (معادل müssen). ترکیب "sein + zu + مصدر" الزام یا امکان‌پذیری را به صورت مجهول بیان می‌دارد (معادل müssen/können gelöst werden).',
          prs: 'ترکیب haben + zu + مصدر وجیبه فاعل را نشان می‌دهد و sein + zu + مصدر مجهولیت کار را با وجه ضرورت بیان می‌کند.',
          tr: '"haben + zu" öznenin aktif zorunluluğunu (müssen), "sein + zu" ise edilgen zorunluluk veya olasılığı ifade eder.',
          ar: 'التركيب "haben + zu" يفيد إلزام الفاعل بأداء الفعل، بينما يفيد "sein + zu" الوجوب أو الإمكانية بصيغة المبني للمجهول.',
          es: '"haben + zu" denota obligación activa del sujeto; "sein + zu" expresa necesidad o posibilidad en voz pasiva.'
        },
        examples: [
          {
            german: 'Die beteiligten Ministerien haben die verfassungsrechtlichen Einwände gewissenhaft zu prüfen.',
            formulaBreakdown: 'Die Ministerien (S) + haben (haben) + die Einwände (Akk) + gewissenhaft zu prüfen (zu + Infinitiv = müssen prüfen).',
            literalTranslation: {
              en: 'The involved ministries have the constitutional objections conscientiously to examine.',
              fa: 'وزارت‌خانه‌های دخیل باید ایرادات حقوق اساسی را با وجدان کاری بررسی کنند.',
              prs: 'وزارت‌های مربوطه مکلف هستند اعتراضات متکی بر قانون اساسی را با دقت بررسی نمایند.',
              tr: 'İlgili bakanlıklar anayasal itirazları titizlikle incelemekle yükümlüdür.',
              ar: 'يتعين على الوزارات المعنية فحص الاعتراضات الدستورية فحصاً دقيقاً ومسؤولاً.',
              es: 'Los ministerios competentes han de examinar a conciencia las objeciones constitucionales.'
            },
            fluentTranslation: {
              en: 'The ministries involved are strictly required to examine the constitutional objections with utmost diligence.',
              fa: 'وزارت‌خانه‌های مربوطه موظفند ایرادات وارده از منظر حقوق اساسی را با نهایت دقت و موشکافی بررسی نمایند.',
              prs: 'وزارت‌های ذیربط مکلفیت دارند که نظریات مبتنی بر قانون اساسی را به گونه عمیق بازنگری کنند.',
              tr: 'Söz konusu bakanlıklar anayasa hukukuna ilişkin itirazları büyük bir titizlikle incelemek zorundadır.',
              ar: 'تلتزم الوزارات المعنية التزاماً قاطعاً بدراسة الطعون الدستورية بأقصى درجات المسؤولية والحرص.',
              es: 'Los ministerios involucrados tienen la ineludible obligación de examinar diligentemente los reparos constitucionales.'
            }
          }
        ]
      },
      practiceTasks: [
        'Formulieren Sie juristische Verpflichtungen mit "haben + zu + Infinitiv".',
        'Verfassen Sie den Urteilstenor eines fiktiven Normenkontrollverfahrens.'
      ]
    },
    vocabularies: [
      { id: 'c2_1_v4', word: 'die Normenkontrolle', article: 'die', plural: 'die Normenkontrollen', ipa: '/ˈnɔʁmənkɔnˌtʁɔlə/', translation: { en: 'judicial review of constitutionality of statutes', fa: 'کنترل انطباق قوانین با قانون اساسی', prs: 'بررسی مطابقت قوانین با قانون اساسی', tr: 'norm denetimi', ar: 'الرقابة على دستورية القوانين', es: 'control de constitucionalidad de las normas' } },
      { id: 'c2_1_v5', word: 'der Wesensgehalt', article: 'der', plural: 'die Wesensgehalte', ipa: '/ˈveːzn̩sɡəˌhalt/', translation: { en: 'essential content / core substance of a fundamental right', fa: 'جوهر و محتوای بنیادین حق اساسی که نقض آن ناممکن است', prs: 'هسته و اساس حقوق غیرقابل سلب انسانی', tr: 'öz güvencesi / temel hakkın özü', ar: 'المحتوى الجوهري للحق الدستوري', es: 'contenido esencial de un derecho fundamental' } },
      { id: 'c2_1_v6', word: 'die Nichtigkeit', article: 'die', plural: '-', ipa: '/ˈnɪçtɪçkaɪ̯t/', translation: { en: 'nullity / voidness ex tunc', fa: 'بطلان مطلق و بی‌اعتباری قانونی از ابتدا', prs: 'باطل بودن کامل حکم یا قانون از بنیاد', tr: 'butlan / geçersizlik', ar: 'البطلان المطلق بأثر رجعي', es: 'nulidad de pleno derecho' } }
    ],
    exercises: [
      {
        id: 'ex_c2_1_2',
        type: 'multiple_choice',
        instruction: {
          en: 'Identify the sentence in which "haben + zu + Infinitiv" expresses an active obligation.',
          fa: 'جمله‌ای را مشخص کنید که در آن ترکیب "haben + zu + Infinitiv" بیانگر الزام فاعل است.',
          prs: 'جمله‌ای را پیدا کنید که ساختار haben + zu مکلفیت مستقیم فاعل را نشان می‌دهد.',
          tr: '"haben + zu + mastar" yapısının etkence bir zorunluluk bildirdiği cümleyi tespit ediniz.',
          ar: 'حدد الجملة التي يعبر فيها التركيب "haben + zu + المصدر" عن إلزام صريح للفاعل.',
          es: 'Identifica la oración en la que "haben + zu + infinitivo" denota obligación activa del sujeto.'
        },
        prompt: 'In welchem Satz drückt die Konstruktion eine aktive Verpflichtung des Subjekts aus?',
        options: [
          'Die Verwaltungsbehörde hat den Bescheid innerhalb von zwei Wochen zuzustellen.',
          'Der Bescheid ist innerhalb von zwei Wochen zuzustellen.',
          'Der Bescheid lässt sich innerhalb von zwei Wochen zustellen.',
          'Es bleibt ein Bescheid zuzustellen.'
        ],
        correctAnswer: 'Die Verwaltungsbehörde hat den Bescheid innerhalb von zwei Wochen zuzustellen.',
        explanation: {
          en: '"Die Behörde (Subject) + hat (haben) + zuzustellen (zu + Infinitiv)" means the authority must actively deliver the decision.',
          fa: 'در جمله اول "Die Verwaltungsbehörde (فاعل) + hat + zuzustellen" نشان می‌دهد که اداره خود موظف است ابلاغیه را ارسال کند (haben + zu = müssen فاعلی).',
          prs: 'در این جمله اداره مستقیماً مکلف ساخته شده است که فیصله را ابلاغ نماید.',
          tr: '"haben + zu" yapısı öznenin (idari makamın) aktif teslim etme yükümlülüğünü ("muss zustellen") ifade eder.',
          ar: 'التركيب "haben + zu" في الجملة الأولى يفيد إلزام الجهة الإدارية بالقيام بإجراء التبليغ بنفسها.',
          es: '"haben + zu" expresa la obligación activa del sujeto ("la autoridad administrativa") de notificar la resolución.'
        }
      }
    ]
  }
];
