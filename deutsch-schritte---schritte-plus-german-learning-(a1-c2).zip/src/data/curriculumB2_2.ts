import { Lesson } from '../types';

export const CURRICULUM_B2_2: Lesson[] = [
  {
    id: 'b2_2_lek1',
    lektionNumber: 1,
    level: 'B2.2',
    title: 'Umweltökonomie und Nachhaltige Mobilität',
    subTitle: 'Klimaschutz, Energiewende und Pronominaladverbien (B2.2 Niveau)',
    topic: 'Nachhaltigkeit, Kreislaufwirtschaft, Pronominaladverbien und komplexe Konnektoren',
    fotoHoergeschichte: {
      title: 'Foto-Hörgeschichte: Die Konferenz zur städtischen Verkehrswende in Freiburg',
      imagePrompt: 'A solar-powered modern municipal conference hall in Freiburg with urban planners and transport experts reviewing cycling highway maps and tram network extensions.',
      imageTheme: 'Freiburg Verkehrswende',
      audioDuration: '03:10',
      transcript: [
        { speaker: 'Bürgermeister Dr. Weber', text: 'Die Dekarbonisierung unseres Nahverkehrs erfordert erhebliche Investitionen in den Schienenausbau.' },
        { speaker: 'Verkehrsplanerin Dipl.-Ing. Keller', text: 'Wir haben lange darüber nachgedacht, wie wir Autofahrer zum Umstieg auf den ÖPNV bewegen können.' },
        { speaker: 'Herr Özdemir (Bürgerinitiative)', text: 'Worauf es jetzt ankommt, ist eine zuverlässige Taktung und bezahlbare Jahrestickets für alle Bürger.' },
        { speaker: 'Bürgermeister Dr. Weber', text: 'Genau darauf zielt unser Maßnahmenpaket ab: mehr Busspuren und ein 365-Euro-Jahresticket.' }
      ],
      summary: {
        en: 'City planners in Freiburg discuss the municipal transit transition, cycling infrastructure, and affordable public transportation.',
        fa: 'برنامه‌ریزان شهری در فرایبورگ در مورد گذار حمل و نقل عمومی، مسیرهای دوچرخه‌سواری و بلیت‌های ارزان سالانه گفتگو می‌کنند.',
        prs: 'پلان‌گذاران شهری در فرایبورگ در مورد بهبود سیستم ترانسپورت عامه، خطوط بایسکل‌رانی و تکت‌های ارزان سالانه گفتگو می‌نمایند.',
        tr: 'Freiburg\'daki şehir plancıları toplu taşıma dönüşümünü, bisiklet yollarını ve ekonomik yıllık biletleri tartışıyor.',
        ar: 'يناقش مخططو المدن في فرايبورغ التحول في النقل الحضري والبنية التحتية للدراجات والتذاكر السنوية الميسرة.',
        es: 'Urbanistas en Friburgo debaten sobre la transición del transporte público, carriles bici y abonos anuales asequibles.'
      }
    },
    sectionA: {
      title: 'Mussawi A: Sprechen & Dialog',
      focus: 'Sprechen & Hören (Podiumsdiskussion & Kommunalpolitik)',
      description: {
        en: 'Debate ecological municipal policies, present environmental statistics, and justify arguments convincingly.',
        fa: 'مناظره درباره سیاست‌های محیط‌زیستی شهری، ارائه آمارهای آلایندگی و توجیه استدلال‌ها با قاطعیت.',
        prs: 'بحث روی سیاست‌های حفظ محیط زیست شهری، ارائه ارقام و استدلال متقاعدکننده.',
        tr: 'Belediye çevre politikalarını tartışın, istatistikleri sunun ve savlarınızı ikna edici şekilde temellendirin.',
        ar: 'مناقشة السياسات البيئية الحضرية، عرض الإحصاءات البيئية وتبرير الحجج بإقناع.',
        es: 'Debate sobre políticas ecológicas municipales, presentación de estadísticas ambientales y argumentación persuasiva.'
      },
      content: 'Worauf kommt es an? / Wir bestehen darauf, dass... / Es hängt davon ab, ob...',
      audioText: 'Es lässt sich nicht bestreiten, dass die Verkehrswende eine unverzichtbare Säule des Klimaschutzes darstellt.',
      practiceTasks: [
        'Führen Sie ein Pro-und-Kontra-Gespräch über autofreie Innenstädte.',
        'Verwenden Sie gezielt Pronominaladverbien wie "darüber", "womit", "worauf".'
      ]
    },
    sectionB: {
      title: 'Mussawi B: Wortschatz & Hören',
      focus: 'Hören & Wortschatz (Ökologie & Kreislaufwirtschaft)',
      description: {
        en: 'Advanced vocabulary of sustainable energy, circular economy, and ecological footprint.',
        fa: 'واژگان پیشرفته انرژی‌های تجدیدپذیر، اقتصاد چرخشی و ردپای اکولوژیک.',
        prs: 'لغات مسلکی انرژی‌های پاک، اقتصاد چرخشی و اثرات زیست‌محیطی.',
        tr: 'Sürdürülebilir enerji, döngüsel ekonomi ve ekolojik ayak izine ilişkin ileri düzey sözcükler.',
        ar: 'مفردات متقدمة في الطاقة المتجددة، الاقتصاد الدائري، والبصمة البيئية.',
        es: 'Vocabulario avanzado de energías sostenibles, economía circular y huella ecológica.'
      },
      content: 'die Dekarbonisierung, die Kreislaufwirtschaft, der ökologische Fußabdruck, die Emissionsminderung.',
      practiceTasks: [
        'Erläutern Sie das Konzept der Kreislaufwirtschaft anhand eines Industriebeispiels.',
        'Ordnen Sie Umweltfachbegriffe ihren korrekten Begriffsdefinitionen zu.'
      ]
    },
    sectionC: {
      title: 'Mussawi C: Alltagskommunikation',
      focus: 'Sprechen & Dialoge (Bürgerversammlung & Konsensfindung)',
      description: {
        en: 'Participate in town hall debates, formulate compromises, and address citizen concerns.',
        fa: 'شرکت در گردهمایی‌های مشورتی شهروندی، تدوین مصالحه‌های مشترک و پاسخ به دغدغه‌های مردم.',
        prs: 'سهم‌گیری در جلسات مشورتی مردم و حل مشکلات محیط زیستی با تفاهم مشترک.',
        tr: 'Halk toplantılarına katılın, uzlaşma formülleri üretin ve yurttaş kaygılarını yanıtlayın.',
        ar: 'المشاركة في الجمعيات العمومية للمواطنين، صياغة التسويات ومعالجة مخاوف الأهالي.',
        es: 'Participa en asambleas ciudadanas, formula consensos y responde a las inquietudes vecinales.'
      },
      content: 'Einerseits verstehen wir Ihre Bedenken hinsichtlich der Parkplatzsituation, andererseits überwiegt das Gemeinwohl.',
      audioText: 'Wir haben uns darauf verständigt, Anwohnerparkausweise prioritär zu vergeben.',
      practiceTasks: [
        'Simulieren Sie eine Bürgerbefragung zur Erweiterung der Straßenbahnlinien.',
        'Formulieren Sie verbindliche Kompromissvorschläge.'
      ]
    },
    sectionD: {
      title: 'Mussawi D: Leseverstehen & Text',
      focus: 'Lesen & Textanalyse (Fachberichte des Umweltbundesamtes)',
      description: {
        en: 'Read and analyze official reports from the German Federal Environment Agency (Umweltbundesamt).',
        fa: 'مطالعه و تحلیل گزارش‌های رسمی اداره فدرال محیط زیست آلمان (Umweltbundesamt).',
        prs: 'خواندن گزارش‌های رسمی اداره فدرال محیط زیست آلمان با درک عمیق واژگان تخصصی.',
        tr: 'Alman Federal Çevre Ajansı\'nın resmi raporlarını okuyup tahlil edin.',
        ar: 'قراءة وتحليل التقارير الرسمية الصادرة عن الهيئة الاتحادية للبيئة في ألمانيا.',
        es: 'Lectura y análisis de informes técnicos de la Agencia Federal de Medio Ambiente de Alemania.'
      },
      content: 'Auszug aus dem Jahresbericht zur Luftqualität in deutschen Ballungsräumen.',
      readingText: {
        type: 'Fachpublikation des Umweltbundesamtes',
        title: 'Verkehrsbedingte Stickoxid-Belastung in städtischen Verdichtungsräumen',
        body: 'Die Messungen des vergangenen Jahres dokumentieren eine spürbare Verbesserung der städtischen Luftqualität. Dies ist maßgeblich auf die Modernisierung der Fahrzeugflotten sowie den konsequenten Ausbau emissionsarmer Nahverkehrsangebote zurückzuführen. Gleichwohl bedarf es weiterer koordinierter Anstrengungen, um die von der Weltgesundheitsorganisation empfohlenen Richtwerte flächendeckend einzuhalten.'
      },
      practiceTasks: [
        'Analysieren Sie die Ursachen für den Rückgang der Schadstoffemissionen.',
        'Verfassen Sie eine kritische Zusammenfassung des Berichts (150 Wörter).'
      ]
    },
    sectionE: {
      title: 'Mussawi E: Grammatik & Schreiben',
      focus: 'Grammatik & Schreiben (Pronominaladverbien: da(r)- / wo(r)- + Präposition)',
      description: {
        en: 'Master pronominal adverbs: "worauf", "darauf", "womit", "damit", "worüber", "darüber" with prepositional verbs.',
        fa: 'تسلط کامل بر قیدهای ضمیری: ترکیبات da(r)- و wo(r)- با حروف اضافه افعال دارای حرف اضافه ثابت.',
        prs: 'یادگیری قیود ضمیری با حروف اضافه ثابت برای افعال پرکاربرد در سطح B2.2.',
        tr: 'Edatlı fiillerle kullanılan zamirsel zarflar: "worauf/darauf", "womit/damit", "worüber/darüber".',
        ar: 'إتقان الظروف الضميرية مع حروف الجر الثابتة للأفعال: "worauf/darauf", "womit/damit".',
        es: 'Dominio de adverbios pronominales: "worauf/darauf", "womit/damit", "worüber/darüber" con verbos preposicionales.'
      },
      content: 'Pronominaladverbien: Präposition + Nomen (Sache) -> da(r) + Präposition / Frage: wo(r) + Präposition.',
      grammarRule: {
        id: 'b2_2_pronominaladverbien',
        level: 'B2.2',
        germanTitle: 'Pronominaladverbien mit Präpositionalverben (da(r)- / wo(r)-)',
        formula: 'Sache: da(r) + Präposition (darauf, womit) | Person: Präposition + Pronomen (auf ihn, mit wem)',
        explanation: {
          en: 'When referring to objects, facts, or clauses, use "da(r)- + preposition". If the preposition begins with a vowel, insert an "r" (da-r-auf, wo-r-an). For persons, always use the preposition directly with the pronoun (auf wen, an ihn).',
          fa: 'هنگام اشاره به اشیاء، امور یا جملات، از ترکیب "da(r) + حرف اضافه" استفاده می‌شود. در صورت آغاز حرف اضافه با مصوت، حرف "r" اضافه می‌گردد (مانند darauf). برای انسان‌ها همواره حرف اضافه مستقیماً با ضمیر به کار می‌رود (auf ihn).',
          prs: 'برای اشیا و کارها از da(r) + حرف اضافه استفاده می‌شود و برای اشخاص حرف اضافه به همراه ضمیر شخص می‌آید.',
          tr: 'Cansız nesneler ve olgular için "da(r)- + edat" yapısı kullanılır; sesli harfle başlayan edatlarda araya "r" girer. Kişiler için doğrudan şahıs zamiri kullanılır.',
          ar: 'للإشارة إلى الأشياء والوقائع نستخدم "da(r)- + حرف الجر". أما للأشخاص فنستخدم حرف الجر مع ضمير الغائب مباشرة.',
          es: 'Para objetos o hechos se emplea "da(r)- + preposición" (insertando "r" ante vocal). Para personas, se usa la preposición con el pronombre.'
        },
        examples: [
          {
            german: 'Wir haben lange darüber diskutiert, wie die CO2-Steuer verwendet werden soll.',
            formulaBreakdown: 'Wir (S) + haben diskutiert (Perfekt) + darüber (da + r + über = über die Sache) + wie-Satz (Objektsatz).',
            literalTranslation: {
              en: 'We have long there-about discussed, how the CO2 tax used be shall.',
              fa: 'ما مدت‌ها درباره آن بحث کردیم که چگونه مالیات کربن باید مصرف شود.',
              prs: 'ما بسیار روی آن بحث نمودیم که چگونه مالیات کاربن مصرف گردد.',
              tr: 'Karbon vergisinin nasıl kullanılması gerektiği konusunda uzun süre tartıştık.',
              ar: 'لقد تناقشنا طويلاً حول ذلك، أي حول كيفية استخدام ضريبة الكربون.',
              es: 'Hemos debatido largamente sobre ello, sobre cómo debe emplearse el impuesto sobre el carbono.'
            },
            fluentTranslation: {
              en: 'We have discussed at length how the carbon tax revenue should be utilized.',
              fa: 'ما به تفصیل درباره چگونگی تخصیص درآمدهای حاصل از مالیات کربن بحث و تبادل نظر کردیم.',
              prs: 'ما روی چگونگی استفاده موثر از عواید مالیات محیط زیستی بحث مفصل کردیم.',
              tr: 'Karbon vergisinden elde edilecek gelirin nasıl değerlendirileceği konusunu ayrıntılı biçimde ele aldık.',
              ar: 'ناقشنا باستفاضة الآليات والسبل الكفيلة بتخصيص عائدات ضريبة الكربون على النحو الأمثل.',
              es: 'Debatimos detenidamente sobre el destino que debería darse a la recaudación del impuesto al carbono.'
            }
          }
        ]
      },
      practiceTasks: [
        'Ersetzen Sie in fünf Sätzen Substantive durch die passenden Pronominaladverbien.',
        'Verfassen Sie einen Leserbrief an eine Tageszeitung zur Verkehrsberuhigung.'
      ]
    },
    vocabularies: [
      { id: 'b2_2_v1', word: 'die Dekarbonisierung', article: 'die', plural: '-', ipa: '/dekaʁboniˈziːʁʊŋ/', translation: { en: 'decarbonization', fa: 'کربن‌زدایی / حذف سوخت‌های فسیلی', prs: 'کاهش و حذف گازهای کاربنی', tr: 'karbonsuzlaştırma', ar: 'إزالة الكربون / التخلص من الوقود الأحفوري', es: 'descarbonización' } },
      { id: 'b2_2_v2', word: 'die Kreislaufwirtschaft', article: 'die', plural: 'die Kreislaufwirtschaften', ipa: '/ˈkʁaɪ̯slaʊ̯fˌvɪʁtʃaft/', translation: { en: 'circular economy', fa: 'اقتصاد چرخشی / بازیافت‌محور', prs: 'اقتصاد دورانی و استفاده مجدد از مواد', tr: 'döngüsel ekonomi', ar: 'الاقتصاد الدائري', es: 'economía circular' } },
      { id: 'b2_2_v3', word: 'der Nahverkehr', article: 'der', plural: '-', ipa: '/ˈnaːfɛɐ̯ˌkeːɐ̯/', translation: { en: 'local public transport', fa: 'حمل و نقل عمومی درون‌شهری', prs: 'ترانسپورت عامه شهری', tr: 'yerel toplu taşıma', ar: 'النقل العام المحلي', es: 'transporte público urbano' } }
    ],
    exercises: [
      {
        id: 'ex_b2_2_1',
        type: 'multiple_choice',
        instruction: {
          en: 'Choose the correct prepositional or pronominal adverb to complete the sentence.',
          fa: 'قید ضمیری یا ترکیب حرف اضافه‌ای صحیح را برای تکمیل جمله انتخاب کنید.',
          prs: 'قید ضمیری مناسب را انتخاب کنید.',
          tr: 'Cümleyi tamamlamak için doğru zamirsel zarfı seçiniz.',
          ar: 'اختر الظرف الضميري المناسب لإكمال الجملة بشكل صحيح.',
          es: 'Elige el adverbio pronominal correcto para completar la oración.'
        },
        prompt: 'Die Bürger warten ungeduldig _____, dass der Ausbau der U-Bahn beginnt.',
        options: ['darauf', 'darüber', 'worauf', 'auf ihn'],
        correctAnswer: 'darauf',
        explanation: {
          en: 'The verb is "warten auf + Akkusativ". Referring to the following "dass"-clause requires the anticipatory pronominal adverb "darauf".',
          fa: 'فعل "warten auf" است. اشاره به جمله پیرو "dass" نیازمند قید ضمیری پیش‌درآمد "darauf" است.',
          prs: 'فعل warten auf با جمله dass به قید ضمیری darauf ضرورت دارد.',
          tr: '"warten auf" fiili bir yan cümleye (dass-cümlesi) bağlandığında "darauf" zamirsel zarfı gerektirir.',
          ar: 'الفعل يتعدى بحرف الجر "warten auf"، وللإشارة إلى جملة "dass" التابعة نستخدم الظرف التمهيدي "darauf".',
          es: 'El verbo rige "warten auf". Para anticipar una subordinada con "dass" se utiliza el adverbio pronominal "darauf".'
        }
      }
    ]
  },
  {
    id: 'b2_2_lek2',
    lektionNumber: 2,
    level: 'B2.2',
    title: 'Gesundheitssystem und Patientenrechte',
    subTitle: 'Medizinethik, Klinikalltag und Partizip I & II als Adjektive (B2.2)',
    topic: 'Krankenversicherung, Patientenaufklärung, Partizipialattribute und Nomen-Verb-Gefüge',
    fotoHoergeschichte: {
      title: 'Foto-Hörgeschichte: Die interdisziplinäre Visite am Universitätsklinikum Leipzig',
      imagePrompt: 'A bright modern hospital ward at the University Hospital Leipzig where a senior physician, residents, and nursing staff consult patient records.',
      imageTheme: 'Universitätsklinikum Leipzig',
      audioDuration: '03:15',
      transcript: [
        { speaker: 'Prof. Dr. Hartmann (Chefarzt)', text: 'Guten Morgen, Frau Schultze. Wie haben Sie den gestrigen operativen Eingriff überstanden?' },
        { speaker: 'Frau Schultze (Patientin)', text: 'Danke, Herr Professor. Die postoperativen Schmerzen sind dank der eingestellten Medikation gut erträglich.' },
        { speaker: 'Dr. Meier (Assistenzarzt)', text: 'Die heute Morgen durchgeführten Laboranalysen zeigen eine kontinuierlich abnehmende Entzündungsreaktion.' },
        { speaker: 'Prof. Dr. Hartmann', text: 'Sehr erfreulich. Wenn die Wundheilung weiter fortschreitet, können wir die Entlassung für Freitag in Aussicht stellen.' }
      ],
      summary: {
        en: 'Physicians at Leipzig University Hospital conduct morning rounds, reviewing postoperative patient recovery and lab results.',
        fa: 'پزشکان در بیمارستان دانشگاهی لایپزیگ ویزیت صبحگاهی را انجام داده و نتایج آزمایش‌ها و روند بهبود بیمار را بررسی می‌کنند.',
        prs: 'داکتران در شفاخانه پوهنتون لایپزیگ وضعیت بعد از عملیات جراحی مریضان را بررسی می‌نمایند.',
        tr: 'Leipzig Üniversite Hastanesi\'ndeki hekimler sabah vizitinde ameliyat sonrası iyileşme sürecini ve laboratuvar sonuçlarını değerlendiriyor.',
        ar: 'يقوم الأطباء في مستشفى لايبزيغ الجامعي بجولة الصباح لمتابعة تعافي المرضى بعد الجراحة ونتائج التحاليل.',
        es: 'Médicos del Hospital Universitario de Leipzig pasan visita matutina examinando la recuperación postoperatoria.'
      }
    },
    sectionA: {
      title: 'Mussawi A: Sprechen & Dialog',
      focus: 'Sprechen & Hören (Ärztliche Aufklärungsgespräche)',
      description: {
        en: 'Conduct sensitive doctor-patient consultations, explaining diagnoses and medical interventions clearly.',
        fa: 'انجام مشاوره‌های پزشکی حساس، توضیح شفاف تشخیص‌ها و روش‌های درمانی به بیمار.',
        prs: 'مکالمه میان داکتر و مریض، تشریح وضعیت صحی و پلان معالجه به زبان روان.',
        tr: 'Hassas hekim-hasta görüşmeleri gerçekleştirin, tanı ve tedavi süreçlerini anlaşılır şekilde açıklayın.',
        ar: 'إجراء المحادثات الطبية التوجيهية مع المرضى، وتوضيح التشخيص وخطة العلاج بكل شفافية.',
        es: 'Conducción de consultas médicas, explicando diagnósticos y tratamientos con claridad y empatía.'
      },
      content: 'Wir müssen eine gründliche Anamnese durchführen. / Ich kläre Sie über mögliche Risiken auf.',
      audioText: 'Vor dem geplanten Eingriff ist das schriftliche Einverständnis der Patientin zwingend erforderlich.',
      practiceTasks: [
        'Simulieren Sie ein ärztliches Aufklärungsgespräch vor einer Operation.',
        'Erklären Sie medizinische Fachbegriffe laienverständlich.'
      ]
    },
    sectionB: {
      title: 'Mussawi B: Wortschatz & Hören',
      focus: 'Hören & Wortschatz (Medizin & Gesundheitssystem)',
      description: {
        en: 'Specialized healthcare lexicon: anamnesis, statutory health insurance, co-payment, and clinical referral.',
        fa: 'واژگان تخصصی نظام سلامت: شرح حال، بیمه درمانی قانونی، فرانشیز و برگه ارجاع به متخصص.',
        prs: 'لغات ضروری سیستم صحی: تاریخچه بیماری، بیمه دولتی، سهم پرداختی مریض و برگه راجع ساختن به متخصص.',
        tr: 'Sağlık sistemi terminolojisi: anamnez, yasal sağlık sigortası, katılım payı ve sevk belgesi.',
        ar: 'المصطلحات الطبية ونظام التأمين الصحي: التاريخ المرضي، التأمين الإلزامي، ونموذج التحويل.',
        es: 'Léxico sanitario especializado: anamnesis, seguro médico público, copago y volante de derivación.'
      },
      content: 'die Anamnese, die Gesetzliche Krankenversicherung (GKV), die Zuzahlung, die Überweisung.',
      practiceTasks: [
        'Hören Sie ein Fachgespräch über das deutsche Solidaritätsprinzip in der Krankenversicherung.',
        'Erstellen Sie eine Übersicht über ambulante und stationäre Versorgungsformen.'
      ]
    },
    sectionC: {
      title: 'Mussawi C: Alltagskommunikation',
      focus: 'Sprechen & Dialoge (Ethikkommission & Fallberatung)',
      description: {
        en: 'Deliberate ethical medical decisions in a clinical ethics committee.',
        fa: 'بحث و تصمیم‌گیری درباره پرونده‌های پیچیده اخلاق پزشکی در کمیته اخلاق بالینی.',
        prs: 'بحث‌های تخصصی در کمیته اخلاق داکتری درباره مریضان در وضعیت عاجل.',
        tr: 'Klinik etik kurulunda karmaşık tıp etiği vakalarını müzakere edin.',
        ar: 'التداول الأخلاقي في اللجان الطبية حول الحالات الإكلينيكية المعقدة وحقوق المرضى.',
        es: 'Deliberaciones ético-médicas en comités clínicos sobre casos asistenciales complejos.'
      },
      content: 'Aus ethischer Sicht stellt sich die Frage, inwieweit der Patientenwille hinreichend dokumentiert ist.',
      audioText: 'Die Patientenverfügung entlastet Angehörige und behandelnde Ärzte in schwierigen Entscheidungssituationen.',
      practiceTasks: [
        'Diskutieren Sie über die Bindungswirkung einer Patientenverfügung.',
        'Wägen Sie medizinische Indikation und Patientenautonomie gegeneinander ab.'
      ]
    },
    sectionD: {
      title: 'Mussawi D: Leseverstehen & Text',
      focus: 'Lesen & Textanalyse (Deutsches Ärzteblatt & Patientenrechtegesetz)',
      description: {
        en: 'Analyze legal texts on patients rights and clinical studies in the Deutsches Ärzteblatt.',
        fa: 'تحلیل متون حقوقی منشور حقوق بیمار و مطالعات بالینی در نشریه معتبر پزشکان آلمان.',
        prs: 'مطالعه اسناد حقوقی مریضان و مقالات علمی در مجله طبی آلمان.',
        tr: 'Alman Tabipler Birliği dergisindeki klinik çalışmaları ve hasta hakları yasasını inceleyin.',
        ar: 'تحليل نصوص قانون حقوق المرضى والدراسات الطبية المنشورة في مجلة الأطباء الألمانية.',
        es: 'Análisis de artículos de Deutsches Ärzteblatt y la Ley de Derechos del Paciente.'
      },
      content: 'Auszug aus dem Bürgerlichen Gesetzbuch (§ 630e BGB - Informationspflichten des Behandelnden).',
      readingText: {
        type: 'Gesetzestext (§ 630e Bürgerliches Gesetzbuch)',
        title: 'Aufklärungspflichten im medizinischen Behandlungsvertrag',
        body: 'Der Behandelnde ist verpflichtet, den Patienten über sämtliche für die Einwilligung wesentlichen Umstände aufzuklären. Dazu gehören insbesondere Art, Umfang, Durchführung, zu erwartende Folgen und Risiken der Maßnahme sowie ihre Notwendigkeit, Dringlichkeit, Eignung und Erfolgsaussichten. Die Aufklärung muss mündlich und so rechtzeitig erfolgen, dass der Patient seine Entscheidung wohlüberlegt treffen kann.'
      },
      practiceTasks: [
        'Prüfen Sie, welche Kriterien ein rechtsgültiges Aufklärungsgespräch erfüllen muss.',
        'Fassen Sie die Rechte des Patienten stichpunktartig zusammen.'
      ]
    },
    sectionE: {
      title: 'Mussawi E: Grammatik & Schreiben',
      focus: 'Grammatik & Schreiben (Partizip I und II als Adjektive mit Deklination)',
      description: {
        en: 'Master Partizip I (active/simultaneous: -end) and Partizip II (passive/completed) used as declined attributive adjectives.',
        fa: 'تسلط بر اسم فاعل (Partizip I: -end نشان‌دهنده استمرار و فاعلی بودن) و اسم مفعول (Partizip II نشان‌دهنده اتمام و مفعولی بودن) در نقش صفت با صرف کامل.',
        prs: 'کاربرد صفت‌های فاعلی (-end) و صفت‌های مفعولی با صرف کامل آرتیکل و پسوندها.',
        tr: 'Sıfat olarak kullanılan ve çekimlenen Partizip I (etken/süren: -end) ve Partizip II (edilgen/tamamlanan) yapıları.',
        ar: 'استخدام اسم الفاعل (Partizip I) واسم المفعول (Partizip II) كصفات معربة تتبع المنعوت.',
        es: 'Uso y declinación de participios como adjetivos: Participio I (activo/simultáneo: -end) y Participio II (pasivo/completado).'
      },
      content: 'Partizip I + Adjektivendung (der heilende Prozess) | Partizip II + Adjektivendung (die durchgeführte Operation).',
      grammarRule: {
        id: 'b2_2_partizip_adjektive',
        level: 'B2.2',
        germanTitle: 'Partizip I und II als attributive Adjektive',
        formula: 'Partizip I: Infinitiv + -d + Adjektivendung | Partizip II: Ge- + Stamm + -(e)t/-en + Adjektivendung',
        explanation: {
          en: 'Partizip I represents an active, ongoing action simultaneous with the main verb (der lachende Patient = the laughing patient). Partizip II represents a completed or passive condition (die operierte Patientin = the operated patient). Both take standard adjective endings.',
          fa: 'اسم فاعل (Partizip I) بر عمل هم‌زمان، فعال و جاری دلالت دارد (der heilende Arzt = پزشک درمان‌کننده). اسم مفعول (Partizip II) بر وضعیتی تکمیل‌شده یا مجهول دلالت می‌کند (der behandelte Patient = بیمار درمان‌شده). هر دو همانند صفت‌های عادی صرف می‌شوند.',
          prs: 'اسم فاعل با پسوند d- کار در حال انجام را صفت می‌سازد و اسم مفعول کار انجام یافته یا مجهول را بیان می‌کند.',
          tr: 'Partizip I (-end ekiyle) süregelen ve etken bir eylemi, Partizip II ise tamamlanmış veya edilgen bir durumu niteler. İkisi de sıfat çekim kurallarına tabidir.',
          ar: 'يعبر اسم الفاعل (Partizip I) عن حدث آني ومستمر، في حين يعبر اسم المفعول (Partizip II) عن حدث تام أو مبني للمجهول. وكلاهما يعربان كصفات عادية.',
          es: 'El Participio I (-end) denota acción activa y simultánea. El Participio II indica acción concluida o pasiva. Ambos siguen las reglas de declinación adjetival.'
        },
        examples: [
          {
            german: 'Die behandelnde Ärztin untersuchte den frisch operierten Patienten.',
            formulaBreakdown: 'Die behandelnde (Partizip I + Endung -e) Ärztin untersuchte den frisch operierten (Partizip II + Endung -en) Patienten.',
            literalTranslation: {
              en: 'The treating female doctor examined the freshly operated patient.',
              fa: 'پزشک زن معالجه‌کننده بیمار تازه عمل‌شده را معاینه کرد.',
              prs: 'داکتر زن تداوی‌کننده، مریض تازه عملیات‌شده را معاینه نمود.',
              tr: 'Tedaviyi yürüten kadın hekim, yeni ameliyat edilmiş hastayı muayene etti.',
              ar: 'فحصت الطبيبة المعالِجة المريض الذي خضع لعملية جراحية حديثاً.',
              es: 'La médica responsable examinó al paciente recién operado.'
            },
            fluentTranslation: {
              en: 'The attending physician carefully examined the patient who had just undergone surgery.',
              fa: 'پزشک معالج بیمار را که به تازگی تحت عمل جراحی قرار گرفته بود با دقت معاینه کرد.',
              prs: 'داکتر معالج، مریضی را که تازه جراحی شده بود به گونه دقیق معاینه نمود.',
              tr: 'Sorumlu doktor, kısa süre önce ameliyat olan hastayı ayrıntılı biçimde muayene etti.',
              ar: 'أجرت الطبيبة المعالجة فحصاً دقيقاً للمريض الذي أجرى عملية جراحية للتو.',
              es: 'La médica responsable examinó con esmero al paciente recién intervenido quirúrgicamente.'
            }
          }
        ]
      },
      practiceTasks: [
        'Bilden Sie aus fünf Verben Partizip-I- und Partizip-II-Attribute mit korrekten Deklinationsendungen.',
        'Verfassen Sie einen kurzen Arztbrief über den Genesungsverlauf eines Patienten.'
      ]
    },
    vocabularies: [
      { id: 'b2_2_v4', word: 'die Anamnese', article: 'die', plural: 'die Anamnesen', ipa: '/anamˈneːzə/', translation: { en: 'anamnesis / medical case history', fa: 'شرح حال و سابقه پزشکی بیمار', prs: 'تاریخچه و سابقه صحی مریض', tr: 'hasta öyküsü / anamnez', ar: 'التاريخ المرضي / السيرة المرضية', es: 'anamnesis / historial clínico' } },
      { id: 'b2_2_v5', word: 'die Patientenverfügung', article: 'die', plural: 'die Patientenverfügungen', ipa: '/paˈti̯ɛntn̩fɛɐ̯ˌfyːɡʊŋ/', translation: { en: 'living will / advance healthcare directive', fa: 'وصیت‌نامه پزشکی / دستورالعمل پیشین درمان', prs: 'وصیت‌نامه طبی در مورد ادامه تداوی', tr: 'hasta vasiyeti', ar: 'الوصية الطبية المسبقة', es: 'testamento vital / voluntades anticipadas' } },
      { id: 'b2_2_v6', word: 'der Befund', article: 'der', plural: 'die Befunde', ipa: '/bəˈfʊnt/', translation: { en: 'clinical findings / medical result', fa: 'یافته‌های بالینی / جواب آزمایش و معاینه', prs: 'نتیجه معاینات و تست‌های طبی', tr: 'tıbbi bulgu / rapor sonucu', ar: 'النتيجة الطبية / التقرير التشخيصي', es: 'resultado del diagnóstico / informe clínico' } }
    ],
    exercises: [
      {
        id: 'ex_b2_2_2',
        type: 'multiple_choice',
        instruction: {
          en: 'Select the correct participle and adjective ending.',
          fa: 'صفت مفعولی یا فاعلی و پسوند صرفی صحیح آن را انتخاب کنید.',
          prs: 'پسوند صفت مناسب را انتخاب نمایید.',
          tr: 'Doğru ortaç formunu ve sıfat çekim ekini seçiniz.',
          ar: 'اختر صيغة اسم الفاعل/المفعول واللاحقة الإعرابية الصحيحة.',
          es: 'Selecciona el participio y la desinencia adjetival correcta.'
        },
        prompt: 'Das Pflegepersonal betreut die _____ Patienten auf der Intensivstation.',
        options: ['frisch operierten', 'frisch operierende', 'frisch operiertem', 'frisch operiertes'],
        correctAnswer: 'frisch operierten',
        explanation: {
          en: 'Akkusativ Plural with definite article "die" requires the weak adjective ending "-en" on the Partizip II ("operierten").',
          fa: 'حالت مفعولی مستقیم (Akkusativ) جمع همراه با آرتیکل معین "die" نیازمند پسوند صفت ضعیف "-en" برای اسم مفعول است ("operierten").',
          prs: 'در حالت مفعولی جمع با آرتیکل die پسوند صفت en- می‌باشد.',
          tr: '"die" artikeliyle çoğul ismin Akkusativ halinde sıfat çekim eki "-en" olur ("operierten").',
          ar: 'في حالة النصب للجمع مع أداة التعريف "die" تأخذ الصفة المشتقة اللاحقة الإعرابية الضعيفة "-en".',
          es: 'En acusativo plural con artículo determinado "die", el participio adjetivado recibe la desinencia débil "-en".'
        }
      }
    ]
  },
  {
    id: 'b2_2_lek8',
    lektionNumber: 8,
    level: 'B2.2',
    title: 'Wirtschaft, Globalisierung und Zukunft der Arbeit',
    subTitle: 'Internationale Märkte, Digitalisierung und Konjunktiv I der Vergangenheit',
    topic: 'Handelsbeziehungen, Automatisierung, Konjunktiv I und indirekte Rede im Beruf',
    fotoHoergeschichte: {
      title: 'Foto-Hörgeschichte: Auf der Hannover Messe',
      imagePrompt: 'A cutting-edge industrial robotics exhibition hall at the Hannover Messe with international engineers discussing smart factory automation.',
      imageTheme: 'Hannover Messe Industrie 4.0',
      audioDuration: '02:50',
      transcript: [
        { speaker: 'Ingenieur Schmidt', text: 'Auf der diesjährigen Hannover Messe präsentieren wir vollautomatisierte Produktionssysteme.' },
        { speaker: 'Frau Chen', text: 'Die Wirtschaftsberater berichteten, die Nachfrage nach autonomen Fertigungslinien sei im vergangenen Quartal sprunghaft gestiegen.' },
        { speaker: 'Ingenieur Schmidt', text: 'In der Tat. Dadurch lassen sich Produktionskosten drastisch senken und Ressourcen schonen.' }
      ],
      summary: {
        en: 'Engineers and international trade visitors discuss smart industrial robotics and market dynamics at the Hannover Messe.',
        fa: 'مهندسان و بازرگانان در نمایشگاه صنعتی هانوفر درباره رباتیک و تحولات بازار با ساختار نقل قول غیرمستقیم گفتگو می‌کنند.',
        prs: 'انجینیران و تاجران در نمایشگاه بین‌المللی هانوفر روی اتوماسیون صنعتی و مارکیت جهانی با زبان مسلکی تبادل نظر می‌نمایند.',
        tr: 'Hannover Fuarı\'nda mühendisler sanayi robotları ve pazar eğilimlerini tartışır.',
        ar: 'يناقش المهندسون في معرض هانوفر الصناعي الدولي تقنيات الأتمتة وسوق العمل المستقبلي.',
        es: 'Ingenieros debaten en la Feria de Hannover sobre robótica industrial y globalización.'
      }
    },
    sectionA: {
      title: 'Mussawi A: Sprechen & Dialog',
      focus: 'Sprechen & Hören (Präsentation von Wirtschaftstrends)',
      description: {
        en: 'Present economic forecasts, market trends, and industrial transformations effectively.',
        fa: 'ارائه پیش‌بینی‌های اقتصادی، روندهای بازار و تحولات صنعتی به آلمانی مسلط.',
        prs: 'ارائه تحلیل‌های اقتصادی، روند پیشرفت بازار و تحولات فابریکه‌ها.',
        tr: 'Ekonomik tahminleri ve pazar eğilimlerini akıcı şekilde sunma.',
        ar: 'تقديم التوقعات الاقتصادية واتجاهات السوق بأسلوب احترافي.',
        es: 'Presentación de previsiones económicas y tendencias de mercado.'
      },
      content: 'Die Konjunktur / Die Wachstumsrate / Die Automatisierung / Die Lieferkette.',
      audioText: 'Experten prognostizieren für das kommende Geschäftsjahr eine moderate Zunahme der Exportvolumina.',
      practiceTasks: [
        'Präsentieren Sie eine Grafik zur Entwicklung der Beschäftigtenzahlen.',
        'Diskutieren Sie die Vor- und Nachteile von Homeoffice und mobiler Arbeit.'
      ]
    },
    sectionB: {
      title: 'Mussawi B: Wortschatz & Hören',
      focus: 'Hören & Wortschatz (Wirtschaft & Handel)',
      description: {
        en: 'Business vocabulary: inflation, trade balance, supply chains, and market share.',
        fa: 'واژگان تخصصی تجارت و اقتصاد: تورم، تراز تجاری، زنجیره تامین و سهم بازار.',
        prs: 'لغات تخصصی اقتصاد: تورم، بیلانس تجارتی، زنجیره اکمالات و سهم بازار.',
        tr: 'Ticaret sözlüğü: enflasyon, ticaret dengesi ve pazar payı.',
        ar: 'مفردات الاقتصاد والتجارة: التضخم، الميزان التجاري، وسلاسل التوريد.',
        es: 'Léxico económico: inflación, balanza comercial y cuota de mercado.'
      },
      content: 'die Inflation, die Handelsbilanz, der Marktanteil, die Wertschöpfungskette.',
      audioText: 'Ein stabiler Binnenmarkt bildet das Rückgrat der mitteleuropäischen Wirtschaftsordnung.',
      practiceTasks: [
        'Analysieren Sie einen Wirtschaftskommentar zu Zinsänderungen.',
        'Erläutern Sie die Funktionsweise einer globalen Wertschöpfungskette.'
      ]
    },
    sectionC: {
      title: 'Mussawi C: Alltagskommunikation',
      focus: 'Sprechen & Dialoge (Verhandlungsführung & Kompromissfindung)',
      description: {
        en: 'Negotiate contracts, handle commercial disputes, and find balanced trade compromises.',
        fa: 'مذاکره قراردادها، حل اختلافات تجاری و دستیابی به مصالحه‌های متعادل.',
        prs: 'مذاکرات تجارتی، حل منازعات قراردادی و رسیدن به توافق متوازن.',
        tr: 'Sözleşme müzakereleri yapma ve ticari uzlaşmalar sağlama.',
        ar: 'التفاوض التجاري وحل النزاعات والتوصل إلى تسويات متوازنة.',
        es: 'Negociación de contratos y resolución de discrepancias comerciales.'
      },
      content: 'Wir schlagen folgenden Kompromiss vor... / Auf dieser Grundlage können wir einwilligen.',
      audioText: 'Wenn Sie uns bei den Zahlungszielen entgegenkommen, sind wir bereit, das Auftragsvolumen zu erhöhen.',
      practiceTasks: [
        'Simulieren Sie eine Preisverhandlung zwischen Zulieferer und Großkunde.',
        'Formulieren Sie einen schriftlichen Gegenvorschlag.'
      ]
    },
    sectionD: {
      title: 'Mussawi D: Leseverstehen & Text',
      focus: 'Lesen & Textanalyse (Wirtschaftsanalysen & Branchenberichte)',
      description: {
        en: 'Comprehend complex business articles on globalization and automation.',
        fa: 'درک مقالات تخصصی اقتصادی درباره جهانی‌سازی و اتوماسیون صنعتی.',
        prs: 'خواندن مقالات پیچیده درباره تجارت بین‌الملل و آینده بازار کار.',
        tr: 'Küreselleşme ve otomasyon üzerine karmaşık ekonomi yazılarını anlama.',
        ar: 'فهم المقالات الاقتصادية المعقدة حول العولمة ومستقبل العمل.',
        es: 'Comprensión de artículos económicos sobre globalización y automatización.'
      },
      content: 'Auszug aus einer volkswirtschaftlichen Analyse zum Strukturwandel.',
      readingText: {
        type: 'Wirtschaftsmagazin',
        title: 'Der Strukturwandel der mitteleuropäischen Industrie',
        body: 'Die vierte industrielle Revolution verändert nicht nur Produktionsabläufe, sondern stellt auch tradierte Arbeitsmarktmodelle infrage. Unternehmen, die frühzeitig in KI-gestützte Logistik investiert haben, konnten ihre Marktposition konsolidieren.'
      },
      practiceTasks: [
        'Fassen Sie die Herausforderungen des Strukturwandels schriftlich zusammen.',
        'Erörtern Sie den Begriff "Industrie 4.0".'
      ]
    },
    sectionE: {
      title: 'Mussawi E: Grammatik & Schreiben',
      focus: 'Grammatik & Schreiben (Konjunktiv I der Vergangenheit in der indirekten Rede)',
      description: {
        en: 'Report past statements objectively using Konjunktiv I of the past: "sei + Partizip II" / "habe + Partizip II".',
        fa: 'گزارش وقایع گذشته در نقل قول غیرمستقیم با کُنیونکتیو ۱ گذشته: ترکیب sei/habe به علاوه اسم مفعول.',
        prs: 'نقل قول بی‌طرفانه از اظهارات گذشته با استفاده از Konjunktiv I زمان گذشته.',
        tr: 'Geçmiş ifadeleri dolaylı anlatımda nesnel aktarma: "sei / habe + Partizip II".',
        ar: 'نقل التصريحات السابقة بموضوعية باستخدام صيغة Konjunktiv I للماضي.',
        es: 'Estilo indirecto en pasado con Konjunktiv I: "sei / habe + Participio II".'
      },
      content: 'Konjunktiv I Vergangenheit: sei/habe + Partizip II ("Der Sprecher betonte, die Exporte seien gestiegen").',
      grammarRule: {
        id: 'b2_2_konjunktiv1_past',
        level: 'B2.2',
        germanTitle: 'Konjunktiv I der Vergangenheit (Indirekte Rede)',
        formula: 'Subjekt + sei / habe (Konjunktiv I) + Partizip II',
        explanation: {
          en: 'To report what someone said happened in the past, use the auxiliary verb in Konjunktiv I ("sei" for movement/state change, "habe" for transitive/other verbs) + Partizip II.',
          fa: 'برای نقل قول بی‌طرفانه رخدادهای گذشته، فعل کمکی را در فرم کُنیونکتیو ۱ قرار داده (sei یا habe) و اسم مفعول فعل اصلی را در انتهای جمله می‌آوریم.',
          prs: 'برای نقل قول وقایع گذشته، فعل کمکی sei یا habe را با صفت مفعولی به کار می‌بریم.',
          tr: 'Geçmişte yaşanan olayları dolaylı aktarırken yardımcı fiil Konjunktiv I formunda ("sei" veya "habe") kullanılır ve ana fiilin Partizip II hali sona gelir.',
          ar: 'لنقل الأحداث الماضية بأسلوب غير مباشر نستخدم الفعل المساعد بصيغة Konjunktiv I متبوعاً باسم المفعول في نهاية الجملة.',
          es: 'Para reproducir declaraciones sobre el pasado en estilo indirecto se emplea el auxiliar en Konjunktiv I ("sei/habe") seguido del participio.'
        },
        examples: [
          {
            german: 'Der Regierungssprecher erklärte, die Steuereinnahmen seien im vergangenen Quartal deutlich gestiegen.',
            formulaBreakdown: 'Der Sprecher erklärte + [die Einnahmen (S) + seien (sei-Form) + deutlich (Adv) + gestiegen (Partizip II)].',
            literalTranslation: {
              en: 'The government spokesperson declared, the tax revenues be in the past quarter clearly risen.',
              fa: 'سخنگوی دولت اعلام کرد که درآمدهای مالیاتی در فصل گذشته به وضوح افزایش یافته است.',
              prs: 'سخنگوی حکومت اظهار داشت که عواید مالیاتی در ربع گذشته افزایش یافته است.',
              tr: 'Hükümet sözcüsü, vergi gelirlerinin geçen çeyrekte belirgin şekilde arttığını açıkladى.',
              ar: 'صرّح المتحدث باسم الحكومة بأن العائدات الضريبية قد ارتفعت بشكل ملحوظ خلال الربع الماضي.',
              es: 'El portavoz del gobierno declaró que los ingresos fiscales habrían aumentado sensiblemente en el último trimestre.'
            },
            fluentTranslation: {
              en: 'The government spokesperson stated that tax revenues had risen significantly in the previous quarter.',
              fa: 'سخنگوی دولت تصریح کرد که درآمدهای مالیاتی در سه‌ماهه گذشته رشد چشمگیری داشته است.',
              prs: 'سخنگوی دولت خاطرنشان ساخت که عواید مالیاتی در سه ماه قبل رشد قابل توجهی را نشان داده است.',
              tr: 'Hükümet sözcüsü, vergi gelirlerinde geçtiğimiz çeyrek dönemde kayda değer bir artış gerçekleştiğini bildirdi.',
              ar: 'أوضح المتحدث باسم الحكومة أن الإيرادات الضريبية شهدت زيادة ملموسة في الربع المنصرم.',
              es: 'El portavoz gubernamental indicó que la recaudación tributaria se había incrementado de forma notable durante el último trimestre.'
            }
          }
        ]
      },
      practiceTasks: [
        'Setzen Sie drei Aussagen von Unternehmensvertretern in den Konjunktiv I der Vergangenheit.',
        'Verfassen Sie einen Zeitungsbericht über eine Pressekonferenz.'
      ]
    },
    vocabularies: [
      { id: 'b2_2_v7', word: 'die Konjunktur', article: 'die', plural: '-', ipa: '/kɔnjʊŋkˈtuːɐ̯/', translation: { en: 'economic cycle / market trend', fa: 'اوضاع و رونق اقتصادی / چرخه بازار', prs: 'روند بازار و وضعیت اقتصادی', tr: 'konjonktür / ekonomik gidişat', ar: 'الحركة الاقتصادية / الدورة الاقتصادية', es: 'coyuntura económica' } },
      { id: 'b2_2_v8', word: 'die Wertschöpfungskette', article: 'die', plural: 'die Wertschöpfungsketten', ipa: '/ˈveːɐ̯tˌʃœp͡fʊŋskɛtə/', translation: { en: 'value-added chain / supply chain', fa: 'زنجیره ارزش / فرایند خلق ارزش افزوده', prs: 'زنجیره تولید و ارزش افزوده', tr: 'değer zinciri', ar: 'سلسلة القيمة المضافة', es: 'cadena de valor' } },
      { id: 'b2_2_v9', word: 'die Rendite', article: 'die', plural: 'die Renditen', ipa: '/ʁɛnˈdiːtə/', translation: { en: 'return on investment / yield', fa: 'بازدهی سرمایه‌گذاری / سود سهام', prs: 'مفاد و بازده سرمایه', tr: 'getiri / rantabilite', ar: 'العائد الاستثماري / المردود المالي', es: 'rentabilidad / rendimiento' } }
    ],
    exercises: [
      {
        id: 'ex_b2_2_3',
        type: 'multiple_choice',
        instruction: {
          en: 'Choose the correct Konjunktiv I form for reporting a past action.',
          fa: 'فرم صحیح کُنیونکتیو ۱ برای نقل قول کار انجام‌شده در گذشته را انتخاب کنید.',
          prs: 'فرم صحیح کُنیونکتیو ۱ در زمان گذشته را انتخاب نمایید.',
          tr: 'Geçmiş bir eylemi aktarırken kullanılan doğru Konjunktiv I formunu seçiniz.',
          ar: 'اختر صيغة Konjunktiv I الصحيحة لنقل حدث وقع في الماضي.',
          es: 'Elige la forma correcta de Konjunktiv I para reproducir una acción pasada.'
        },
        prompt: 'Die Zeitung meldet: "Der Konzern _____ im letzten Jahr hohe Gewinne erzielt."',
        options: ['habe', 'hätte', 'hat', 'sei'],
        correctAnswer: 'habe',
        explanation: {
          en: 'For transitive verbs like "erzielen", the past in Konjunktiv I uses "habe + Partizip II".',
          fa: 'برای افعال متعدی مانند "erzielen"، زمان گذشته در نقل قول غیرمستقیم از "habe + Partizip II" تشکیل می‌شود.',
          prs: 'برای فعل erzielen در نقل قول گذشته از habe + Partizip II استفاده می‌گردد.',
          tr: '"Erzielen" geçişli fiili için geçmişte dolaylı anlatım "habe + Partizip II" yapısıyla kurulur.',
          ar: 'للأفعال المتعدية مثل "erzielen" تُصاغ صيغة الماضي غير المباشر بالتركيب "habe + اسم المفعول".',
          es: 'Para verbos transitivos como "erzielen", el pasado en Konjunktiv I se forma con "habe + participio".'
        }
      }
    ]
  }
];
