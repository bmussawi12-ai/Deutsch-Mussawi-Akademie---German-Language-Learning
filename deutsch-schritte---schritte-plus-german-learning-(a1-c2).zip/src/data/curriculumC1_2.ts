import { Lesson } from '../types';

export const CURRICULUM_C1_2: Lesson[] = [
  {
    id: 'c1_2_lek8',
    lektionNumber: 8,
    level: 'C1.2',
    title: 'Akademischer Diskurs und Wissenschaftssprache',
    subTitle: 'Wissenschaftliches Schreiben, Forschungsmethoden und erweiterte Partizipialattribute',
    topic: 'Forschungskolloquium, Methodologie, Peer-Review und Partizip I/II mit Attributen',
    fotoHoergeschichte: {
      title: 'Foto-Hörgeschichte: Das interdisziplinäre Forschungskolloquium an der LMU',
      imagePrompt: 'A historic lecture hall at Ludwig Maximilian University in Munich with professors and doctoral candidates reviewing scientific graphs and debating empirical results.',
      imageTheme: 'LMU München Kolloquium',
      audioDuration: '03:10',
      transcript: [
        { speaker: 'Prof. Dr. von Weizsäcker', text: 'Meine Damen und Herren, wir eröffnen die heutige Disputation mit der von Frau Dr. Nematullah eingereichten Monografie.' },
        { speaker: 'Dr. Nematullah', text: 'Herzlichen Dank! Die den empirischen Erhebungen zugrunde liegenden Daten weisen signifikante Korrelationen auf.' },
        { speaker: 'Prof. Lindemann', text: 'Gestatten Sie einen methodischen Einwand bezüglich der von Ihnen angewendeten statistischen Signifikanztests?' },
        { speaker: 'Dr. Nematullah', text: 'Selbstverständlich. Sämtliche in Betracht gezogenen Störvariablen wurden durch multivariate Kontrollgruppenverfahren neutralisiert.' },
        { speaker: 'Prof. Dr. von Weizsäcker', text: 'Diese methodisch lückenlos untermauerte Argumentation überzeugt uns in vollem Umfang.' }
      ],
      summary: {
        en: 'Doctoral candidate Dr. Nematullah defends her scientific dissertation at LMU Munich using sophisticated academic language and expanded participial attributes.',
        fa: 'دکتر نعمت‌الله پایان‌نامه دکترای خود را در دانشگاه لودویگ ماکسیمیلیان مونیخ با زبانی فاخر، دانشگاهی و ساختارهای پیشرفته صفتی دفاع می‌کند.',
        prs: 'دوکتور نعمت‌الله از تیزس علمی دوکتورای خود در پوهنتون مونیخ با استفاده از اصطلاحات بلند رتبه علمی، صفات مفعولی پیوسته و استدلال اکادمیک دفاع می‌نماید.',
        tr: 'Dr. Nematullah, Münih LMU Üniversitesi\'nde doktora tezini yüksek akademik üslup ve genişletilmiş sıfat tamlamalarıyla savunur.',
        ar: 'تدافع الدكتورة نعمت الله عن أطروحتها العلمية في جامعة ميونيخ مستخدمة لغة أكاديمية رصينة.',
        es: 'La Dra. Nematullah defiende su tesis doctoral en la Universidad LMU de Múnich empleando registro académico avanzado.'
      }
    },
    sectionA: {
      title: 'Mussawi A: Sprechen & Dialog',
      focus: 'Sprechen & Hören (Akademische Disputation & Fachdiskussion)',
      description: {
        en: 'Engage in academic disputes, question scientific methodologies diplomatically, and defend empirical findings.',
        fa: 'مشارکت در مناظرات دانشگاهی، نقد دیپلماتیک روش تحقیق و دفاع از یافته‌های تجربی.',
        prs: 'اشتراک در مباحثات علمی پوهنتونی، ارزیابی روش تحقیق و دفاع از نتایج تجربی.',
        tr: 'Akademik tartışmalara katılma, yöntem eleştirisi yapma ve bilimsel bulguları savunma.',
        ar: 'المشاركة في المناظرات الأكاديمية ونقد مناهج البحث بأسلوب علمي رصين.',
        es: 'Participación en debates académicos, crítica metodológica y defensa de tesis.'
      },
      content: 'Die vorgelegten Thesen bedürfen einer kritischen Überprüfung. / Die den Untersuchungen zugrunde liegende Hypothese lässt sich empirisch verifizieren.',
      audioText: 'In Anbetracht der aktuellen Studienlage erscheint die von den Autoren vertretene Schlussfolgerung durchaus plausibel, wenngleich weitere Langzeitbeobachtungen vonnöten sind.',
      practiceTasks: [
        'Formulieren Sie einen begründeten wissenschaftlichen Einwand gegen eine statistische Erhebung.',
        'Präsentieren Sie ein Forschungsvorhaben im akademischen Register.'
      ]
    },
    sectionB: {
      title: 'Mussawi B: Wortschatz & Hören',
      focus: 'Hören & Wortschatz (Wissenschaftliche Terminologie & Epistemologie)',
      description: {
        en: 'Master lexical fields of research design: causality, correlation, validation, peer-review, and falsification.',
        fa: 'تسلط بر حوزه واژگانی روش پژوهش: علیت، همبستگی، اعتبارسنجی، داوری همتا و ابطال‌پذیری.',
        prs: 'تسلط بر لغات تخصصی تحقیق علمی: علیت، ارتباط احصائیوی، ابطال‌پذیری و داوری مقالات.',
        tr: 'Bilimsel metodoloji terimleri: nedensellik, korelasyon, akran denetimi ve yanlışlanabilirlik.',
        ar: 'إتقان المصطلحات العلمية الدقيقة: السببية، الارتباط الإحصائي، التحكيم العلمي.',
        es: 'Términos de diseño de investigación: causalidad, correlación y validación empírica.'
      },
      content: 'die Kausalität, die Korrelation, die Falsifizierbarkeit, das Peer-Review-Verfahren, die Evidenz, die Kohärenz.',
      audioText: 'Das Peer-Review-Verfahren garantiert die wissenschaftliche Güte und Unabhängigkeit der im Fachjournal publizierten Ergebnisse.',
      practiceTasks: [
        'Unterscheiden Sie präzise zwischen Kausalität und bloßer Koinzidenz.',
        'Verfassen Sie ein kurzes Fach-Abstract für einen wissenschaftlichen Zeitschriftenartikel.'
      ]
    },
    sectionC: {
      title: 'Mussawi C: Alltagskommunikation',
      focus: 'Sprechen & Dialoge (Wissenschaftsvermittlung & Moderation)',
      description: {
        en: 'Moderate academic panels, synthesize contradictory theories, and communicate complex phenomena accessibly.',
        fa: 'مدیریت و مدیریت میزگردهای علمی، تلفیق نظریه‌های متناقض و تشریح پدیده‌های پیچیده به شکلی گویا.',
        prs: 'گردانندگی میزگردهای علمی، جمع‌بندی نظریات مختلف پوهنتونی و انتقال مفاهیم دشوار.',
        tr: 'Akademik panelleri yönetme, çelişkili tezleri sentezleme ve bilim iletişimi.',
        ar: 'إدارة الندوات العلمية، التوفيق بين النظريات المتعارضة وتبسيط المعرفة.',
        es: 'Moderación de mesas redondas académicas y divulgación de conceptos complejos.'
      },
      content: 'Zusammenfassend lässt sich konstatieren... / Wir müssen die konträren Positionen dialektisch abwägen.',
      audioText: 'Erlauben Sie mir, die wesentlichen Kontroversen unserer bisherigen Debatte kurz zusammenzuführen: Während die Verfechter des quantitativen Ansatzes...',
      practiceTasks: [
        'Moderieren Sie eine simulierte universitäre Podiumsdiskussion.',
        'Fassen Sie zwei konträre Forschungsergebnisse neutral und syntheseorientiert zusammen.'
      ]
    },
    sectionD: {
      title: 'Mussawi D: Leseverstehen & Text',
      focus: 'Lesen & Textanalyse (Fachaufsatz & Monografie)',
      description: {
        en: 'Analyze high-density academic papers featuring nominal style, footnotes, and advanced syntactic embedding.',
        fa: 'تحلیل مقالات تخصصی علمی با چگالی بالا، ساختارهای اسمی (Nominalstil) و پاورقی‌های پژوهشی.',
        prs: 'تحلیل مقالات علمی تخصصی با ساختار اسمی فشرده، سبک پوهنتونی و ارجاعات تحقیقی.',
        tr: 'Yoğun akademik makaleleri, isimleşmiş yapıları (Nominalstil) ve dipnotları analiz etme.',
        ar: 'تحليل الأبحاث الأكاديمية المحكمة ذات البنية الاسمية المكثفة والتعقيد التركيبي.',
        es: 'Análisis de artículos científicos densos, nominalizaciones y notas al pie.'
      },
      content: 'Auszug aus einer soziologischen Fachpublikation.',
      readingText: {
        type: 'Wissenschaftlicher Fachartikel',
        title: 'Die Transformation gesellschaftlicher Wissensordnungen im Zeitalter digitaler Netzwerke',
        body: 'Die durch die ubiquitäre Verbreitung digitaler Informationsarchitekturen hervorgerufene Rekonfiguration epistemischer Deutungshoheiten stellt tradierte Institutionen vor fundamentale Legitimitätsprobleme. An die Stelle diskursiv vermittelter, institutionell beglaubigter Urteile tritt eine algorithmisch gesteuerte Aggregation individueller Nutzerpräferenzen. Dieses Phänomen bedarf einer eingehenden theoretischen Durchdringung, um den erodierenden Konsens bezüglich wissenschaftlicher Evidenz adäquat zu begreifen.'
      },
      practiceTasks: [
        'Lösen Sie die Nominalstrukturen des Textes in entsprechende Verbalsätze auf.',
        'Erläutern Sie den Kernbegriff "epistemische Deutungshoheit" mit eigenen Worten.'
      ]
    },
    sectionE: {
      title: 'Mussawi E: Grammatik & Schreiben',
      focus: 'Grammatik & Schreiben (Erweiterte Partizipialattribute: Partizip I & II mit Attributketten)',
      description: {
        en: 'Transform relative clauses into high-register expanded participial attributes and vice versa.',
        fa: 'تبدیل جملات موصولی به ساختارهای صفتی گسترش‌یافته با اسم فاعل و مفعول (Partizipialattribute) و بالعکس.',
        prs: 'یادگیری صفات مفعولی و فاعلی گسترش‌یافته (Partizipialattribute) برای متون عالی و نگارش مقالات علمی.',
        tr: 'Genişletilmiş sıfat tamlamaları (Partizip I ve II ile kurulan karmaşık yapılar).',
        ar: 'تحويل الجمل الموصولة إلى تراكيب نعتية مركبة باستخدام اسم الفاعل واسم المفعول الموسع.',
        es: 'Transformación de oraciones de relativo en atributos participiales expandidos.'
      },
      content: 'Relativsatz: "Das Gesetz, das vom Bundestag beschlossen wurde" -> Partizipialattribut: "Das vom Bundestag beschlossene Gesetz".',
      grammarRule: {
        id: 'c1_2_partizipial_rule',
        level: 'C1.2',
        germanTitle: 'Erweiterte Partizipialattribute (Partizip I & II vor dem Nomen)',
        formula: 'Artikel + [Erweiternde Angaben] + Partizip (dekliniert) + Nomen',
        explanation: {
          en: 'In written academic and administrative German (C1/C2), relative clauses are compressed into expanded participial attributes placed directly between the article and the noun. Partizip I indicates ongoing active processes (+ d + adjective ending); Partizip II indicates completed or passive actions.',
          fa: 'در زبان دانشگاهی و اداری پیشرفته (C1/C2)، جملات موصولی طولانی فشرده شده و به عنوان صفت مرکب، مستقیماً میان آرتیکل و اسم قرار می‌گیرند. اسم فاعل (Partizip I) بر عمل در جریان و فعال دلالت دارد، و اسم مفعول (Partizip II) بر عمل پایان‌یافته یا مجهول.',
          prs: 'در سبک رسمی و اکادمیک، به جای جملات پیوندی طولانی، از صفات پیوسته پیش از اسم استفاده می‌شود. Partizip I جریان کار را نشان می‌دهد و Partizip II کار تکمیل‌شده یا مجهول را بیان می‌دارد.',
          tr: 'C1/C2 düzeyindeki akademik Almancada, yan cümleler sıkıştırılarak artikel ile isim arasına genişletilmiş sıfat olarak yerleştirilir.',
          ar: 'في الأسلوب الأكاديمي المتقدم يتم تكثيف الجمل الموصولة ووضعها كنعت مركب بين أداة التعريف والاسم.',
          es: 'En el registro académico culto, las oraciones de relativo se condensan en sintagmas participiales entre el artículo y el sustantivo.'
        },
        examples: [
          {
            german: 'Die den empirischen Untersuchungen zugrunde liegenden Daten wurden sorgfältig verifiziert.',
            formulaBreakdown: 'Die (Artikel) + den empirischen Untersuchungen zugrunde liegenden (erweitertes Partizip I) + Daten (Nomen).',
            literalTranslation: {
              en: 'The to-the empirical investigations at-basis lying data were carefully verified.',
              fa: 'داده‌های مبنا قرار گرفته برای تحقیقات تجربی، با دقت راستی‌آزمایی شدند.',
              prs: 'معلومات و احصائیه اساسی این تحقیق تجربی با دقت تمام ارزیابی و تایید گردید.',
              tr: 'Empirik araştırmaların temelini oluşturan veriler titizlikle doğrulandı.',
              ar: 'تم التحقق بدقة من البيانات التي تستند إليها الأبحاث التجريبية.',
              es: 'Los datos que sirven de base a las investigaciones empíricas fueron cuidadosamente verificados.'
            },
            fluentTranslation: {
              en: 'The data underlying the empirical investigations have been thoroughly verified.',
              fa: 'داده‌هایی که پایه و اساس پژوهش‌های تجربی را تشکیل می‌دهند، با دقت تمام مورد راستی‌آزمایی قرار گرفتند.',
              prs: 'معلومات ارقام و اعدادی که اساس این پژوهش عملی را می‌سازند، با دقت بسیار تصدیق گردیدند.',
              tr: 'Deneysel araştırmaların temelini oluşturan veriler titizlikle teyit edildi.',
              ar: 'جرى التحقق بكل عناية من البيانات التي تشكل الأساس للدراسات التجريبية.',
              es: 'Los datos que sustentan las investigaciones empíricas se verificaron exhaustivamente.'
            }
          },
          {
            german: 'Das von der Forschungsgruppe neu entwickelte Verfahren senkt die Fehlerquote signifikant.',
            formulaBreakdown: 'Das (Artikel) + von der Forschungsgruppe neu entwickelte (erweitertes Partizip II) + Verfahren (Nomen).',
            literalTranslation: {
              en: 'The by the research-group newly developed procedure lowers the error-rate significantly.',
              fa: 'روش به تازگی توسعه یافته توسط گروه پژوهشی، ضریب خطا را به طور معناداری کاهش می‌دهد.',
              prs: 'طریقه نوی که توسط گروه تحقیقاتی ایجاد شده، فیصدی اشتباه را به پیمانه قابل ملاحظه کم می‌سازد.',
              tr: 'Araştırma grubu tarafından yeni geliştirilen yöntem hata oranını belirgin biçimde düşürmektedir.',
              ar: 'يقلل الإجراء المطور حديثاً من قِبل المجموعة البحثية نسبة الخطأ بشكل ملحوظ.',
              es: 'El procedimiento desarrollado recientemente por el grupo de investigación reduce significativamente el margen de error.'
            },
            fluentTranslation: {
              en: 'The new method developed by the research team significantly reduces the error margin.',
              fa: 'روش جدید ابداع‌شده توسط تیم پژوهشی، نرخ خطا را به میزان چشمگیری پایین می‌آورد.',
              prs: 'طریقه کار تازه‌ای که توسط تیم علمی انکشاف یافته است، میزان اشتباهات را به گونه بارزی کاهش می‌دهد.',
              tr: 'Araştırma ekibinin yeni geliştirdiği yöntem hata oranını kayda değer ölçüde azaltmaktadır.',
              ar: 'تؤدي المنهجية الجديدة التي طورها الفريق البحثي إلى خفض نسبة الخطأ بصورة لافتة.',
              es: 'El nuevo método ideado por el equipo investigador reduce sustancialmente el porcentaje de fallos.'
            }
          }
        ]
      },
      practiceTasks: [
        'Lösen Sie folgendes Partizipialattribut in einen Relativsatz auf: "die von den Wissenschaftlern unlängst publizierten Ergebnisse".',
        'Bilden Sie ein erweitertes Partizip I aus: "die Studierenden, die im Hörsaal fleißig mitschreiben".'
      ]
    },
    vocabularies: [
      { id: 'c1_2_v1', word: 'die Monografie', article: 'die', plural: 'die Monografien', ipa: '/monoɡʁaˈfiː/', translation: { en: 'monograph / academic treatise', fa: 'تک‌نگاری / کتاب پژوهشی تخصصی', prs: 'اثر تحقیقی / کتاب رساله علمی', tr: 'monografi', ar: 'دراسة أحادية / أطروحة متخصصة', es: 'monografía' } },
      { id: 'c1_2_v2', word: 'die Kausalität', article: 'die', plural: 'die Kausalitäten', ipa: '/kaʊ̯zaliˈtɛːt/', translation: { en: 'causality', fa: 'رابطه علیتی / اصل علیت', prs: 'رابطه علت و معلول (علیت)', tr: 'nedensellik', ar: 'السببية / العِلّية', es: 'causalidad' } },
      { id: 'c1_2_v3', word: 'die Falsifizierbarkeit', article: 'die', plural: 'die Falsifizierbarkeiten', ipa: '/falzifiˈtsiːɐ̯baːɐ̯kaɪ̯t/', translation: { en: 'falsifiability', fa: 'ابطال‌پذیری علمی', prs: 'قابلیت ابطال علمی', tr: 'yanlışlanabilirlik', ar: 'القابلية للدحض / التفنيد العلمي', es: 'falsabilidad' } },
      { id: 'c1_2_v4', word: 'die Disputation', article: 'die', plural: 'die Disputationen', ipa: '/dɪsputaˈtsi̯oːn/', translation: { en: 'doctoral oral defense', fa: 'جلسه دفاع شفاهی دکترا', prs: 'جلسه دفاع علمی دوکتورا', tr: 'tez savunması', ar: 'مناقشة أطروحة الدكتوراه', es: 'defensa pública de tesis' } },
      { id: 'c1_2_v5', word: 'das Postulat', article: 'das', plural: 'die Postulate', ipa: '/pɔstuˈlaːt/', translation: { en: 'postulate / axiom', fa: 'اصل موضوع / فرض بنیادین', prs: 'اصل اساسی / فرضیه پذیرفته‌شده', tr: 'önerme / postulat', ar: 'مُسلّمة علمية / فرضية بديهية', es: 'postulado' } }
    ],
    videoClip: {
      title: 'Akademische Disputation und Kolloquium',
      scenario: 'Ein Doktorand verteidigt seine Dissertation über KI-Ethik vor der Prüfungskommission an der LMU München.',
      category: 'interview',
      duration: '03:10',
      speakers: ['Prof. Dr. Weber', 'Doktorand'],
      keyPhrases: [
        'Die vorgelegten empirischen Befunde stützen diese These.',
        'Es gilt zu differenzieren zwischen Korrelation und Kausalität.',
        'Unter methodologischen Gesichtspunkten ist dieser Einwand berechtigt.'
      ],
      germanTranscript: [
        'Prof. Dr. Weber: Herr Kandidat, wie begegnen Sie dem Vorwurf, Ihre Methodik basiere auf einer selektiven Stichprobe?',
        'Doktorand: Frau Professorin, die in Kapitel 4 detailliert dargelegten Daten wurden mittels eines doppelblinden Verfahrens erhoben.',
        'Prof. Dr. Weber: Dennoch lässt sich eine gewisse Kausalitätsunsicherheit nicht gänzlich von der Hand weisen.',
        'Doktorand: Dieser Einwand ist methodologisch nachvollziehbar; allerdings bestätigen die Replikationsstudien unsere Grundannahme.',
        'Prof. Dr. Weber: Eine schlüssige Argumentation. Die Kommission wird sich nun zur Beratung zurückziehen.'
      ],
      translatedTranscript: [
        {
          en: 'Prof. Dr. Weber: Candidate, how do you address the criticism that your methodology is based on a selective sample?',
          fa: 'پروفسور وبر: داوطلب گرامی، به این انتقاد که روش پژوهش شما بر نمونه‌گیری گزینشی مبتنی است چه پاسخی می‌دهید؟',
          prs: 'پروفسور داکتر ویبر: داوطلب محترم، در برابر این انتقاد که روش تحقیق شما بر نمونه‌گیری انتخابی استوار است چه استدلالی دارید؟',
          tr: 'Prof. Dr. Weber: Sayın aday, metodolojinizin yanlı bir örnekleme dayandığı eleştirisine nasıl yanıt veriyorsunuz?',
          ar: 'أ.د. فيبر: أيها المرشح، كيف ترد على الانتقاد القائل بأن منهجيتك استندت إلى عينة انتقائية؟',
          es: 'Prof. Dra. Weber: Candidato, ¿cómo responde a la objeción de que su metodología se basa en una muestra sesgada?'
        },
        {
          en: 'Doctoral Candidate: Professor, the data detailed in Chapter 4 were collected using a double-blind procedure.',
          fa: 'کاندیدای دکترا: استاد محترم، داده‌های ارائه‌شده در فصل ۴ از طریق شیوه دوسوکور جمع‌آوری شده‌اند.',
          prs: 'داوطلب دوکتورا: استاد محترمه، ارقام و معلومات تشریح‌شده در فصل چهارم از طریق پروسه دقیق دوطرفه‌کور جمع‌آوری شده‌اند.',
          tr: 'Doktora Adayı: Sayın Profesör, 4. bölümde açıklanan veriler çift körleme yöntemiyle toplanmıştır.',
          ar: 'مرشح الدكتوراه: أستاذتي الفاضلة، إن البيانات المعروضة في الفصل الرابع جُمعت وفق إجراء مزدوج التعمية.',
          es: 'Doctorando: Profesora, los datos expuestos en el capítulo 4 se obtuvieron mediante un procedimiento de doble ciego.'
        },
        {
          en: 'Prof. Dr. Weber: Nevertheless, a certain causal uncertainty cannot be entirely dismissed.',
          fa: 'پروفسور وبر: با این حال، وجود نوعی عدم قطعیت علّی را نمی‌توان کاملاً نادیده گرفت.',
          prs: 'پروفسور داکتر ویبر: با آنهم، یک اندازه عدم اطمینان در رابطه علت و معلول را نمی‌توان کاملاً رد نمود.',
          tr: 'Prof. Dr. Weber: Yine de nedensellik konusundaki belirsizlik bütünüyle göz ardı edilemez.',
          ar: 'أ.د. فيبر: ومع ذلك، لا يمكن استبعاد وجود قدر من عدم اليقين السببي بصورة قاطعة.',
          es: 'Prof. Dra. Weber: No obstante, cierta incertidumbre causal no puede desestimarse por completo.'
        },
        {
          en: 'Doctoral Candidate: This objection is methodologically sound; however, the replication studies corroborate our primary premise.',
          fa: 'کاندیدای دکترا: این اشکال از نظر روش‌شناسی موجه است؛ با این وجود، پژوهش‌های مکرر فرضیه بنیادین ما را تایید می‌کنند.',
          prs: 'داوطلب دوکتورا: این نقد از دید میتودولوژی بجاست؛ اما آزمایش‌ها و تحقیقات مجدد، اصل فرضیه ما را ثابت می‌سازند.',
          tr: 'Doktora Adayı: Bu itiraz metodolojik olarak haklıdır; ancak tekrarlanan çalışmalar temel önermemizi doğrulamaktadır.',
          ar: 'مرشح الدكتوراه: هذا الاعتراض وجيه منهجياً؛ غير أن دراسات إعادة القياس تدعم فرضيتنا الأساسية بقوة.',
          es: 'Doctorando: Dicha objeción es metodológicamente comprensible; no obstante, los estudios de replicación corroboran nuestra premisa.'
        },
        {
          en: 'Prof. Dr. Weber: A coherent argumentation. The committee will now withdraw for deliberation.',
          fa: 'پروفسور وبر: استدلالی منسجم و منطقی بود. اکنون هیئت داوران برای شور و تصمیم‌گیری خارج می‌شوند.',
          prs: 'پروفسور داکتر ویبر: استدلال شما منطقی و قناعت‌بخش بود. اکنون هیئت ژوری برای مشوره و تصمیم‌گیری جلسه را موقتاً ترک می‌کند.',
          tr: 'Prof. Dr. Weber: Tutarlı bir argümantasyon. Komisyon şimdi değerlendirme için çekilecektir.',
          ar: 'أ.د. فيبر: حجة متماسكة ومقنعة. ستنسحب اللجنة الآن للمداولة وإصدار الحكم.',
          es: 'Prof. Dra. Weber: Una argumentación coherente. El tribunal se retirará ahora a deliberar.'
        }
      ]
    },
    examTip: {
      standard: 'C1 (Goethe-Zertifikat C1 & telc C1 Hochschule)',
      module: 'Leseverstehen Teil 1 & Textproduktion',
      tip: {
        en: 'In telc C1 Hochschule reading texts, complex information is almost exclusively compressed using expanded participial attributes. Master identifying the main noun at the end of the chain before parsing the embedded prepositions.',
        fa: 'در آزمون telc C1 Hochschule، اطلاعات پیچیده همواره در قالب صفات گسترش‌یافته پیش از اسم فشرده می‌شوند. ابتدا اسم اصلی در انتهای ترکیب را بیابید و سپس اجزای توصیفی آن را تحلیل کنید.',
        prs: 'در امتحانات C1 برای ورود به پوهنتون‌های آلمان، معلومات علمی با صفات مرکب طولانی پیش از اسم بیان می‌شوند. اول نام اصلی را در اخیر عبارت دریابید و سپس حروف اضافه و تشریحات را معنی کنید.',
        tr: 'telc C1 Hochschule sınavında metinler genişletilmiş sıfat tamlamalarıyla doludur. Önce cümlenin asıl ismini bulun.',
        ar: 'في اختبار telc C1 الجامعي تعتمد النصوص على التراكيب النعتية الموسعة؛ حدد الاسم الرئيسي أولاً لفهم السياق بدقة.',
        es: 'En los textos de nivel C1 académico, identifica primero el sustantivo central al final de la construcción participial.'
      }
    }
  },
  {
    id: 'c1_2_lek9',
    lektionNumber: 9,
    level: 'C1.2',
    title: 'Wirtschaftsethik, Nachhaltigkeit und Funktionsverbgefüge',
    subTitle: 'Corporate Governance, ökologische Transformation und feste Nomen-Verb-Verbindungen',
    topic: 'Nachhaltigkeitsberichte, Lieferkettengesetz, Compliance und Funktionsverbgefüge (in Betracht ziehen / zur Verfügung stehen)',
    fotoHoergeschichte: {
      title: 'Foto-Hörgeschichte: Die außerordentliche Aufsichtsratssitzung in Frankfurt',
      imagePrompt: 'A high-rise boardroom overlooking the Frankfurt banking district skyline where board members examine an ESG corporate compliance report.',
      imageTheme: 'Frankfurt am Main Finanzdistrikt',
      audioDuration: '02:55',
      transcript: [
        { speaker: 'Frau Vorsitzende', text: 'Wir müssen heute die Auswirkungen des neuen Lieferkettengesetzes eingehend in Betracht ziehen.' },
        { speaker: 'Herr Dr. Berger', text: 'Die bisherigen Kontrollmechanismen stellen die Einhaltung ökologischer Standards nicht vollends unter Beweis.' },
        { speaker: 'Frau Vorsitzende', text: 'Deshalb müssen wir den betroffenen Abteilungen substanzielle Ressourcen zur Verfügung stellen.' },
        { speaker: 'Herr Dr. Berger', text: 'Ganz Ihrer Meinung. Andernfalls laufen wir Gefahr, empfindliche Sanktionen seitens der Aufsichtsbehörden auf uns zu ziehen.' },
        { speaker: 'Frau Vorsitzende', text: 'Ich bringe daher den Beschlussantrag zur sofortigen Implementierung eines ESG-Audits zur Abstimmung.' }
      ],
      summary: {
        en: 'The supervisory board of a corporation in Frankfurt deliberates corporate governance and ESG supply chain compliance using business functional verb idioms.',
        fa: 'هیئت نظارت یک شرکت در فرانکفورت، الزامات حاکمیت شرکتی و قانون زنجیره تامین را با ترکیبات اسمی-فعلی پیشرفته بررسی می‌کند.',
        prs: 'جلسه رهبری و نظارت یک شرکت در فرانکفورت، تطبیق قوانین زنجیره تمویل و مسوولیت‌های محیطی را با اصطلاحات عالی تجارتی ارزیابی می‌نماید.',
        tr: 'Frankfurt\'taki bir şirketin denetim kurulu, kurumsal yönetim ve tedarik zinciri uyumluluğunu fonksiyonel fiil kalıplarıyla müzakere eder.',
        ar: 'يناقش مجلس الرقابة في فرانكفورت معايير الحوكمة وسلاسل التوريد باستخدام تراكيب الأفعال الوظيفية.',
        es: 'El consejo de administración debate en Fráncfort sobre gobernanza y sostenibilidad con perífrasis verbales complejas.'
      }
    },
    sectionA: {
      title: 'Mussawi A: Sprechen & Dialog',
      focus: 'Sprechen & Hören (Verhandlungen auf Vorstandsebene)',
      description: {
        en: 'Lead strategic negotiations, present business proposals, and handle corporate compliance discourse.',
        fa: 'هدایت مذاکرات استراتژیک در سطح هیئت مدیره، ارائه طرح‌های تجاری و گفتمان حاکمیت شرکتی.',
        prs: 'پیشبرد مذاکرات مهم اداری و تجارتی در سطح رهبری، و دفاع از پلان‌های اقتصادی.',
        tr: 'Üst düzey yönetim müzakerelerini yürütme, stratejik plan sunma ve kurumsal uyum dili.',
        ar: 'قيادة المفاوضات الاستراتيجية الرفيعة وعرض الخطط والامتثال المؤسسي.',
        es: 'Liderazgo en negociaciones ejecutivas, propuestas de negocio y cumplimiento normativo.'
      },
      content: 'Einen Entschluss fassen / Unter Beweis stellen / Zur Verhandlung stehen / Zum Ausdruck bringen.',
      audioText: 'Wir müssen heute eine wegweisende Weichenstellung vornehmen, um die Marktposition unseres Unternehmens auch künftig abzusichern.',
      practiceTasks: [
        'Formulieren Sie 3 strategische Forderungen unter Verwendung von Funktionsverbgefügen.',
        'Führen Sie ein Streitgespräch über Rentabilität versus ökologische Nachhaltigkeit.'
      ]
    },
    sectionB: {
      title: 'Mussawi B: Wortschatz & Hören',
      focus: 'Hören & Wortschatz (ESG & Lieferkettenverantwortung)',
      description: {
        en: 'Vocabulary for Environmental Social Governance (ESG), audit procedures, circular economy, and labor standards.',
        fa: 'واژگان معیارهای پایداری زیست‌محیطی-اجتماعی (ESG)، حسابرسی سازمانی، اقتصاد چرخشی و استانداردهای کار.',
        prs: 'ذخیره لغات مرتبط به معیارهای محیط‌زیستی، تفتیش مسلکی شرکت‌ها و حقوق کارگران.',
        tr: 'ESG standartları, döngüsel ekonomi, denetim süreçleri ve tedarik zinciri terimleri.',
        ar: 'مفردات الحوكمة البيئية والاجتماعية والاقتصاد الدائري ومعايير العمل الدولية.',
        es: 'Vocabulario de criterios ESG, auditorías, economía circular y derechos laborales.'
      },
      content: 'die Sorgfaltspflicht, das ESG-Rating, die Kreislaufwirtschaft, die Dekarbonisierung, die Transparenzpflicht.',
      audioText: 'Das Lieferkettensorgfaltspflichtengesetz verpflichtet Unternehmen zur lückenlosen Dokumentation menschenrechtlicher Standards bei allen Zulieferern.',
      practiceTasks: [
        'Erklären Sie die 3 Säulen von ESG (Environmental, Social, Governance).',
        'Analysieren Sie einen Nachhaltigkeitsbericht auf Greenwashing-Indikatoren.'
      ]
    },
    sectionC: {
      title: 'Mussawi C: Alltagskommunikation',
      focus: 'Sprechen & Dialoge (Krisenkommunikation & Presseerklärung)',
      description: {
        en: 'Conduct crisis communications, respond to investigative journalism inquiries, and issue formal statements.',
        fa: 'مدیریت ارتباطات در شرایط بحران، پاسخ به سوالات خبرنگاران تحقیقی و صدور بیانیه‌های رسمی مطبوعاتی.',
        prs: 'ارتباطات در وضعیت اضطراری و بحرانی، پاسخ‌گویی به ژورنالیستان و نشر اعلامیه رسمی مطبوعاتی.',
        tr: 'Kriz iletişimi yürütme, araştırmacı gazetecilere yanıt verme ve basın açıklaması yapma.',
        ar: 'إدارة التواصل أثناء الأزمات والرد على الصحافة الاستقصائية وإصدار البيانات الرسمية.',
        es: 'Comunicación de crisis corporativa y redacción de comunicados de prensa institucionales.'
      },
      content: 'Stellung nehmen zu / Vorwürfe von sich weisen / Konsequenzen ziehen aus / Maßnahmen in die Wege leiten.',
      audioText: 'Das Unternehmen nimmt die erhobenen Vorwürfe außerordentlich ernst und hat umgehend eine unabhängige Untersuchungskommission ins Leben gerufen.',
      practiceTasks: [
        'Formulieren Sie eine offizielle Stellungnahme eines Vorstandssprechers.',
        'Reagieren Sie souverän auf kritische Pressefragen bezüglich einer Produktionspanne.'
      ]
    },
    sectionD: {
      title: 'Mussawi D: Leseverstehen & Text',
      focus: 'Lesen & Textanalyse (Wirtschaftsanalysen & Geschäftsberichte)',
      description: {
        en: 'Critique corporate annual reports, financial audits, and regulatory compliance frameworks.',
        fa: 'نقد و بررسی گزارش‌های مالی سالانه شرکت‌ها، ترازنامه‌ها و چارچوب‌های قانون‌گذاری اقتصادی.',
        prs: 'بررسی راپور سالانه مالی شرکت‌ها، حسابرسی اقتصادی و احکام قانونی نظارت بر بازار.',
        tr: 'Şirketlerin yıllık faaliyet raporlarını, bilanço analizlerini ve regülasyon metinlerini okuma.',
        ar: 'تحليل التقارير المالية السنوية للشركات ولوائح الامتثال التنظيمي.',
        es: 'Análisis de balances, informes anuales corporativos y marcos regulatorios.'
      },
      content: 'Auszug aus einem Lagebericht einer DAX-40-Aktiengesellschaft.',
      readingText: {
        type: 'Konzernlagebericht & Risikoberichterstattung',
        title: 'Risikobericht des Vorstands zum Geschäftsjahr 2025/2026',
        body: 'Im abgelaufenen Geschäftsjahr sah sich der Konzern mit einer Verschärfung geopolitischer Verwerfungen konfrontiert. Um den daraus resultierenden Risiken für die Absatzkanäle wirksam zu begegnen, wurden umfassende Restrukturierungsmaßnahmen in Angriff genommen. Durch die Diversifizierung der Beschaffungsmärkte konnte eine substantielle Risikominderung erzielt werden. Gleichwohl bleiben volatile Rohstoffpreise ein nicht zu vernachlässigender Unsicherheitsfaktor.'
      },
      practiceTasks: [
        'Welche konkreten Maßnahmen leitete das Unternehmen zur Abfederung der Risiken ein?',
        'Wie schätzt der Vorstand die künftige Rohstoffpreisentwicklung ein?'
      ]
    },
    sectionE: {
      title: 'Mussawi E: Grammatik & Schreiben',
      focus: 'Grammatik & Schreiben (Funktionsverbgefüge / Nomen-Verb-Verbindungen)',
      description: {
        en: 'Master idiomatic noun-verb combinations that define high-level administrative and business German.',
        fa: 'تسلط بر ترکیبات اسمی-فعلی ثابت (Funktionsverbgefüge) که شاخصه زبان تجاری و اداری سطح بالا هستند.',
        prs: 'یادگیری کامل ترکیبات ثابت اسم و فعل (Funktionsverbgefüge) که در ادارات و تجارت پیشرفته استفاده می‌شوند.',
        tr: 'Yüksek bürokrasi ve iş dünyasında kullanılan fonksiyonel fiil kalıpları (Nomen-Verb-Verbindungen).',
        ar: 'إتقان تراكيب الأفعال الوظيفية التي تميز الأسلوب الرسمي والإداري والاقتصادي المتقدم.',
        es: 'Dominio de perífrasis y combinaciones fijas de sustantivo y verbo del registro profesional culto.'
      },
      content: 'In Betracht ziehen (= berücksichtigen), zur Verfügung stehen (= verfügbar sein), Kritik üben an (= kritisieren).',
      grammarRule: {
        id: 'c1_2_funktionsverb_rule',
        level: 'C1.2',
        germanTitle: 'Funktionsverbgefüge (Nomen-Verb-Verbindungen des gehobenen Stils)',
        formula: 'Präposition + Nomen + Funktionsverb (bringen, ziehen, stehen, stellen, gelangen)',
        explanation: {
          en: 'Functional verb combinations replace simple verbs with a noun + a semantically weakened auxiliary verb. They convey precision, objectivity, and formality essential for C1/C2 communication.',
          fa: 'ترکیبات اسمی-فعلی به جای افعال ساده به کار می‌روند تا لحن متن رسمی‌تر، دقیق‌تر و فاخرتر شود (مثلاً به جای kritisieren از Kritik üben an استفاده می‌شود).',
          prs: 'در این ساختار به جای فعل ساده، یک اسم با فعل خاصی ترکیب می‌گردد تا کلام شکل کاملاً رسمی و باوقار پیدا کند (مانند in Betracht ziehen به جای berücksichtigen).',
          tr: 'Basit fiiller yerine bir isim ve anlamca zayıflamış yardımcı fiil kullanılır. C1/C2 seviyesinde metne nesnellik ve resmiyet katar.',
          ar: 'تراكيب تستبدل الأفعال البسيطة باسم وفعل وظيفي لمنح الكلام طابعاً رسمياً محايداً ومتقناً.',
          es: 'Estructuras que sustituyen verbos simples por una combinación de sustantivo y verbo funcional para dotar al texto de rigor y formalidad.'
        },
        examples: [
          {
            german: 'Wir müssen alle Optionen sorgfältig in Betracht ziehen.',
            formulaBreakdown: 'Wir müssen (Modalverb) + alle Optionen (Objekt) + in Betracht ziehen (FVG = berücksichtigen).',
            literalTranslation: {
              en: 'We must all options carefully into consideration draw.',
              fa: 'ما باید همه گزینه‌ها را با دقت مد نظر قرار دهیم.',
              prs: 'ما باید تمام گزینه‌ها و راه‌ها را با دقت تحت غور و بررسی قرار بدهیم.',
              tr: 'Tüm seçenekleri titizlikle göz önünde bulundurmalıyız.',
              ar: 'علينا أن نأخذ جميع الخيارات بعين الاعتبار والتقدير.',
              es: 'Debemos tomar en consideración minuciosamente todas las opciones.'
            },
            fluentTranslation: {
              en: 'We must take all available options into careful consideration.',
              fa: 'ما موظفیم تمامی راهکارهای پیش‌رو را با دقت تام مورد توجه و بررسی قرار دهیم.',
              prs: 'لازم است که تمام گزینه‌های موجود را با دقت کامل مورد بررسی و ملاحظه قرار دهیم.',
              tr: 'Bütün ihtimalleri özenle değerlendirmek zorundayız.',
              ar: 'يجب أن نضع كافة الاحتمالات المتاحة نصب أعيننا بكل عناية.',
              es: 'Es imperativo sopesar con rigor todas las posibilidades a nuestro alcance.'
            }
          },
          {
            german: 'Die neuen Fördermittel stehen den Universitäten ab sofort zur Verfügung.',
            formulaBreakdown: 'Die neuen Fördermittel (Subjekt) + stehen (FVG) + den Universitäten + zur Verfügung (FVG = verfügbar sein).',
            literalTranslation: {
              en: 'The new funds stand to-the universities from now to disposal.',
              fa: 'بودجه‌های حمایتی جدید از هم‌اکنون در دسترس دانشگاه‌ها قرار دارند.',
              prs: 'بودجه‌های حمایتی نو از همین اکنون در اختیار پوهنتون‌ها گذاشته شده‌اند.',
              tr: 'Yeni teşvik fonları bugünden itibaren üniversitelerin kullanımına sunulmuştur.',
              ar: 'المخصصات المالية الجديدة موضوعة تحت تصرف الجامعات ابتداءً من الآن.',
              es: 'Los nuevos fondos de ayuda quedan a disposición de las universidades de inmediato.'
            },
            fluentTranslation: {
              en: 'The new funding resources are available to universities with immediate effect.',
              fa: 'اعتبارات مالی حمایتی جدید از این لحظه در اختیار و در دسترس دانشگاه‌ها قرار گرفته است.',
              prs: 'بودجه‌های کمکی جدید از هم‌اکنون به صورت کامل در دسترس پوهنتون‌ها قرار دارد.',
              tr: 'Yeni mali destekler üniversitelerin hizmetine derhal sunulmuştur.',
              ar: 'أصبحت الميزانيات الداعمة الجديدة متاحة لاستخدام الجامعات بشكل فوري.',
              es: 'Las nuevas subvenciones se encuentran a disposición de las universidades a partir de este momento.'
            }
          }
        ]
      },
      practiceTasks: [
        'Ersetzen Sie das Verb "beenden" durch das passende Funktionsverbgefüge ("zu einem Ende bringen / führen").',
        'Bilden Sie einen diplomatischen Satz mit "außer Frage stehen".'
      ]
    },
    vocabularies: [
      { id: 'c1_2_v6', word: 'die Sorgfaltspflicht', article: 'die', plural: 'die Sorgfaltspflichten', ipa: '/ˈzɔʁkfalt͡sˌp͡flɪçt/', translation: { en: 'duty of diligence / care', fa: 'تعهد به رعایت دقت و مراقبت قانونی', prs: 'مسوولیت دقت و مراقبت قانونی', tr: 'özen yükümlülüğü', ar: 'واجب العناية الواجبة', es: 'deber de diligencia' } },
      { id: 'c1_2_v7', word: 'die Dekarbonisierung', article: 'die', plural: 'die Dekarbonisierungen', ipa: '/dekaʁboniˈziːʁʊŋ/', translation: { en: 'decarbonization', fa: 'کربن‌زدایی زیست‌محیطی', prs: 'کاهش و حذف گازهای کاربن', tr: 'karbonsuzlaştırma', ar: 'إزالة الكربون والحد من الانبعاثات', es: 'descarbonización' } },
      { id: 'c1_2_v8', word: 'das Gutachten', article: 'das', plural: 'die Gutachten', ipa: '/ˈɡuːtˌʔaxtn̩/', translation: { en: 'expert opinion / legal report', fa: 'نظریه کارشناسی رسمی / ارزیابی حقوقی', prs: 'نظر کارشناس مسلکی / تصدیق حقوقی', tr: 'bilirkişi raporu', ar: 'تقرير الخبرة الفنية / الرأي القانوني', es: 'dictamen pericial' } },
      { id: 'c1_2_v9', word: 'die Restrukturierung', article: 'die', plural: 'die Restrukturierungen', ipa: '/ʁestʁʊktuˈʁiːʁʊŋ/', translation: { en: 'restructuring', fa: 'تغییر ساختار سازمانی / بازسازی', prs: 'تجدید ساختار اداری و اقتصادی', tr: 'yeniden yapılandırma', ar: 'إعادة الهيكلة المؤسسية', es: 'reestructuración' } },
      { id: 'c1_2_v10', word: 'die Transparenz', article: 'die', plural: 'die Transparenzen', ipa: '/tʁanspaˈʁɛnt͡s/', translation: { en: 'transparency', fa: 'شفافیت سازمانی', prs: 'شفافیت در کار و حساب‌دهی', tr: 'şeffaflık', ar: 'الشفافية المؤسسية', es: 'transparencia' } }
    ],
    videoClip: {
      title: 'Aufsichtsratssitzung: Dekarbonisierung und Lieferkettengesetz',
      scenario: 'Vorstandsmitglieder debattieren über die Umsetzung des deutschen Lieferkettensorgfaltspflichtengesetzes in Frankfurt.',
      category: 'beruf',
      duration: '02:50',
      speakers: ['Vorsitzende', 'Compliance-Chef'],
      keyPhrases: [
        'Wir müssen alle Risiken in Betracht ziehen.',
        'Die ESG-Kriterien stehen zur Disposition.',
        'Es bedarf einer grundlegenden Neuausrichtung.'
      ],
      germanTranscript: [
        'Vorsitzende: Meine Damen und Herren, wir müssen heute über die strikte Einhaltung des Lieferkettengesetzes entscheiden.',
        'Compliance-Chef: Frau Vorsitzende, unser aktueller Audit-Bericht zieht alle kritischen Zulieferer in Betracht.',
        'Vorsitzende: Welche Konsequenzen stehen bei Verstößen im Raum?',
        'Compliance-Chef: Es drohen empfindliche Bußgelder sowie der Ausschluss von öffentlichen Vergabeverfahren.',
        'Vorsitzende: Folglich bringen wir den Maßnahmenkatalog zur Dekarbonisierung und Transparenz unverzüglich zur Abstimmung.'
      ],
      translatedTranscript: [
        {
          en: 'Chairwoman: Ladies and gentlemen, we must decide today on strict compliance with the Supply Chain Act.',
          fa: 'رئیس جلسه: خانم‌ها و آقایان، امروز باید درباره پایبندی دقیق به قانون زنجیره تامین تصمیم‌گیری کنیم.',
          prs: 'رییسه جلسه: خانم‌ها و آقایان محترم، امروز باید در مورد تطبیق قانون زنجیره تدارکات تصمیم بگیریم.',
          tr: 'Başkan: Hanımefendiler ve beyefendiler, bugün Tedarik Zinciri Yasasına uyum konusunda karar vermeliyiz.',
          ar: 'رئيسة المجلس: سيداتي وسادتي، يتعين علينا اليوم البت في الامتثال الصارم لقانون سلاسل التوريد.',
          es: 'Presidenta: Señoras y señores, hoy debemos decidir sobre el estricto cumplimiento de la Ley de Cadena de Suministro.'
        },
        {
          en: 'Compliance Head: Madam Chair, our current audit report takes all critical suppliers into consideration.',
          fa: 'مدیر تطبیق مقررات: خانم رئیس، گزارش حسابرسی فعلی ما تمام تامین‌کنندگان پرریسک را مد نظر قرار داده است.',
          prs: 'مسئول تفتیش و انطباق: خانم رییسه، راپور تفتیش فعلی تمام تدارک‌کنندگان عمده را مدنظر گرفته است.',
          tr: 'Uyum Direktörü: Sayın Başkan, mevcut denetim raporumuz tüm kritik tedarikçileri dikkate almaktadır.',
          ar: 'مسؤول الامتثال: سيادة الرئيسة، إن تقرير التدقيق الحالي يأخذ في الاعتبار جميع الموردين الحرجين.',
          es: 'Jefe de Compliance: Sra. Presidenta, nuestro informe de auditoría toma en consideración a todos los proveedores críticos.'
        },
        {
          en: 'Chairwoman: What consequences are looming in case of violations?',
          fa: 'رئیس جلسه: در صورت نقض مقررات، چه پیامدهایی در انتظار ما خواهد بود؟',
          prs: 'رییسه جلسه: در صورت نقض مقررات، کدام عواقب و جریمه‌ها متوجه ما خواهد شد؟',
          tr: 'Başkan: İhlal durumunda ne tür yaptırımlarla karşılaşabiliriz?',
          ar: 'رئيسة المجلس: ما العواقب المترتبة في حال حدوث أي انتهاكات؟',
          es: 'Presidenta: ¿Qué consecuencias se contemplan en caso de infracción?'
        },
        {
          en: 'Compliance Head: Severe fines and exclusion from public procurement procedures are imminent.',
          fa: 'مدیر تطبیق مقررات: جریمه‌های مالی سنگین و همچنین محرومیت از مناقصات عمومی ما را تهدید می‌کند.',
          prs: 'مسئول انطباق: جریمه‌های بسیار گزاف و محرومیت از داوطلبی‌ها و قراردادهای دولتی در پیش خواهد بود.',
          tr: 'Uyum Direktörü: Ağır para cezaları ve kamu ihalelerinden men edilme riski bulunmaktadır.',
          ar: 'مسؤول الامتثال: ثمة تهديد بفرض غرامات مالية باهظة والاستبعاد من المناقصات الحكومية العامة.',
          es: 'Jefe de Compliance: Amenazan severas multas y la exclusión de licitaciones públicas.'
        },
        {
          en: 'Chairwoman: Consequently, we will put the catalog of measures for decarbonization and transparency to a vote immediately.',
          fa: 'رئیس جلسه: در نتیجه، فهرست اقدامات برای کربن‌زدایی و شفافیت را فوراً به رای می‌گذاریم.',
          prs: 'رییسه جلسه: بناءً، لایحه اقدامات برای کاهش گازهای مضره و شفافیت را بلافاصله به رای‌گیری می‌گذاریم.',
          tr: 'Başkan: Dolayısıyla karbonsuzlaştırma ve şeffaflık eylem planını derhal oylamaya sunuyoruz.',
          ar: 'رئيسة المجلس: بناءً عليه، سنطرح حزمة التدابير الخاصة بإزالة الكربون والشفافية للتصويت فوراً.',
          es: 'Presidenta: Por consiguiente, someteremos a votación de inmediato el catálogo de medidas de descarbonización y transparencia.'
        }
      ]
    },
    examTip: {
      standard: 'C1 (Goethe-Zertifikat C1 & telc C1)',
      module: 'Schriftlicher Ausdruck (Stellungnahme)',
      tip: {
        en: 'In C1 essay writing, substituting simple verbs with appropriate functional verb phrases ("in Angriff nehmen", "in Zweifel ziehen", "zur Sprache bringen") will significantly boost your score in vocabulary variety and stylistic range.',
        fa: 'در نگارش مقاله C1، جایگزین کردن افعال ساده با اصطلاحات اسمی-فعلی، نمره دایره لغات و سبک نوشتار شما را بسیار بالا می‌برد.',
        prs: 'در بخش نوشتن مقاله آزمون C1، استفاده از اصطلاحات ترکیبی اسم و فعل (مانند in Betracht ziehen یا zur Verfügung stehen) نشان‌دهنده فصاحت اکادمیک شما بوده و بلندترین نمره را برایتان می‌آورد.',
        tr: 'C1 yazma sınavında basit fiiller yerine Nomen-Verb-Verbindungen kullanmak dil zenginliği puanınızı doğrudan yükseltir.',
        ar: 'في التعبير الكتابي لمستوى C1 استبدال الأفعال البسيطة بالتراكيب الوظيفية يضمن لك أعلى الدرجات في تنوع المفردات والأسلوب.',
        es: 'En la redacción de C1, sustituir verbos cotidianos por perífrasis formales eleva sustancialmente la calificación estilística.'
      }
    }
  },
  {
    id: 'c1_2_lek10',
    lektionNumber: 10,
    level: 'C1.2',
    title: 'Medienkritik, Hermeneutik und Passivalternativen',
    subTitle: 'Medientheorie, Diskursanalyse und Passiversatzformen (sich lassen / sein zu / -bar / -lich)',
    topic: 'Desinformation, Informationsästhetik, Medienethik und Passivalternativen im gehobenen Stil',
    fotoHoergeschichte: {
      title: 'Foto-Hörgeschichte: Das Medienforum in Berlin',
      imagePrompt: 'A sleek television debate studio in Berlin where media theorists and journalists analyze digital disinformation networks on a giant multimedia display.',
      imageTheme: 'Berlin Medienstudio',
      audioDuration: '03:00',
      transcript: [
        { speaker: 'Moderatorin', text: 'Herzlich willkommen zum Berliner Medienforum über die Zersetzung des öffentlichen Raumes durch Desinformation.' },
        { speaker: 'Prof. Dr. Klein', text: 'Die Authentizität digital generierter Bilddokumente lässt sich mit bloßem Auge kaum noch überprüfen.' },
        { speaker: 'Dr. Sarah Amari', text: 'In der Tat. Es sind dringend neue Verifikationsprotokolle zu etablieren, um Täuschungen vorzubeugen.' },
        { speaker: 'Prof. Dr. Klein', text: 'Dieser Verlust an Faktizität ist keineswegs hinnehmbar. Die Integrität des Diskurses steht auf dem Spiel.' },
        { speaker: 'Dr. Sarah Amari', text: 'Dennoch ist festzustellen, dass eine allzu restriktive Regulierung die Meinungsfreiheit ungebührlich einschränken könnte.' }
      ],
      summary: {
        en: 'Media theorists in Berlin debate digital disinformation and information hygiene, utilizing elegant passive alternatives (lässt sich überprüfen, ist festzustellen).',
        fa: 'نظریه‌پردازان رسانه در برلین پیرامون اخبار جعلی و بهداشت اطلاعات با ساختارهای جایگزین مجهول (مانند lässt sich überprüfen) مناظره می‌کنند.',
        prs: 'صاحب‌نظران رسانه در برلین درباره معلومات نادرست و حقیقت‌سنجی دیجیتالی با استفاده از ساختارهای مجهول ادبی مباحثه می‌نمایند.',
        tr: 'Berlin\'deki medya forumunda uzmanlar, edilgen çatı alternatiflerini (Passiversatzformen) kullanarak dezenformasyon konusunu tartışır.',
        ar: 'يناقش خبراء الإعلام في برلين التضليل الرقمي مستخدمين بدائل المبني للمجهول الأدبية الرفيعة.',
        es: 'Expertos en comunicación debaten en Berlín sobre desinformación empleando alternativas estilísticas a la pasiva.'
      }
    },
    sectionA: {
      title: 'Mussawi A: Sprechen & Dialog',
      focus: 'Sprechen & Hören (Medienanalyse & Diskurskritik)',
      description: {
        en: 'Critique journalistic ethics, sensationalism, framing techniques, and the digital transformation of the public sphere.',
        fa: 'نقد اخلاق رسانه‌ای، زردنگاری، جهت‌دهی به افکار عمومی (فرمینگ) و دگرگونی فضای عمومی در عصر دیجیتال.',
        prs: 'نقد مسلکی اصول خبرنگاری، جهت‌دهی به خبرها و تغییرات افکار عامه در رسانه‌های امروزی.',
        tr: 'Medya etiği, sansasyonellik, çerçeveleme teknikleri ve kamuoyu tartışmalarını eleştirme.',
        ar: 'نقد أخلاقيات الصحافة والإثارة الإعلامية وتأطير الأخبار في الفضاء الرقمي.',
        es: 'Crítica de la ética periodística, el sensacionalismo y los marcos discursivos.'
      },
      content: 'Das Framing / Die Aufmerksamkeitsökonomie / Die Echokammer / Faktizität versus Narrativ.',
      audioText: 'In modernen Aufmerksamkeitsökonomien entscheidet nicht mehr die faktische Stichhaltigkeit einer Meldung über ihre Reichweite, sondern ihr affektives Erregungspotenzial.',
      practiceTasks: [
        'Analysieren Sie die Schlagzeilen zweier Zeitungen auf Framing-Effekte.',
        'Erläutern Sie das Phänomen der "Filterblase" im gehobenen Register.'
      ]
    },
    sectionB: {
      title: 'Mussawi B: Wortschatz & Hören',
      focus: 'Hören & Wortschatz (Hermeneutik & Informationsethik)',
      description: {
        en: 'Advanced vocabulary for textual interpretation, bias detection, algorithmic curation, and epistemic bubbles.',
        fa: 'واژگان تفسیر متن و هرمنوتیک، شناسایی پیش‌داوری، گزینش الگوریتمی و حباب‌های اطلاعاتی.',
        prs: 'لغات هرمنوتیک و تفسیر متن، کشف سوگیری‌های رسانه‌ای و گزینش‌های الگوریتمی.',
        tr: 'Metin yorumlama (hermenötik), algoritmik kürasyon ve bilgi etiği terimleri.',
        ar: 'مفردات التأويل والهرمنيوطيقا وكشف الانحياز الإعلامي والتنظيم الخوارزمي للمحتوى.',
        es: 'Vocabulario de hermenéutica, sesgos cognitivos y algoritmos de selección informativa.'
      },
      content: 'die Hermeneutik, das Narrativ, die Zensur, die Verifikation, die Resonanz, die Konnotation.',
      audioText: 'Die hermeneutische Textanalyse erfordert eine sorgfältige Rekonstruktion des historischen und soziopolitischen Kontextes, in dem ein Text entstanden ist.',
      practiceTasks: [
        'Klären Sie den Unterschied zwischen Denotation und Konnotation an Beispielen.',
        'Verfassen Sie einen Kommentar zur Verantwortung von Plattformbetreibern.'
      ]
    },
    sectionC: {
      title: 'Mussawi C: Alltagskommunikation',
      focus: 'Sprechen & Dialoge (Differenzierte Meinungsäußerung & Nuancierung)',
      description: {
        en: 'Express nuanced qualifications, avoid black-and-white dichotomies, and present balanced socio-cultural arguments.',
        fa: 'بیان دیدگاه‌های چندلایه و ظریف، پرهیز از ساده‌انگاری سیاه و سفید و ارائه استدلال‌های متوازن.',
        prs: 'ابراز نظر دقیق و همه‌جانبه، دوری از قضاوت‌های یک‌طرفه و ارائه دلایل منطقی متوازن.',
        tr: 'Siyah-beyaz kutuplaşmasından kaçınarak incelikli ve dengeli fikir beyan etme.',
        ar: 'التعبير عن الآراء الدقيقة متعددة الأبعاد وتجنب الأحكام التبسيطية المطلقة.',
        es: 'Expresión de matices y argumentación equilibrada evitando simplificaciones dicotómicas.'
      },
      content: 'Es steht außer Frage, dass... / Gleichwohl darf nicht verkannt werden, dass... / Man muss differenzieren zwischen...',
      audioText: 'Obgleich die Gefahren von Fehlinformationen unübersehbar sind, darf die Debatte nicht in panische Zensurforderungen abgleiten. Es gilt vielmehr, die Medienkompetenz der Bürger nachhaltig zu stärken.',
      practiceTasks: [
        'Formulieren Sie ein differenziertes Plädoyer für Medienkompetenz im Schulunterricht.',
        'Entkräften Sie ein populistisches Scheinargument mit stichhaltigen Gegenargumenten.'
      ]
    },
    sectionD: {
      title: 'Mussawi D: Leseverstehen & Text',
      focus: 'Lesen & Textanalyse (Kulturkritischer Feuilletonbeitrag)',
      description: {
        en: 'Analyze sophisticated cultural essays from leading newspapers (FAZ, DIE ZEIT) with irony, metaphors, and subtle subtext.',
        fa: 'تحلیل ستون‌های فرهنگی-تحلیلی روزنامه‌های معتبر آلمانی با ایهام، استعاره‌ها و لایه‌های پنهان معنایی.',
        prs: 'خواندن و تحلیل مقالات فرهنگی ادبی روزنامه‌های مهم با استعاره‌ها و کنایه‌های ادبی فاخر.',
        tr: 'Nitelikli gazete makalelerini (Feuilleton), ironi, metafor ve edebi üslubu analiz etme.',
        ar: 'تحليل المقالات الثقافية والفكرية المعمقة بما تتضمنه من استعارات وبلاغة لغوية.',
        es: 'Análisis de artículos de opinión y crítica cultural con lenguaje figurado y matices irónicos.'
      },
      content: 'Feuilletonistischer Essay über das Lesen im Zeitalter digitaler Kurzformate.',
      readingText: {
        type: 'Feuilleton-Essay',
        title: 'Die Kunst des Innehaltens - Lob des langsamen Lesens',
        body: 'Im Takt der Push-Nachrichten und der algorithmisch getakteten Aufmerksamkeitsfetzen droht eine Kulturtechnik zu verkümmern, die einst das Fundament aufgeklärter Subjektivität bildete: das kontemplative, geduldige Lesen. Wer sich heute noch einem mehrbändigen Roman oder einer philosophischen Abhandlung aussetzt, vollzieht fast schon einen Akt des zivilen Ungehorsams gegen die Diktatur der Sekundenschnelligkeit. Es ist höchste Zeit, die Fähigkeit zur vertieften Reflexion neu zu kultivieren.'
      },
      practiceTasks: [
        'Welche Metaphern verwendet der Autor, um die moderne Informationsflut zu charakterisieren?',
        'Wie begründet der Text den Wert des "langsamen Lesens" für das Individuum?'
      ]
    },
    sectionE: {
      title: 'Mussawi E: Grammatik & Schreiben',
      focus: 'Grammatik & Schreiben (Passivalternativen: sich lassen + Inf. / sein + zu + Inf. / Adjektive auf -bar, -lich)',
      description: {
        en: 'Master stylistic alternatives to the passive voice to write varied, academic, and elegant German prose.',
        fa: 'تسلط بر جایگزین‌های شیک و ادبی مجهول برای افزایش غنا و روانی متن در آزمون‌های C1.',
        prs: 'یادگیری بدل‌های زیبای مجهول (Passivalternativen) مانند sich lassen، sein + zu و پسوندهای bar- و lich- برای نگارش عالی.',
        tr: 'Edilgen çatı alternatifleri (sich lassen + mastar, sein + zu + mastar, -bar/-lich ekleri).',
        ar: 'إتقان بدائل صيغة المبني للمجهول في الأسلوب الأدبي والأكاديمي الرفيع.',
        es: 'Dominio de alternativas a la voz pasiva para enriquecer el estilo y evitar la monotonía sintáctica.'
      },
      content: 'Passiv: "Das kann gemacht werden" -> Passivalternativen: "Das lässt sich machen" / "Das ist zu machen" / "Das ist machbar".',
      grammarRule: {
        id: 'c1_2_passivalternativen_rule',
        level: 'C1.2',
        germanTitle: 'Passivalternativen (Passiversatzformen)',
        formula: '1. sich lassen + Infinitiv | 2. sein + zu + Infinitiv | 3. Adjektive auf -bar / -lich / -abel',
        explanation: {
          en: 'Frequent use of the passive voice can make texts repetitive and clumsy. Advanced German uses three primary alternatives: 1. "sich lassen + Infinitiv" (possibility: can be done); 2. "sein + zu + Infinitiv" (obligation or possibility: must/can be done); 3. Adjectives ending in -bar or -lich (feasibility: solvable, understandable).',
          fa: 'تکرار زیاد افعال مجهول متن را سنگین و یکنواخت می‌کند. در آلمانی پیشرفته از ۳ ساختار جایگزین استفاده می‌شود: ۱. sich lassen + مصدر (امکان‌پذیری: می‌توان انجام داد)؛ ۲. sein + zu + مصدر (بایستگی یا امکان: باید/می‌توان انجام داد)؛ ۳. صفت‌های مختوم به -bar و -lich (مانند machbar: قابل انجام، erklärbar: قابل توضیح).',
          prs: 'برای زیبایی کلام و جلوگیری از تکرار مجهول، سه طریقه دیگر به کار می‌رود: ۱. sich lassen + مصدر (قابل اجرا بودن)؛ ۲. sein + zu + مصدر (ضرورت یا امکان انجام کار)؛ ۳. صفت‌های با پسوند -bar و -lich (مانند lösbar یعنی قابل حل).',
          tr: 'Metnin akıcılığını artırmak için edilgen çatı yerine üç yapı tercih edilir: sich lassen + mastar (olabilirlik), sein + zu + mastar (zorunluluk/olabilirlik) ve -bar/-lich son ekli sıfatlar.',
          ar: 'بدائل المبني للمجهول تضفي مرونة وبلاغة على النص: sich lassen (الإمكانية)، sein + zu (الوجوب أو الإمكان)، وصفات -bar و-lich.',
          es: 'Estructuras alternativas para evitar la repetición de la pasiva: sich lassen (posibilidad), sein + zu (obligación/posibilidad) y sufijos -bar / -lich.'
        },
        examples: [
          {
            german: 'Diese komplexe Problematik lässt sich nicht trivialisieren.',
            formulaBreakdown: 'Diese komplexe Problematik (Subjekt) + lässt (V1) + sich (Refl.) + nicht trivialisieren (Inf. = kann nicht trivialisiert werden).',
            literalTranslation: {
              en: 'This complex problem-complex lets itself not trivialize.',
              fa: 'این مسئله پیچیده اجازه ساده‌انگاری به خود نمی‌دهد (نمی‌توان آن را ساده‌انگارانه تقلیل داد).',
              prs: 'این معضل دشوار را نمی‌توان ساده و پیش‌پاافتاده جلوه داد.',
              tr: 'Bu karmaşık sorun hafife alınamaz.',
              ar: 'لا يمكن تبسيط هذه الإشكالية المعقدة بصورة مبتذلة.',
              es: 'Esta compleja problemática no se deja trivializar (no puede simplificarse).'
            },
            fluentTranslation: {
              en: 'This complex issue cannot simply be reduced or trivialized.',
              fa: 'این معضل پیچیده را به هیچ وجه نمی‌توان به شکلی ساده‌انگارانه تقلیل داد.',
              prs: 'این موضوع پیچیده را نمی‌توان به آسانی تقلیل داده و ساده پنداشت.',
              tr: 'Bu çetrefilli mesele kesinlikle basite indirgenemez.',
              ar: 'لا يمكن اختزال هذه القضية المعقدة بأي حال من الأحوال.',
              es: 'No es admisible simplificar una problemática de semejante envergadura.'
            }
          },
          {
            german: 'Die Sicherheitsvorschriften sind von allen Mitarbeitern strikt einzuhalten.',
            formulaBreakdown: 'Die Sicherheitsvorschriften (Subjekt) + sind (sein) + von allen Mitarbeitern + strikt einzuhalten (zu + Infinitiv = müssen eingehalten werden).',
            literalTranslation: {
              en: 'The safety regulations are by all employees strictly to keep.',
              fa: 'مقررات ایمنی توسط همه کارکنان به طور اکید باید رعایت شوند.',
              prs: 'مقررات ایمنی و حفظ‌الصحه باید از سوی تمامی کارمندان به گونه جدی رعایت گردد.',
              tr: 'Güvenlik kurallarına tüm çalışanlar tarafından harfiyen uyulmalıdır.',
              ar: 'يجب الالتزام الصارم بتعليمات السلامة من قِبل كافة العاملين.',
              es: 'Las normas de seguridad deben ser observadas estrictamente por todos los empleados.'
            },
            fluentTranslation: {
              en: 'Safety regulations must be adhered to strictly by all staff members.',
              fa: 'رعایت دقیق مقررات ایمنی از سوی تمامی کارکنان الزامی و اجباری است.',
              prs: 'رعایت مقررات ایمنی کار از طرف همه پرسونل کاملاً حتمی و لازم‌الاجرا می‌باشد.',
              tr: 'Güvenlik talimatlarına bütün çalışanlar tarafından mutlak surette riayet edilmelidir.',
              ar: 'يتعين على جميع الموظفين التقيد التام بقواعد السلامة المهنية.',
              es: 'Todos los colaboradores tienen la obligación ineludible de acatar las directrices de seguridad.'
            }
          }
        ]
      },
      practiceTasks: [
        'Formulieren Sie den Satz "Das Problem kann gelöst werden" auf 3 verschiedene Arten um (mit sich lassen, sein + zu, und -bar).',
        'Verfassen Sie eine formelle Bekanntmachung mit 2 "sein + zu + Infinitiv"-Konstruktionen.'
      ]
    },
    vocabularies: [
      { id: 'c1_2_v11', word: 'das Narrativ', article: 'das', plural: 'die Narrative', ipa: '/naʁaˈtiːf/', translation: { en: 'narrative / framing story', fa: 'روایت کلان / گفتمان مسلط', prs: 'روایت مسلط / دیدگاه شکل‌گرفته', tr: 'anlatı / söylem', ar: 'السردية / الخطاب المهيمن', es: 'narrativa' } },
      { id: 'c1_2_v12', word: 'die Hermeneutik', article: 'die', plural: 'die Hermeneutiken', ipa: '/hɛʁmeˈnɔɪ̯tɪk/', translation: { en: 'hermeneutics / science of interpretation', fa: 'هرمنوتیک / علم تفسیر و تاویل', prs: 'هرمنوتیک / علم تفسیر متن', tr: 'hermenötik / yorumbilim', ar: 'الهرمينيوطيقا / علم التأويل', es: 'hermenéutica' } },
      { id: 'c1_2_v13', word: 'das Feuilleton', article: 'das', plural: 'die Feuilletons', ipa: '/fœjəˈtɔ̃ː/', translation: { en: 'cultural section of a newspaper', fa: 'بخش فرهنگی-ادبی روزنامه', prs: 'بخش فرهنگی و نقد ادبی اخبار', tr: 'kültür-sanat eki', ar: 'الصفحة الثقافية والفكرية في الصحيفة', es: 'sección cultural / folletín' } },
      { id: 'c1_2_v14', word: 'die Authentizität', article: 'die', plural: 'die Authentizitäten', ipa: '/aʊ̯tɛntit͡siˈtɛːt/', translation: { en: 'authenticity', fa: 'اصالت / اعتبار واقعی', prs: 'اصالت و اعتبار حقیقی', tr: 'özgünlük / sahicilik', ar: 'الأصالة والموثوقية', es: 'autenticidad' } },
      { id: 'c1_2_v15', word: 'die Faktenlage', article: 'die', plural: 'die Faktenlagen', ipa: '/ˈfaktn̩ˌlaːɡə/', translation: { en: 'factual situation / state of facts', fa: 'وضعیت حقایق و شواهد موجود', prs: 'حقایق و اسناد موجود', tr: 'olgusal durum', ar: 'الوقائع الثابتة / الأدلة القائمة', es: 'conjunto de hechos comprobados' } }
    ],
    videoClip: {
      title: 'TV-Debatte im Presseclub: Medienästhetik und Desinformation',
      scenario: 'Journalisten diskutieren über generative KI, Deepfakes und Informationsverifikation im öffentlich-rechtlichen Rundfunk.',
      category: 'interview',
      duration: '03:00',
      speakers: ['Moderatorin', 'Chefredakteur'],
      keyPhrases: [
        'Die Authentizität digitaler Quellen lässt sich schwer verifizieren.',
        'Hierbei ist mit größter redaktioneller Sorgfalt vorzugehen.',
        'Gefälschte Narrative sind von fundierten Recherchen kaum zu unterscheiden.'
      ],
      germanTranscript: [
        'Moderatorin: Herzlich willkommen zum Presseclub! Lässt sich im Zeitalter generativer KI die Authentizität von Bildmaterial noch zweifelsfrei nachweisen?',
        'Chefredakteur: Frau Kollegin, dies ist in der Tat die Kardinalfrage. Deepfakes lassen sich heutzutage kaum noch mit bloßem Auge entlarven.',
        'Moderatorin: Welche Prüfmechanismen sind demnach in den Redaktionen zu etablieren?',
        'Chefredakteur: Kryptografische Wasserzeichen und quellengestützte Verifikationsverfahren sind unverzüglich einzuführen.',
        'Moderatorin: Es ist festzuhalten, dass Medienkompetenz damit zu einer unverzichtbaren demokratischen Bürgerpflicht avanciert.'
      ],
      translatedTranscript: [
        {
          en: 'Moderator: Welcome to the Press Club! In the era of generative AI, can the authenticity of visual material still be verified beyond doubt?',
          fa: 'مجری: به کلوب مطبوعات خوش آمدید! در عصر هوش مصنوعی زاینده، آیا اصالت تصاویر و ویدیوها هنوز بدون شک قابل اثبات است؟',
          prs: 'گرداننده: به برنامه نقد مطبوعات خوش آمدید! در عصر هوش مصنوعی تولیدکننده، آیا اصالت ویدیوها هنوز به یقین ثابت شده می‌تواند؟',
          tr: 'Moderatör: Basın Kulübü\'ne hoş geldiniz! Üretken yapay zeka çağında görsel materyallerin doğruluğu kesin olarak kanıtlanabilir mi?',
          ar: 'مقدمة البرنامج: أهلاً بكم في نادي الصحافة! في عصر الذكاء الاصطناعي التوليدي، هل يمكن إثبات صحة الصور دون أدنى شك؟',
          es: 'Moderadora: ¡Bienvenidos al Club de Prensa! En la era de la IA generativa, ¿aún se puede verificar fehacientemente la autenticidad visual?'
        },
        {
          en: 'Editor-in-Chief: Colleague, this is indeed the cardinal question. Deepfakes can hardly be unmasked with the naked eye nowadays.',
          fa: 'سردبیر: همکار گرامی، این حقیقتاً پرسش بنیادین است. امروزه دیپ‌فیک‌ها به‌ندرت با چشم غیرمسلح قابل تشخیص هستند.',
          prs: 'سرمحرر: همکار محترمه، این واقعاً سوال اساسی است. تصاویر جعلی و دیپ‌فیک امروزه به چشم عادی قابل تشخیص نیستند.',
          tr: 'Genel Yayın Yönetmeni: Meslektaşım, bu gerçekten can alıcı soru. Deepfake içerikler çıplak gözle neredeyse ayırt edilemiyor.',
          ar: 'رئيس التحرير: زميلتي، هذا هو السؤال المحوري بالفعل. لم يعد بالإمكان كشف التزييف العميق بالعين المجردة.',
          es: 'Redactor jefe: Estimada colega, esa es la pregunta cardinal. Hoy en día los deepfakes apenas se detectan a simple vista.'
        },
        {
          en: 'Moderator: What verification mechanisms must therefore be established in newsrooms?',
          fa: 'مجری: بنابراین چه سازوکارهای راستی‌آزمایی باید در تحریریه‌ها مستقر شود؟',
          prs: 'گرداننده: بنابرین چه سیستم‌های تثبیت صحت خبر باید در دفاتر مطبوعات فعال گردد؟',
          tr: 'Moderatör: Bu durumda yazı işlerinde hangi denetim mekanizmaları kurulmalıdır?',
          ar: 'مقدمة البرنامج: ما آليات التحقق التي يجب ترسيخها في غرف الأخبار إذن؟',
          es: 'Moderadora: ¿Qué mecanismos de verificación deben establecerse en las redacciones?'
        },
        {
          en: 'Editor-in-Chief: Cryptographic watermarks and source-based verification protocols must be introduced without delay.',
          fa: 'سردبیر: واترمارک‌های رمزنگاری‌شده و پروتکل‌های راستی‌آزمایی مبتنی بر منبع باید بدون اتلاف وقت اجرا شوند.',
          prs: 'سرمحرر: نشانه‌های رمزگذاری‌شده و پروسه‌های تثبیت منبع باید بدون معطلی تطبیق شوند.',
          tr: 'Genel Yayın Yönetmeni: Kriptografik filigranlar ve kaynak doğrulama protokolleri derhal hayata geçirilmelidir.',
          ar: 'رئيس التحرير: يجب تطبيق العلامات المائية المشفرة وبروتوكولات التحقق من المصادر فوراً دون إبطاء.',
          es: 'Redactor jefe: Deben implementarse sin demora marcas de agua criptográficas y protocolos de verificación de fuentes.'
        },
        {
          en: 'Moderator: It is evident that media literacy has thereby advanced to an indispensable democratic civic duty.',
          fa: 'مجری: باید اذعان کرد که سواد رسانه‌ای به یک وظیفه شهروندی دموکراتیک و انکارناپذیر ارتقا یافته است.',
          prs: 'گرداننده: باید تصریح نمود که سواد رسانه‌ای اکنون به یک وجیبه اساسی شهروندی دموکراتیک تبدیل شده است.',
          tr: 'Moderatör: Medya okuryazarlığının vazgeçilmez bir demokratik vatandaşlık görevine dönüştüğü sabittir.',
          ar: 'مقدمة البرنامج: بات من المؤكد أن التربية الإعلامية قد غدت واجباً مدنياً وديمقراطياً لا غنى عنه.',
          es: 'Moderadora: Cabe constatar que la alfabetización mediática se ha convertido en un deber cívico indispensable.'
        }
      ]
    },
    examTip: {
      standard: 'C1 (Goethe-Zertifikat C1 & telc C1 Hochschule)',
      module: 'Mündlicher Ausdruck (Präsentation & Diskussion)',
      tip: {
        en: 'In C1 speaking exams, replace simple "man kann" constructions with "Es lässt sich unschwer feststellen, dass..." or "Hierbei ist zu beachten, dass...". This demonstrates the academic fluency required for highest grades.',
        fa: 'در مصاحبه شفاهی C1، به جای "man kann" از "Es lässt sich feststellen..." یا "Hierbei ist zu beachten..." استفاده کنید تا تسلط شما بر ساختارهای فاخر اثبات شود.',
        prs: 'در بخش صحبت امتحان C1، به جای جملات ساده "man kann"، همیشه از تعبیرات عالی مثل "Es lässt sich feststellen..." یا "Hierbei ist zu berücksichtigen..." استفاده نمایید تا نمره عالی دانشگاهی بگیرید.',
        tr: 'C1 sözlü sınavında "man kann" yerine "Es lässt sich feststellen" gibi akademik kalıplar kullanın.',
        ar: 'في الاختبار الشفوي لـ C1 استبدل العبارات البسيطة ببدائل مثل "Es lässt sich feststellen" لإبراز تمكنك الأكاديمي.',
        es: 'En el examen oral de C1, sustituye "man kann" por construcciones cultas como "Es lässt sich konstatieren".'
      }
    }
  }
];
