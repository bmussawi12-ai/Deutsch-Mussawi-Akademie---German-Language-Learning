import { StandardizedExam } from '../types';

export const COMPREHENSIVE_STANDARDIZED_EXAMS: StandardizedExam[] = [
  // ================= GOETHE A1 =================
  {
    id: 'exam_goethe_a1',
    title: 'Goethe-Zertifikat A1: Start Deutsch 1 (Modellsatz)',
    standard: 'Goethe-Zertifikat',
    level: 'A1.1',
    totalDurationMinutes: 65,
    passingScore: '60% (60 / 100 Punkte)',
    strategy: {
      level: 'A1.1',
      timeManagement: [
        {
          section: 'Lesen (Reading)',
          allocatedMinutes: 25,
          tip: {
            en: 'Spend ~8 minutes per text. Skim the questions first before reading the notices or emails.',
            fa: 'حدود ۸ دقیقه برای هر متن اختصاص دهید. ابتدا سوالات را بخوانید و سپس آگهی‌ها یا ایمیل‌ها را بررسی کنید.',
            prs: 'حدود ۸ دقیقه برای هر متن وقت بگذارید. اول سوالات را بخوانید و بعد ایمیل یا متن را بخوانید.',
            tr: 'Metin başına yaklaşık 8 dakika ayırın. İlanları veya e-postaları okumadan önce sorulara göz atın.',
            ar: 'خصص حوالي 8 دقائق لكل نص. اقرأ الأسئلة أولاً قبل قراءة الإعلانات أو رسائل البريد.',
            es: 'Dedica unos 8 minutos por texto. Lee primero las preguntas antes de leer los avisos o correos.'
          }
        },
        {
          section: 'Hören (Listening)',
          allocatedMinutes: 20,
          tip: {
            en: 'Read the prompt during the pause. Teil 1 and 3 are played twice, Teil 2 is played once only.',
            fa: 'در زمان مکث، صورت سوال را بخوانید. بخش ۱ و ۳ دو بار پخش می‌شوند، بخش ۲ فقط یک بار پخش می‌شود.',
            prs: 'در وقت مکث، سوال را بخوانید. بخش ۱ و ۳ دو بار و بخش ۲ یک بار شنیده می‌شود.',
            tr: 'Duraklama sırasında soruyu okuyun. Bölüm 1 ve 3 iki kez, Bölüm 2 yalnızca bir kez dinletilir.',
            ar: 'اقرأ السؤال أثناء فترة التوقف. يُسمع القسمان 1 و 3 مرتين، بينما يُسمع القسم 2 مرة واحدة فقط.',
            es: 'Lee la pregunta durante la pausa. Las partes 1 y 3 se reproducen dos veces, la parte 2 solo una vez.'
          }
        },
        {
          section: 'Schreiben (Writing)',
          allocatedMinutes: 20,
          tip: {
            en: 'Fill in form data accurately (Teil 1, 5 pts) and write a short email with all 3 guiding points (Teil 2, 10 pts).',
            fa: 'فرم اطلاعات را دقیق پر کنید (بخش ۱، ۵ امتیاز) و یک ایمیل کوتاه حاوی هر ۳ نکته بنویسید (بخش ۲، ۱۰ امتیاز).',
            prs: 'فرم را دقیق پر کنید و ایمیل کوتاه با رعایت هر ۳ نکته بنویسید.',
            tr: 'Formu eksiksiz doldurun (1. Bölüm, 5 puan) ve 3 yönlendirici maddeyi içeren kısa bir e-posta yazın (2. Bölüm, 10 puan).',
            ar: 'املأ بيانات الاستمارة بدقة (القسم 1، 5 نقاط) واكتب بريداً قصيراً يغطي النقاط الثلاث (القسم 2، 10 نقاط).',
            es: 'Rellena el formulario con precisión (Parte 1, 5 pts) y escribe un correo breve con los 3 puntos guía (Parte 2, 10 pts).'
          }
        }
      ],
      stepByStepStrategies: [
        {
          title: 'Leseverstehen Teil 1 (E-Mails & Briefe)',
          steps: [
            {
              en: '1. Identify sender and recipient. 2. Highlight dates, numbers, and core intention. 3. Watch for negation words (nicht, kein).',
              fa: '۱. فرستنده و گیرنده را مشخص کنید. ۲. تاریخ‌ها، اعداد و هدف اصلی را علامت بزنید. ۳. به کلمات منفی‌ساز (nicht, kein) دقت کنید.',
              prs: '۱. فرستنده و گیرنده را دریابید. ۲. تاریخ‌ها و عددها را نشانی کنید. ۳. به کلمات منفی متوجه باشید.',
              tr: '1. Gönderen ve alıcıyı belirleyin. 2. Tarihleri, sayıları ve ana amacı vurgulayın. 3. Olumsuzluk bildiren kelimelere (nicht, kein) dikkat edin.',
              ar: '1. حدد المرسل والمستقبل. 2. ضع خطاً تحت التواريخ والأرقام والهدف الأساسي. 3. انتبه لكلمات النفي (nicht, kein).',
              es: '1. Identifica remitente y destinatario. 2. Subraya fechas, números e intención principal. 3. Presta atención a las negaciones (nicht, kein).'
            }
          ]
        }
      ],
      commonMistakes: [
        {
          mistake: 'Forgetting to address all 3 bullet points in Schreiben Teil 2.',
          correction: 'Dedicate at least one clear sentence to every guiding bullet point provided.',
          explanation: {
            en: 'Omitting a bullet point results in an automatic deduction of task achievement points.',
            fa: 'حذف هر یک از نکات موجب کسر مستقیم امتیاز انجام وظیفه می‌شود.',
            prs: 'فراموش کردن هر یک از ۳ نکته باعث کسر نمره در امتحان می‌شود.',
            tr: 'Bir yönlendirici maddeyi atlamak görev tamamlama puanının doğrudan düşmesine yol açar.',
            ar: 'إغفال أي نقطة يؤدي إلى خصم مباشر من درجات إنجاز المهمة.',
            es: 'Omitir un punto guía conlleva la pérdida automática de puntos en cumplimiento de tarea.'
          }
        }
      ]
    },
    lesen: {
      title: 'Modul Lesen (25 Minuten)',
      durationMinutes: 25,
      texts: [
        {
          title: 'Teil 1: Private Nachricht (Einladung)',
          sourceType: 'E-Mail',
          body: 'Lieber Markus,\nich feiere am kommenden Samstag meinen 30. Geburtstag! Die Party beginnt ab 18:00 Uhr bei mir im Garten. Bitte bring etwas zu trinken mit, für Essen ist gesorgt. Sag mir bitte bis Donnerstag Bescheid, ob du kommen kannst.\nLiebe Grüße,\nSusanne',
          questions: [
            {
              id: 'a1_l_q1',
              question: 'Susanne feiert am Samstagabend ihren Geburtstag.',
              options: ['Richtig', 'Falsch'],
              correctAnswer: 'Richtig',
              explanation: {
                en: 'Text states: "am kommenden Samstag (...) ab 18:00 Uhr". Therefore, Saturday evening is correct.',
                fa: 'در متن آمده است: "شنبه آینده از ساعت ۱۸:۰۰". بنابراین عصر شنبه صحیح است.',
                prs: 'متن گفته: شنبه آینده از ۱۸:۰۰. پس عصر شنبه درست است.',
                tr: 'Metinde: "önümüzdeki cumartesi saat 18:00\'den itibaren" denmektedir, dolayısıyla doğrudur.',
                ar: 'يذكر النص: "السبت القادم من الساعة 18:00"، وبالتالي فإن مساء السبت صحيح.',
                es: 'El texto indica: "el próximo sábado a partir de las 18:00". Por tanto, es correcto.'
              }
            },
            {
              id: 'a1_l_q2',
              question: 'Markus soll bis Samstag Bescheid sagen.',
              options: ['Richtig', 'Falsch'],
              correctAnswer: 'Falsch',
              explanation: {
                en: 'Susanne writes: "Sag mir bitte bis Donnerstag Bescheid", not Saturday.',
                fa: 'سوزانه می‌نویسد: "لطفاً تا پنجشنبه به من اطلاع بده"، نه شنبه.',
                prs: 'سوزانه گفته تا پنجشنبه خبر بده، نه شنبه.',
                tr: 'Susanne "lütfen perşembeye kadar haber ver" yazmıştır, cumartesiye kadar değil.',
                ar: 'كتبت سوزان: "أخبرني من فضلك بحلول يوم الخميس"، وليس السبت.',
                es: 'Susanne escribe: "avísame hasta el jueves, por favor", no el sábado.'
              }
            }
          ]
        },
        {
          title: 'Teil 2: Schilder und Aushänge',
          sourceType: 'Aushang an einer Sprachschule',
          body: 'Achtung Kursteilnehmer!\nAm Freitag, den 15. Oktober, bleibt das Schulsekretariat wegen Renovierungsarbeiten geschlossen. Anmeldungen für die telc- und Goethe-Prüfungen können Sie online über unsere Website vornehmen. Der reguläre Unterricht in den Kursräumen findet wie gewohnt statt.',
          questions: [
            {
              id: 'a1_l_q3',
              question: 'Am Freitag findet kein Unterricht statt.',
              options: ['Richtig', 'Falsch'],
              correctAnswer: 'Falsch',
              explanation: {
                en: 'The notice clarifies: "Der reguläre Unterricht in den Kursräumen findet wie gewohnt statt." Only the office is closed.',
                fa: 'در اطلاعیه تصریح شده: "کلاس‌های آموزشی طبق روال معمول برگزار می‌شوند." فقط دبیرخانه تعطیل است.',
                prs: 'درس‌ها طبق معمول دایر است، فقط شعبه اداری بسته است.',
                tr: 'Duyuruda: "Dersler her zamanki gibi devam edecektir" denmektedir. Sadece sekreterlik kapalıdır.',
                ar: 'يوضح الإعلان: "الدروس النظامية في القاعات مستمرة كالمعتاد". السكرتارية فقط مغلقة.',
                es: 'El aviso aclara: "Las clases regulares se imparten como de costumbre". Solo la secretaría está cerrada.'
              }
            }
          ]
        }
      ]
    },
    hoeren: {
      title: 'Modul Hören (20 Minuten)',
      durationMinutes: 20,
      audioItems: [
        {
          id: 'a1_h_1',
          title: 'Teil 1: Durchsage am Bahnhof',
          situation: 'Durchsage am Hauptbahnhof Gleis 4',
          transcript: 'Achtung an Gleis 4: Der Intercity-Express aus Frankfurt zur Weiterfahrt nach Berlin Hauptbahnhof fährt heute abweichend von Gleis 7 ab. Ich wiederhole: ICE nach Berlin abweichend von Gleis 7. Bitte benutzen Sie die Unterführung.',
          questions: [
            {
              id: 'a1_h_q1',
              question: 'Von welchem Gleis fährt der Zug nach Berlin ab?',
              options: ['Gleis 4', 'Gleis 7', 'Gleis 9'],
              correctAnswer: 'Gleis 7',
              explanation: {
                en: 'The speaker announces: "... fährt heute abweichend von Gleis 7 ab."',
                fa: 'گوینده اعلام می‌کند: "امروز استثنائاً از سکوی ۷ حرکت می‌کند."',
                prs: 'گوینده اعلام کرد که قطار از سکوی ۷ حرکت می‌کند.',
                tr: 'Anons: "... bugün değişiklik olarak 7. perondan hareket edecektir" demektedir.',
                ar: 'يعلن المذيع: "... يغادر اليوم استثنائياً من الرصيف 7."',
                es: 'El locutor anuncia: "... sale hoy excepcionalmente de la vía 7."'
              }
            }
          ]
        }
      ]
    },
    schreiben: {
      title: 'Modul Schreiben (20 Minuten)',
      durationMinutes: 20,
      taskType: 'Teil 2: Kurze Mitteilung (E-Mail)',
      situation: 'Sie möchten am nächsten Deutschkurs teilnehmen und haben Fragen zur Einstufung.',
      prompt: 'Schreiben Sie an die Sprachschule "Sprachakademie München":\n1. Warum schreiben Sie?\n2. Ihr aktuelles Sprachniveau (A1 abgeschlossen).\n3. Bitte um einen Einstufungstest.',
      guidingPoints: ['Grund des Schreibens', 'Sprachniveau mitteilen', 'Bitte um Einstufungstest'],
      targetWordCount: 'ca. 30 Wörter',
      sampleSolution: 'Sehr geehrte Damen und Herren,\nich möchte mich für den neuen Deutschkurs A2 anmelden. Ich habe den A1-Kurs bereits abgeschlossen. Könnte ich bitte nächste Woche einen kurzen Einstufungstest machen?\nMit freundlichen Grüßen,\nAli Reza',
      scoringCriteria: {
        en: 'Fulfilled all 3 points, correct salutation and sign-off, basic grammatical correctness.',
        fa: 'پوشش هر ۳ نکته، سلام و امضای صحیح اداری، صحت نسبی ساختار جمله.',
        prs: 'پوشش هر ۳ نکته، سلام و خاتمه درست، صحت جمله‌بندی.',
        tr: '3 maddenin tamamlanması, doğru hitap ve kapanış, temel gramer doğruluğu.',
        ar: 'تغطية النقاط الثلاث، التحية والخاتمة الصحيحتان، السلامة اللغوية الأساسية.',
        es: 'Cumplimiento de los 3 puntos, saludo y despedida formales, corrección básica.'
      }
    },
    sprechen: {
      title: 'Modul Sprechen (15 Minuten Gruppenprüfung)',
      durationMinutes: 15,
      teil1: {
        name: 'Teil 1: Sich vorstellen (Name, Alter, Land, Beruf, Sprache, Hobby)',
        instruction: {
          en: 'Introduce yourself with personal facts, then spell your family name or state your phone number on request.',
          fa: 'خود را با اطلاعات فردی معرفی کنید، سپس نام خانوادگی یا شماره تلفن خود را به درخواست ممتحن هجی نمایید.',
          prs: 'خود را معرفی کنید و تخلص یا شماره تلفن خود را هجی نمایید.',
          tr: 'Kendinizi tanıtın ve sınav görevlisinin isteği üzerine soyadınızı veya telefon numaranızı harf harf kodlayın.',
          ar: 'قدم نفسك مستخدماً بياناتك الشخصية، ثم قم بتهجئة لقبك أو رقم هاتفك عند طلب الممتحن.',
          es: 'Preséntate con tus datos personales y deletrea tu apellido o número de teléfono cuando lo solicite el examinador.'
        },
        prompts: ['Name', 'Alter', 'Land', 'Wohnort', 'Sprachen', 'Beruf', 'Hobby'],
        sampleResponse: 'Mein Name ist Ahmad Rahimi. Ich bin 26 Jahre alt und komme aus Afghanistan. Jetzt wohne ich in Frankfurt. Ich spreche Dari, Pashto und lerne Deutsch. Von Beruf bin ich Buchhalter. In meiner Freizeit spiele ich gerne Fußball.'
      },
      teil2: {
        name: 'Teil 2: Um Informationen bitten und Informationen geben (Wortkarten)',
        instruction: {
          en: 'Draw a prompt card with a theme and formulate a question using the given word. Your partner answers.',
          fa: 'یک کارت موضوعی بردارید و با کلمه داده شده یک سوال مناسب بسازید. همتای شما به آن پاسخ می‌دهد.',
          prs: 'یک کارت بردارید و با کلمه داده‌شده سوال بسازید.',
          tr: 'Bir konu kartı çekin ve verilen kelimeyle uygun bir soru sorun. Partneriniz yanıtlar.',
          ar: 'اسحب بطاقة موضوع وصغ سؤالاً مناسباً باستخدام الكلمة المحددة. يجيب زميلك في الامتحان.',
          es: 'Toma una tarjeta temática y formula una pregunta con la palabra indicada. Tu compañero responde.'
        },
        topicCards: ['Thema: Einkaufen - Wort: Preis', 'Thema: Freizeit - Wort: Sport', 'Thema: Wohnen - Wort: Balkon'],
        sampleResponse: 'Frage: Wie viel kostet dieser Pullover bitte? - Antwort: Der Pullover kostet 29 Euro.'
      },
      teil3: {
        name: 'Teil 3: Bitten formulieren und darauf reagieren (Bildkarten)',
        instruction: {
          en: 'Formulate a polite request based on an object picture card. Respond appropriately.',
          fa: 'بر اساس تصویر کارت (مانند لیوان آب یا پنجره باز)، یک خواهش محترمانه مطرح کنید و متقابلاً پاسخ دهید.',
          prs: 'بر اساس عکس کارت، خواهش مودبانه مطرح کنید.',
          tr: 'Resimli karta göre kibar bir rica cümlesi kurun ve karşı ricaya uygun yanıt verin.',
          ar: 'صغ طلباً مهذباً بناءً على بطاقة الصورة واعرض رداً مناسباً.',
          es: 'Formula una petición formal a partir de la tarjeta con imagen y responde adecuadamente.'
        },
        planningScenario: 'Alltagssituationen: Höfliche Bitten mit Modalverben (können, möchten)',
        discussionPoints: ['Ein Glas Wasser erbitten', 'Das Fenster öffnen/schließen', 'Einen Stift leihen'],
        sampleResponse: 'Bitte: Könnten Sie mir bitte einen Stift leihen? - Reaktion: Ja, natürlich, bitte sehr!'
      }
    }
  },

  // ================= GOETHE A2 =================
  {
    id: 'exam_goethe_a2',
    title: 'Goethe-Zertifikat A2 (Modellsatz)',
    standard: 'Goethe-Zertifikat',
    level: 'A2.1',
    totalDurationMinutes: 80,
    passingScore: '60% (60 / 100 Punkte)',
    strategy: {
      level: 'A2.1',
      timeManagement: [
        {
          section: 'Lesen (Reading)',
          allocatedMinutes: 30,
          tip: {
            en: '4 parts in total. Read emails, classified ads, and short magazine articles. Allocate 7-8 min per part.',
            fa: 'شامل ۴ بخش: خواندن ایمیل‌ها، آگهی‌ها و مقالات کوتاه. حدود ۷ الی ۸ دقیقه برای هر بخش زمان بگذارید.',
            prs: 'شامل ۴ بخش: خواندن ایمیل، آگهی و متن کوتاه.',
            tr: 'Toplam 4 bölüm. E-postalar, ilanlar ve kısa yazıları okuyun.',
            ar: '4 أقسام للقراءة. خصص 7-8 دقائق لكل جزء.',
            es: '4 partes en total. Asigna de 7 a 8 minutos por parte.'
          }
        },
        {
          section: 'Hören (Listening)',
          allocatedMinutes: 30,
          tip: {
            en: '4 parts. Listen for specific information (numbers, times, appointments).',
            fa: 'شامل ۴ بخش شنیداری. روی اطلاعات خاص نظیر ساعات، قیمت‌ها و مکان‌ها تمرکز کنید.',
            prs: 'روی ساعت، قیمت و مکان‌ها در بخش شنیداری تمرکز کنید.',
            tr: '4 bölüm. Saatler, sayılar ve randevulara odaklanın.',
            ar: '4 أقسام للاستماع. ركز على التواريخ والأوقات والأسعار.',
            es: '4 partes de comprensión auditiva.'
          }
        },
        {
          section: 'Schreiben (Writing)',
          allocatedMinutes: 30,
          tip: {
            en: 'Teil 1: Short SMS/Messenger note (~20-30 words). Teil 2: Polite formal email (~30-40 words).',
            fa: 'بخش ۱: پیامک کوتاه یا یادداشت (۲۰-۳۰ کلمه). بخش ۲: ایمیل اداری مؤدبانه (۳۰-۴۰ کلمه).',
            prs: 'بخش اول پیام کوتاه و بخش دوم ایمیل رسمی است.',
            tr: '1. Bölüm: Kısa mesaj (20-30 kelime). 2. Bölüm: Resmi e-posta (30-40 kelime).',
            ar: 'الجزء 1: رسالة قصيرة. الجزء 2: بريد رسمي مهذب.',
            es: 'Parte 1: Mensaje breve. Parte 2: Correo formal.'
          }
        }
      ],
      stepByStepStrategies: [
        {
          title: 'Lesen Teil 3 (Anzeigen zuordnen)',
          steps: [
            {
              en: 'Read the situation requirements first, then scan headings and prices in the ads.',
              fa: 'ابتدا نیازهای فرد را بخوانید، سپس در آگهی‌ها به دنبال تطابق واژگان کلیدی باشید.',
              prs: 'اول نیازهای شخص را بخوانید، بعد در آگهی‌ها دنبال کلمات کلیدی بگردید.',
              tr: 'Önce kişi ihtiyaçlarını okuyun, sonra ilanlardaki anahtar kelimeleri eşleştirin.',
              ar: 'اقرأ متطلبات الشخص أولاً ثم ابحث عن الكلمات المفتاحية في الإعلانات.',
              es: 'Lee primero las necesidades y luego relaciona las palabras clave.'
            }
          ]
        }
      ],
      commonMistakes: [
        {
          mistake: 'Confusing past tense Perfekt auxiliaries (haben vs. sein).',
          correction: 'Use "sein" for motion verbs like fahren, gehen, fliegen, and "haben" for transitive verbs.',
          explanation: {
            en: 'Remember: Ich bin nach Berlin gefahren, aber ich habe ein Ticket gekauft.',
            fa: 'افعال حرکتی تغییر مکان مانند fahren با sein ساخته می‌شوند.',
            prs: 'افعال حرکتی با sein در گذشته کامل ساخته می‌شوند.',
            tr: 'Hareketi belirten fiiller Perfektte "sein" alır.',
            ar: 'أفعال الحركة تأخذ "sein" في الماضي التام.',
            es: 'Los verbos de cambio de lugar llevan "sein" en Perfekt.'
          }
        }
      ]
    },
    lesen: {
      title: 'Modul Lesen (30 Minuten)',
      durationMinutes: 30,
      texts: [
        {
          title: 'Teil 1: E-Mail von einer Kollegin',
          sourceType: 'E-Mail',
          body: 'Liebe Lena,\nunsere Teambesprechung am Montag muss leider verschoben werden, weil unser Abteilungsleiter Herr Weber auf Dienstreise in Köln ist. Der neue Termin ist Mittwoch um 10:30 Uhr im Konferenzraum 2. Bring bitte die Quartalsberichte ausgedruckt mit.\nViele Grüße,\nSabine',
          questions: [
            {
              id: 'a2_l_q1',
              question: 'Die Teambesprechung findet am Montag statt.',
              options: ['Richtig', 'Falsch'],
              correctAnswer: 'Falsch',
              explanation: {
                en: 'Sabine explains that Monday meeting is postponed to Wednesday at 10:30.',
                fa: 'سابینه توضیح می‌دهد که جلسه دوشنبه لغو و به چهارشنبه موکول شده است.',
                prs: 'جلسه دوشنبه به چهارشنبه منتقل شده است.',
                tr: 'Pazartesi günkü toplantı çarşambaya ertelenmiştir.',
                ar: 'أوضحت سابين أن الاجتماع تأجل إلى الأربعاء.',
                es: 'La reunión del lunes se aplazó al miércoles.'
              }
            },
            {
              id: 'a2_l_q2',
              question: 'Herr Weber ist am Montag nicht im Büro.',
              options: ['Richtig', 'Falsch'],
              correctAnswer: 'Richtig',
              explanation: {
                en: 'Herr Weber is on a business trip in Cologne (Dienstreise in Köln).',
                fa: 'آقای وبر در ماموریت کاری در کلن به سر می‌برد.',
                prs: 'آقای وبر در سفر کاری است و در دفتر نیست.',
                tr: 'Herr Weber Köln\'de iş seyahatindedir.',
                ar: 'السيد فيبر في رحلة عمل في كولونيا.',
                es: 'El señor Weber está de viaje de negocios en Colonia.'
              }
            }
          ]
        }
      ]
    },
    hoeren: {
      title: 'Modul Hören (30 Minuten)',
      durationMinutes: 30,
      audioItems: [
        {
          id: 'a2_h_1',
          title: 'Teil 1: Telefonansage Praxis Dr. Neumann',
          situation: 'Anrufbeantworter einer Arztpraxis',
          transcript: 'Guten Tag, Sie sind verbunden mit der Arztpraxis Dr. Neumann. Unsere Praxis ist vom 2. bis zum 16. August wegen Urlaubs geschlossen. In dringenden Notfällen wenden Sie sich bitte an den ärztlichen Bereitschaftsdienst unter der Telefonnummer 116 117.',
          questions: [
            {
              id: 'a2_h_q1',
              question: 'Wann öffnet die Arztpraxis wieder regulär?',
              options: ['Am 2. August', 'Am 16. August', 'Am 17. August'],
              correctAnswer: 'Am 17. August',
              explanation: {
                en: 'The clinic is closed until August 16th inclusive, reopening on August 17th.',
                fa: 'مطب تا ۱۶ آگوست تعطیل است و از ۱۷ آگوست بازگشایی می‌شود.',
                prs: 'مطب تا ۱۶ آگست رخصت است و روز ۱۷ آگست باز می‌شود.',
                tr: 'Klinik 16 Ağustos dahil kapalı olup 17 Ağustos\'ta açılacaktır.',
                ar: 'العيادة مغلقة حتى 16 أغسطس وتفتح في 17 أغسطس.',
                es: 'La consulta está cerrada hasta el 16 inclusive, reabre el 17.'
              }
            }
          ]
        }
      ]
    },
    schreiben: {
      title: 'Modul Schreiben (30 Minuten)',
      durationMinutes: 30,
      taskType: 'Teil 2: Formelle E-Mail (Entschuldigung / Terminabsage)',
      situation: 'Sie können wegen einer akuten Erkältung nicht zum Deutschkurs kommen.',
      prompt: 'Schreiben Sie an Ihre Kursleiterin Frau Meyer:\n1. Grund für das Fehlen (Krankheit).\n2. Bitte um Hausaufgaben und Unterrichtsmaterial.\n3. Voraussichtliche Rückkehr zum Unterricht.',
      guidingPoints: ['Krankmeldung', 'Hausaufgaben erbitten', 'Rückkehr ankündigen'],
      targetWordCount: 'ca. 40 Wörter',
      sampleSolution: 'Sehr geehrte Frau Meyer,\nleider bin ich stark erkältet und kann heute nicht am Unterricht teilnehmen. Könnten Sie mir bitte die Hausaufgaben per E-Mail schicken? Am kommenden Montag bin ich voraussichtlich wieder im Kurs.\nVielen Dank und freundliche Grüße,\nSoran Karimi',
      scoringCriteria: {
        en: 'Formal salutation, clear explanation of illness, polite request for homework with Konjunktiv II.',
        fa: 'سلام رسمی، توضیح بیماری، درخواست مؤدبانه تکالیف با کونیونکتیو ۲.',
        prs: 'سلام رسمی، معذرت‌خواهی بیماری، خواهش تکالیف خانگی.',
        tr: 'Resmi hitap, hastalık beyanı, Konjunktiv II ile kibar ödev ricası.',
        ar: 'تحية رسمية، بيان العذر المرضي، طلب الواجب بصيغة التأدب.',
        es: 'Saludo formal, motivo de ausencia, petición educada de tareas.'
      }
    },
    sprechen: {
      title: 'Modul Sprechen (15 Minuten Paarprüfung)',
      durationMinutes: 15,
      teil1: {
        name: 'Teil 1: Fragen zur Person beantworten',
        instruction: {
          en: 'Answer detailed questions about your living situation, family, work, and free time.',
          fa: 'به سوالات دقیق‌تر ممتحن درباره محل زندگی، شغل و تجارب روزمره پاسخ دهید.',
          prs: 'به سوالات درباره وضعیت زندگی، کار و فراغت پاسخ دهید.',
          tr: 'Yaşamınız, işiniz ve boş zamanlarınızla ilgili ayrıntılı soruları yanıtlayın.',
          ar: 'أجب عن أسئلة تفصيلية حول عملك وحياتك اليومية.',
          es: 'Responde a preguntas detalladas sobre tu vida diaria y trabajo.'
        },
        prompts: ['Wohnung & Stadt', 'Beruf & Ausbildung', 'Reisen & Urlaub'],
        sampleResponse: 'Ich wohne in einer 3-Zimmer-Wohnung in Berlin-Kreuzberg. Die Wohnung hat einen schönen Balkon und liegt nahe an der U-Bahn.'
      },
      teil2: {
        name: 'Teil 2: Von sich erzählen (Erfahrungen berichten)',
        instruction: {
          en: 'Talk for 1-2 minutes about an everyday topic (e.g. Mein letztes Wochenende, Mein Lieblingsessen).',
          fa: 'به مدت ۱ تا ۲ دقیقه درباره یک موضوع روزمره (مانند آخر هفته گذشته) پیوسته صحبت کنید.',
          prs: 'برای ۱ تا ۲ دقیقه درباره یک موضوع روزمره به آلمانی صحبت کنید.',
          tr: 'Günlük bir konu hakkında (örn. son hafta sonum) 1-2 dakika kesintisiz konuşun.',
          ar: 'تحدث لمدة 1-2 دقيقة حول موضوع من الحياة اليومية.',
          es: 'Habla durante 1 o 2 minutos sobre un tema cotidiano.'
        },
        topicCards: ['Thema: Mein letztes Wochenende', 'Thema: Sport und Gesundheit', 'Thema: Urlaub am Meer'],
        sampleResponse: 'Letztes Wochenende habe ich mit Freunden einen Ausflug an den Wannsee gemacht. Wir haben gegrillt und sind spazieren gegangen.'
      },
      teil3: {
        name: 'Teil 3: Gemeinsam etwas aushandeln / planen',
        instruction: {
          en: 'Plan an event or task together with your exam partner (e.g. buying a birthday present).',
          fa: 'با همتای امتحانی خود برای انجام یک فعالیت مشترک (مانند خرید کادو یا برنامه‌ریزی سفر) توافق کنید.',
          prs: 'با هم‌صنفی خود یک برنامه مشترک (مانند هدیه خریدن) را هماهنگ کنید.',
          tr: 'Sınav partnerinizle ortak bir etkinlik planlayın ve uzlaşmaya varın.',
          ar: 'خطط لفعالية مشتركة مع زميلك في الامتحان وتوصلا إلى اتفاق.',
          es: 'Planifica una actividad conjunta con tu compañero de examen.'
        },
        planningScenario: 'Ein Geburtstagsgeschenk für einen gemeinsamen Freund kaufen',
        discussionPoints: ['Was kaufen? (Gutschein, Buch)', 'Wie viel Geld ausgeben?', 'Wann und wo treffen?'],
        sampleResponse: 'Ich schlage vor, dass wir ihm einen Buchgutschein schenken. Was meinst du dazu? - Das ist eine gute Idee! Wir könnten uns am Samstag um 14 Uhr vor der Buchhandlung treffen.'
      }
    }
  },

  // ================= GOETHE / TELC B1 =================
  {
    id: 'exam_goethe_b1',
    title: 'Goethe- / telc Zertifikat B1 (Modellsatz)',
    standard: 'Goethe-Zertifikat',
    level: 'B1.1',
    totalDurationMinutes: 165,
    passingScore: '60% in jedem Modul (Lesen, Hören, Schreiben, Sprechen)',
    strategy: {
      level: 'B1.1',
      timeManagement: [
        {
          section: 'Lesen (Reading)',
          allocatedMinutes: 65,
          tip: {
            en: '5 parts: Blog posts, press articles, job listings, public regulations. Keep steady pace: 12-13 min per part.',
            fa: 'شامل ۵ بخش: وبلاگ‌ها، مقالات خبری، آگهی‌های استخدام و قوانین. زمان‌بندی دقیق: ۱۲ الی ۱۳ دقیقه برای هر بخش.',
            prs: 'شامل ۵ بخش متن خوانی. حدود ۱۲ الی ۱۳ دقیقه به هر بخش اختصاص دهید.',
            tr: '5 bölüm. Bloglar, haberler ve ilanlar. Her bölüme yaklaşık 12-13 dakika ayırın.',
            ar: '5 أقسام للقراءة. خصص 12-13 دقيقة لكل جزء.',
            es: '5 partes. Administra 12-13 minutos por parte.'
          }
        },
        {
          section: 'Hören (Listening)',
          allocatedMinutes: 40,
          tip: {
            en: '4 parts: Public announcements, radio features, informal conversations, discussion panel.',
            fa: 'شامل ۴ بخش: اطلاعیه‌های عمومی، گزارش‌های رادیویی، مکالمات روزمره و میزگرد بحث و گفتگو.',
            prs: '۴ بخش شنیداری شامل رادیو، مکالمات و میزگرد.',
            tr: '4 bölüm. Radyo haberleri ve panel tartışmaları.',
            ar: '4 أقسام استماع تشمل إعلانات وحوارات إذاعية.',
            es: '4 partes de comprensión auditiva.'
          }
        },
        {
          section: 'Schreiben (Writing)',
          allocatedMinutes: 60,
          tip: {
            en: 'Teil 1: Personal email (~80 words, 20 min). Teil 2: Opinion post on a forum (~80 words, 25 min). Teil 3: Formal message (~40 words, 15 min).',
            fa: 'بخش ۱: ایمیل دوستانه (۸۰ کلمه، ۲۰ دقیقه). بخش ۲: ابراز نظر در تالار گفتگو (۸۰ کلمه، ۲۵ دقیقه). بخش ۳: پیام رسمی کوتاه (۴۰ کلمه، ۱۵ دقیقه).',
            prs: 'سه بخش نگارش: ایمیل دوستانه، ابراز نظر در فروم، و نامه اداری.',
            tr: '1. Bölüm: Kişisel e-posta. 2. Bölüm: Görüş yazısı. 3. Bölüm: Resmi bildirim.',
            ar: '3 أقسام للكتابة: بريد شخصي، إبداء رأي في منتدى، ورسالة رسمية.',
            es: '3 partes de redacción escrita.'
          }
        }
      ],
      stepByStepStrategies: [
        {
          title: 'Schreiben Teil 2 (Meinungsäußerung)',
          steps: [
            {
              en: '1. State your personal stance clearly. 2. Give 1-2 concrete reasons. 3. Provide an example from your home country or daily life.',
              fa: '۱. موضع خود را صریح بیان کنید. ۲. ۱ یا ۲ دلیل منطقی بیاورید. ۳. یک مثال از زندگی شخصی یا کشورتان ذکر کنید.',
              prs: '۱. نظر خود را واضح بگویید. ۲. دلیل بیاورید. ۳. مثالی از کشورتان یا تجربه خودتان ذکر کنید.',
              tr: '1. Görüşünüzü açıkça belirtin. 2. 1-2 somut gerekçe sunun. 3. Kendi deneyiminizden örnek verin.',
              ar: '1. وضح رأيك بوضوح. 2. اذكر سببين مقنعين. 3. أعطِ مثالاً من تجربتك أو بلدك.',
              es: '1. Expresa tu postura claramente. 2. Aporta razones. 3. Da un ejemplo.'
            }
          ]
        }
      ],
      commonMistakes: [
        {
          mistake: 'Using only simple main clauses without subordinate connectors.',
          correction: 'Use varied connectors: weil, obwohl, dass, wenn, damit, um ... zu.',
          explanation: {
            en: 'At B1 level, examiners expect a solid mix of subordinate clauses and relative clauses.',
            fa: 'در سطح B1 ممتحنین انتظار دارند از حروف ربط متنوع مانند weil، obwohl، damit و جملات موصولی استفاده شود.',
            prs: 'در B1 از حروف ربط پیوندی مانند weil و obwohl استفاده نمایید.',
            tr: 'B1 seviyesinde çeşitli yan cümle bağlaçları (weil, obwohl vb.) beklenir.',
            ar: 'في مستوى B1 يُتوقع استخدام أدوات ربط متنوعة لجمل تابعة.',
            es: 'En el nivel B1 se requiere el uso variado de conectores subordinantes.'
          }
        }
      ]
    },
    lesen: {
      title: 'Modul Lesen (65 Minuten)',
      durationMinutes: 65,
      texts: [
        {
          title: 'Teil 1: Blogbeitrag zum Thema "Homeoffice und flexible Arbeitszeiten"',
          sourceType: 'Online-Blog',
          body: 'Immer mehr Unternehmen in Deutschland bieten ihren Mitarbeitern hybride Arbeitsmodelle an. Die Möglichkeit, zwei oder drei Tage pro Woche von zu Hause aus zu arbeiten, spart nicht nur Pendelzeit im Berufsverkehr, sondern ermöglicht auch eine bessere Vereinbarkeit von Familie und Beruf. Dennoch vermissen viele Beschäftigte den spontanen persönlichen Austausch mit den Kollegen an der Kaffeemaschine. Experten raten daher zu festen Präsenztagen für gemeinsame Workshops.',
          questions: [
            {
              id: 'b1_l_q1',
              question: 'Hybrides Arbeiten führt laut Text zu weniger Zeitaufwand für den Arbeitsweg.',
              options: ['Richtig', 'Falsch'],
              correctAnswer: 'Richtig',
              explanation: {
                en: 'The text confirms: "... spart nicht nur Pendelzeit im Berufsverkehr".',
                fa: 'در متن تصریح شده: "... نه تنها در زمان رفت‌وآمد روزانه صرفه‌جویی می‌کند".',
                prs: 'متن تایید می‌کند که زمان رفت و آمد در ترافیک کمتر می‌شود.',
                tr: 'Metin trafiğe harcanan sürenin azaldığını teyit etmektedir.',
                ar: 'يؤكد النص أن العمل الهجين يوفر وقت التنقل في أوقات الذروة.',
                es: 'El texto confirma que ahorra tiempo de desplazamiento.'
              }
            },
            {
              id: 'b1_l_q2',
              question: 'Alle Arbeitnehmer möchten ausschließlich von zu Hause aus arbeiten.',
              options: ['Richtig', 'Falsch'],
              correctAnswer: 'Falsch',
              explanation: {
                en: 'The text states that many employees miss personal contact and face-to-face exchange with colleagues.',
                fa: 'متن بیان می‌کند که بسیاری از کارمندان دلتنگ تعاملات حضوری با همکاران می‌شوند.',
                prs: 'متن می‌گوید که کارمندان دلشان برای گفتگوهای حضوری با همکاران تنگ می‌شود.',
                tr: 'Metinde çalışanların yüz yüze iletişimi özlediği belirtilmektedir.',
                ar: 'يوضح النص أن كثيراً من الموظفين يفتقدون التواصل المباشر مع الزملاء.',
                es: 'El texto indica que muchos echan de menos el contacto personal.'
              }
            }
          ]
        }
      ]
    },
    hoeren: {
      title: 'Modul Hören (40 Minuten)',
      durationMinutes: 40,
      audioItems: [
        {
          id: 'b1_h_1',
          title: 'Teil 2: Radioreportage über nachhaltige Mobilität in Großstädten',
          situation: 'Radiosendung im Deutschlandfunk',
          transcript: 'Willkommen zu unserer Sendung "Umwelt und Zukunft". Heute blicken wir nach Freiburg im Breisgau. Dort hat die Stadtverwaltung ein umfassendes Konzept zur Verkehrsberuhigung umgesetzt: Tempo-30-Zonen in allen Wohngebieten, ein dichtes Netz an Fahrradstraßen sowie vergünstigte Monatstickets für den öffentlichen Nahverkehr. Innerhalb von fünf Jahren stieg der Anteil des Radverkehrs um beachtliche 25 Prozent.',
          questions: [
            {
              id: 'b1_h_q1',
              question: 'Was war eine der Maßnahmen der Stadt Freiburg?',
              options: ['Verbot von Fahrrädern in der Innenstadt', 'Einführung von Tempo-30-Zonen in Wohngebieten', 'Preiserhöhung für Busse und Bahnen'],
              correctAnswer: 'Einführung von Tempo-30-Zonen in Wohngebieten',
              explanation: {
                en: 'The report highlights: "Tempo-30-Zonen in allen Wohngebieten".',
                fa: 'گزارشگر بر برقراری مناطق حداکثر سرعت ۳۰ کیلومتر بر ساعت در مناطق مسکونی تاکید می‌کند.',
                prs: 'یکی از اقدامات، تعیین سرعت حداکثر ۳۰ در مناطق رهایشی بود.',
                tr: 'Habere göre yerleşim bölgelerinde 30 km hız sınırı getirilmiştir.',
                ar: 'أشار التقرير إلى تطبيق مناطق السرعة 30 في كافة الأحياء السكنية.',
                es: 'La medida fue introducir zonas de velocidad a 30 km/h.'
              }
            }
          ]
        }
      ]
    },
    schreiben: {
      title: 'Modul Schreiben (60 Minuten)',
      durationMinutes: 60,
      taskType: 'Teil 2: Meinungsäußerung im Diskussionsforum',
      situation: 'In einem Online-Magazin lesen Sie einen Beitrag zum Thema "Brauchen wir noch Bargeld oder reicht die Kartenzahlung?".',
      prompt: 'Schreiben Sie einen Beitrag für das Diskussionsforum:\n1. Äußern Sie Ihre persönliche Meinung zum bargeldlosen Bezahlen.\n2. Nennen Sie Vor- und Nachteile (z. B. Bequemlichkeit vs. Datenschutz/Kontrollverlust).\n3. Berichten Sie über die Situation in Ihrem Heimatland.',
      guidingPoints: ['Eigene Haltung darstellen', 'Vor- und Nachteile abwägen', 'Situation im Heimatland beschreiben'],
      targetWordCount: 'ca. 80 Wörter',
      sampleSolution: 'Ich finde das Thema bargeldloses Bezahlen hochaktuell und diskussionswürdig. Einerseits ist das Zahlen mit Karte oder Smartphone im Alltag extrem bequem, schnell und praktisch. Andererseits birgt die reine Kartenzahlung auch Risiken für den Datenschutz, da alle Einkäufe digital nachverfolgt werden können. In meinem Heimatland wird nach wie vor überwiegend mit Bargeld bezahlt, besonders auf traditionellen Basaren und in kleineren Geschäften. Meiner Ansicht nach sollte man beiden Bezahlmethoden den Vorzug lassen, damit jeder frei entscheiden kann.',
      scoringCriteria: {
        en: 'Coherent structure, varied sentence connectors (einerseits/andererseits), addressing all guiding prompts with personal stance.',
        fa: 'ساختار منسجم، به کار بردن حروف ربط دوگانه (einerseits/andererseits)، پوشش همه نکات همراه با بیان موضع شخصی.',
        prs: 'ساختار منسجم، استفاده از حروف ربط، پاسخ به همه بخش‌ها.',
        tr: 'Bütünlüklü metin yapısı, zengin bağlaç kullanımı ve tüm noktalara değinilmesi.',
        ar: 'بناء متماسك، استخدام أدوات ربط مزدوجة، وتغطية جميع النقاط.',
        es: 'Estructura coherente, conectores variados y desarrollo de todos los puntos.'
      }
    },
    sprechen: {
      title: 'Modul Sprechen (15 Minuten Paarprüfung)',
      durationMinutes: 15,
      teil1: {
        name: 'Teil 1: Gemeinsam etwas planen',
        instruction: {
          en: 'Plan an event or trip together with your partner. Negotiate dates, responsibilities, and details.',
          fa: 'با همتای امتحانی خود یک رویداد یا سفر را با جزئیات کامل (تاریخ، تقسیم وظایف، بودجه) برنامه‌ریزی کنید.',
          prs: 'با پارتنر تان یک برنامه یا سفر را به تفصیل هماهنگ کنید.',
          tr: 'Partnerinizle birlikte bir gezi veya etkinlik planlayın.',
          ar: 'خططا معاً لرحلة أو مناسبة وناقشا المواعيد والتكاليف.',
          es: 'Planificad juntos un evento negociando detalles y tareas.'
        },
        prompts: ['Reiseziel & Anreise', 'Unterkunft buchen', 'Freizeitprogramm'],
        sampleResponse: 'Wir könnten nächstes Wochenende nach Hamburg fahren. Ich würde vorschlagen, dass wir den Zug nehmen. Was hältst du davon?'
      },
      teil2: {
        name: 'Teil 2: Ein Thema präsentieren (Präsentation)',
        instruction: {
          en: 'Give a structured 3-minute presentation on a chosen topic with introduction, structure, pros/cons, experience, and conclusion.',
          fa: 'یک سخنرانی منسجم ۳ دقیقه‌ای شامل مقدمه، تجارب شخصی، مزایا و معایب و نتیجه‌گیری ارائه دهید.',
          prs: 'یک پرزنتیشن منسجم ۳ دقیقه‌ای با مقدمه، تجربه شخصی و مزایا ارائه دهید.',
          tr: 'Giriş, kişisel deneyim, avantaj/dezavantaj içeren 3 dakikalık sunum yapın.',
          ar: 'قدم عرضاً تقديمياً لمدة 3 دقائق ببنية واضحة ومقدمة وخاتمة.',
          es: 'Realiza una presentación estructurada de 3 minutos.'
        },
        topicCards: ['Thema: Soziale Medien im Alltag', 'Thema: Leben ohne Auto', 'Thema: Fremdsprachen im Kindergarten'],
        sampleResponse: 'Meine Präsentation beschäftigt sich mit dem Thema "Leben ohne Auto". Zuerst spreche ich über meine persönlichen Erfahrungen, danach über die Situation in meinem Heimatland und schließlich über Vor- und Nachteile...'
      },
      teil3: {
        name: 'Teil 3: Auf Fragen reagieren und Feedback geben',
        instruction: {
          en: 'Ask questions about your partner\'s presentation and answer questions from the examiners and partner.',
          fa: 'به سوالات داوران و همتای خود درباره سخنرانی‌تان پاسخ دهید و به سخنرانی او بازخورد مناسب دهید.',
          prs: 'به سوالات درباره پرزنتیشن تان پاسخ دهید.',
          tr: 'Partnerinizin sunumu hakkında sorular sorun ve gelen soruları yanıtlayın.',
          ar: 'اطرح أسئلة حول عرض زميلك وأجب عن أسئلة الممتحنين.',
          es: 'Formula preguntas sobre la presentación de tu compañero y responde.'
        },
        planningScenario: 'Feedback und Anschlussfragen',
        discussionPoints: ['Verständnisfragen stellen', 'Dank für die Präsentation', 'Eigene Sichtweise kurz ergänzen'],
        sampleResponse: 'Vielen Dank für deine interessante Präsentation. Ich habe eine Frage: Wie denkst du, wird sich die Situation auf dem Land entwickeln, wo es weniger Busse gibt?'
      }
    }
  }
];
