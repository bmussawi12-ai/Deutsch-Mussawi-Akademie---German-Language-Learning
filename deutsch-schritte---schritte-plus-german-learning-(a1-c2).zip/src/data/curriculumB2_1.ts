import { Lesson } from '../types';

export const CURRICULUM_B2_1: Lesson[] = [
  {
    id: 'b2_1_lek1',
    lektionNumber: 1,
    level: 'B2.1',
    title: 'Technologischer Wandel und Arbeitswelt 4.0',
    subTitle: 'Digitalisierung, KI am Arbeitsplatz und das Passiv mit Modalverben (B2 Niveau)',
    topic: 'Automatisierung, Ethik in der Technologie und formelle Fachkorrespondenz',
    fotoHoergeschichte: {
      title: 'Foto-Hörgeschichte: Die Einführung von KI in der Produktionshalle',
      imagePrompt: 'A cutting-edge automated production line in Stuttgart with industrial robotics, where German engineers discuss algorithmic quality control.',
      imageTheme: 'Industrie 4.0 in Baden-Württemberg',
      audioDuration: '03:15',
      transcript: [
        { speaker: 'Dr. Franke (Entwicklungsleiter)', text: 'Meine Damen und Herren, durch die Umstellung auf das neue Automatisierungssystem können Montagefehler künftig um 40 Prozent reduziert werden.' },
        { speaker: 'Frau Dr. Sommer', text: 'Das ist ein beachtlicher Fortschritt. Allerdings müssen sämtliche Mitarbeiter zeitnah im Umgang mit den neuen Softwaretools geschult werden.' },
        { speaker: 'Herr Krause (Betriebsrat)', text: 'Der Betriebsrat unterstützt die Modernisierung, sofern der Datenschutz gewährleistet bleibt und keine Arbeitsplätze abgebaut werden.' },
        { speaker: 'Dr. Franke', text: 'Selbstverständlich. Ein umfangreiches Qualifizierungsprogramm wurde bereits von der Geschäftsführung genehmigt.' }
      ],
      summary: {
        en: 'An industrial manufacturing enterprise in Baden-Württemberg introduces AI-driven quality inspection and plans employee training initiatives.',
        fa: 'یک واحد صنعتی تولیدی در بادن-وورتمبرگ سیستم کنترل کیفیت مبتنی بر هوش مصنوعی را راه‌اندازی نموده و برنامه‌های بازآموزی کارکنان را پیگیری می‌کند.',
        prs: 'یک فابریکه بزرگ صنعتی در بادن-وورتمبرگ سیستم بررسی کیفیت با هوش مصنوعی را فعال ساخته و پلان آموزش مسلکی کارمندان را عملی می‌نماید.',
        tr: 'Baden-Württemberg\'deki bir sanayi kuruluşu yapay zeka destekli kalite kontrol sistemini devreye alır ve çalışan eğitimlerini planlar.',
        ar: 'تعتمد منشأة تصنيع صناعية في بادن-فورتمبيرغ تقنيات الفحص المعتمدة على الذكاء الاصطناعي وتخطط لبرامج تدريب الموظفين.',
        es: 'Una empresa manufacturera en Baden-Wurtemberg implanta el control de calidad con IA y planifica programas de formación para la plantilla.'
      }
    },
    sectionA: {
      title: 'Mussawi A: Sprechen & Dialog',
      focus: 'Sprechen & Hören (Fachdiskussionen & Konferenzen)',
      description: {
        en: 'Lead sophisticated debates, formulate arguments persuasively, and respond to counterarguments.',
        fa: 'هدایت مباحثات تخصصی، بیان قانع‌کننده استدلال‌ها و پاسخ‌گویی به نظرات مخالف.',
        prs: 'پیشبرد مباحثات تخصصی تخنیکی، ارائه دلایل منطقی و پاسخ به نقدهای مسلکی.',
        tr: 'Yetkin tartışmaları yönetme, ikna edici savlar öne sürme ve karşı görüşleri karşılama.',
        ar: 'إدارة المناقشات التخصصية، صياغة الحجج بإقناع والرد على الآراء المعارضة.',
        es: 'Conducción de debates especializados, argumentación persuasiva y réplica a objeciones.'
      },
      content: 'Aus meiner Sicht sollte berücksichtigt werden, dass... / Es lässt sich nicht leugnen, dass...',
      audioText: 'Vor der Inbetriebnahme der Fertigungsstraße müssen alle sicherheitsrelevanten Protokolle penibel überprüft werden.',
      practiceTasks: [
        'Diskutieren Sie die Vor- und Nachteile von Homeoffice und digitaler Zeiterfassung.',
        'Halten Sie einen fünfminütigen Kurzvortrag über KI-Regulierungen.'
      ]
    },
    sectionB: {
      title: 'Mussawi B: Wortschatz & Hören',
      focus: 'Hören & Wortschatz (Fachterminologie Industrie 4.0)',
      description: {
        en: 'Advanced technological and operational vocabulary for engineering and business management.',
        fa: 'واژگان تخصصی فناوری، مهندسی و مدیریت تولید مدرن.',
        prs: 'لغات تخصصی تکنالوژی، انجنیری و مدیریت عصری تولید.',
        tr: 'Mühendislik ve işletme yönetimine yönelik ileri düzey teknolojik ve operasyonel terimler.',
        ar: 'المصطلحات التقنية والتشغيلية المتقدمة للهندسة وإدارة الأعمال الصناعية.',
        es: 'Léxico técnico y operativo avanzado para ingeniería y gestión empresarial.'
      },
      content: 'die Prozessoptimierung, die Datensicherheit, die Wertschöpfung, die Automatisierungsquote.',
      practiceTasks: [
        'Ordnen Sie Fachbegriffe ihren Definitionen zu.',
        'Verfassen Sie ein Protokoll über eine Sicherheitsunterweisung.'
      ]
    },
    sectionC: {
      title: 'Mussawi C: Alltagskommunikation',
      focus: 'Sprechen & Dialoge (Verhandlungen & Betriebsratssitzung)',
      description: {
        en: 'Formal business negotiations, mediating between worker councils and management.',
        fa: 'مذاکرات تجاری و رسمی، میانجی‌گری میان شورای کارگری و هیئت مدیره.',
        prs: 'مذاکرات رسمی تجارتی، هماهنگی میان شورای کارمندان و رهبری فابریکه.',
        tr: 'İşletme müzakereleri ve işçi temsilcileri ile yönetim arasında uzlaşma sağlama.',
        ar: 'المفاوضات الرسمية والوساطة بين مجالس العمال والإدارة العليا.',
        es: 'Negociaciones formales y mediación entre comités de empresa y dirección ejecutiva.'
      },
      content: 'Wir schlagen vor, eine Übergangsfrist von sechs Monaten zu vereinbaren.',
      audioText: 'In der heutigen Betriebsratssitzung muss geklärt werden, wie Weiterbildungen vergütet werden.',
      practiceTasks: [
        'Simulieren Sie eine Gehalts- und Weiterbildungsverhandlung.',
        'Formulieren Sie verbindliche Vereinbarungsentwürfe.'
      ]
    },
    sectionD: {
      title: 'Mussawi D: Leseverstehen & Text',
      focus: 'Lesen & Textanalyse (Wirtschaftsberichte & Fachaufsätze)',
      description: {
        en: 'Read and critically analyze complex articles from VDI Nachrichten and Handelsblatt.',
        fa: 'مطالعه و تحلیل موشکافانه گزارش‌های اقتصادی و مقالات فنی نشریات معتبر آلمان.',
        prs: 'مطالعه و تحلیل دقیق گزارش‌های اقتصادی و مقالات تخنیکی ژورنال‌های علمی.',
        tr: 'Saygın yayınlardan karmaşık teknik makaleleri ve ekonomi raporlarını okuyup tahlil etme.',
        ar: 'قراءة وتحليل المقالات التقنية والتقارير الاقتصادية المعقدة بصورة نقدية.',
        es: 'Lectura y análisis crítico de informes económicos y artículos técnicos especializados.'
      },
      content: 'Auszug aus einem Fachbericht des Bundesministeriums für Wirtschaft.',
      readingText: {
        type: 'Fachzeitschrift für Ingenieurwesen',
        title: 'Die Zukunft der industriellen Fertigung in Mitteleuropa',
        body: 'Mitteleuropäische Industrieunternehmen müssen ihre Effizienz durch smarte Algorithmen steigern. Gleichwohl darf der Faktor Mensch nicht vernachlässigt werden: Nur durch kontinuierliche Weiterbildungsmaßnahmen kann der Fachkräftebedarf gesichert werden.'
      },
      practiceTasks: [
        'Fassen Sie die Kernaussagen des Textes in eigenen Worten zusammen.',
        'Beantworten Sie Verständnisfragen zu globalen Lieferketten.'
      ]
    },
    sectionE: {
      title: 'Mussawi E: Grammatik & Schreiben',
      focus: 'Grammatik & Schreiben (Passiv mit Modalverben & Ersatzformen)',
      description: {
        en: 'Master passive voice combined with modal verbs in all tenses, and passive substitutes.',
        fa: 'تسلط بر گرامر جملات مجهول همراه با افعال مدال در تمام زمان‌ها و ساختارهای جانشین مجهول.',
        prs: 'تسلط بر گرامر جملات مجهول با افعال کمکی مدال در تمام زمان‌ها و بدل‌های مجهول.',
        tr: 'Modal fiillerle kurulan tüm zamanlardaki edilgen çatı ve edilgen çatı alternatifleri.',
        ar: 'إتقان صيغ المبني للمجهول مع الأفعال المساعدة في جميع الأزمنة وبدائل المجهول.',
        es: 'Dominio de la voz pasiva con verbos modales en todos los tiempos y sus sustitutos.'
      },
      content: 'Passiv mit Modalverben: "Die Dokumente müssen geprüft werden" / "Der Fehler konnte behoben werden".',
      grammarRule: {
        id: 'b2_1_passiv_modal',
        level: 'B2.1',
        germanTitle: 'Das Passiv mit Modalverben (Präsens & Präteritum)',
        formula: 'Subjekt + Modalverb (konjugiert) + ... + Partizip II + werden (Infinitiv)',
        explanation: {
          en: 'When forming passive with a modal verb, conjugate the modal verb on Position 2 and put the Partizip II followed by the infinitive "werden" at the very end.',
          fa: 'هنگام ساخت مجهول با فعل مدال، فعل مدال را در جایگاه دوم صرف کرده و صفت مفعولی (Partizip II) را به همراه مصدر "werden" در انتهای جمله قرار دهید.',
          prs: 'در ساختن مجهول با افعال مدال، فعل مدال در جایگاه دوم صرف می‌شود و صفت مفعولی همراه با مصدر werden در اخیر جمله می‌آید.',
          tr: 'Modal fiilli edilgen çatıda: Çekimli modal fiil 2. pozisyonda yer alır, cümlenin sonunda ise Partizip II + "werden" bulunur.',
          ar: 'في صيغة المجهول مع فعل مساعد: يصرف الفعل المساعد في الموقع 2، ويوضع اسم المفعول متبوعاً بالمصدر werden في نهاية الجملة.',
          es: 'En la pasiva con verbos modales: el modal se conjuga en la posición 2 y al final se colocan el participio y "werden" en infinitivo.'
        },
        examples: [
          {
            german: 'Die Sicherheitsrichtlinien müssen unverzüglich eingehalten werden.',
            formulaBreakdown: 'Die Richtlinien (S) + müssen (Modalverb) + unverzüglich + eingehalten (Partizip II) + werden (Infinitiv).',
            literalTranslation: {
              en: 'The safety guidelines must immediately kept be.',
              fa: 'دستورالعمل‌های ایمنی باید بی‌درنگ رعایت شوند.',
              prs: 'رهنمودهای ایمنی باید بدون معطلی مراعات گردند.',
              tr: 'Güvenlik yönergelerine derhal riayet edilmelidir.',
              ar: 'يجب الالتزام بإرشادات السلامة على الفور.',
              es: 'Las directrices de seguridad deben cumplirse de inmediato.'
            },
            fluentTranslation: {
              en: 'The safety regulations must be complied with immediately.',
              fa: 'مقررات ایمنی کارگاه باید بلادرنگ و دقیق رعایت گردند.',
              prs: 'دستورالعمل‌های امنیتی باید بی‌درنگ تطبیق شوند.',
              tr: 'Güvenlik kurallarına gecikmeksizin uyulması zorunludur.',
              ar: 'يتعين الامتثال الفوري للوائح السلامة المهنية.',
              es: 'Es obligatorio acatar de inmediato las normativas de seguridad.'
            }
          }
        ]
      },
      practiceTasks: [
        'Formulieren Sie fünf Regeln für Ihren Arbeitsplatz im Passiv mit "müssen" oder "dürfen".',
        'Verwandeln Sie Aktivsätze in Passivkonstruktionen mit Modalverben im Präteritum.'
      ]
    },
    vocabularies: [
      { id: 'b2_1_v1', word: 'die Prozessoptimierung', article: 'die', plural: 'die Prozessoptimierungen', ipa: '/pʁoˈt͡sɛsʔɔptiˌmiːʁʊŋ/', translation: { en: 'process optimization', fa: 'بهینه‌سازی فرآیند', prs: 'بهبود پروسه کاری', tr: 'süreç optimizasyonu', ar: 'تحسين العمليات', es: 'optimización de procesos' } },
      { id: 'b2_1_v2', word: 'die Wertschöpfungskette', article: 'die', plural: 'die Wertschöpfungsketten', ipa: '/ˈveːɐ̯tˌʃœp͡fʊŋskɛtə/', translation: { en: 'value chain', fa: 'زنجیره ارزش', prs: 'زنجیره تولید ارزش', tr: 'değer zinciri', ar: 'سلسلة القيمة', es: 'cadena de valor' } },
      { id: 'b2_1_v3', word: 'der Fachkräftemangel', article: 'der', plural: 'die Fachkräftemängel', ipa: '/ˈfaxkʁɛftəˌmaŋl̩/', translation: { en: 'shortage of skilled workers', fa: 'کمبود نیروی متخصص', prs: 'کمبود کارمندان مسلکی', tr: 'nitelikli iş gücü açığı', ar: 'نقص الكوادر المتخصصة', es: 'escasez de mano de obra cualificada' } }
    ],
    exercises: [
      {
        id: 'ex_b2_1_1',
        type: 'multiple_choice',
        instruction: {
          en: 'Choose the correct form of the passive sentence with modal verb.',
          fa: 'فرم صحیح جمله مجهول به همراه فعل وجهی را انتخاب کنید.',
          prs: 'شکل درست جمله مجهول را با فعل کمکی انتخاب نمایید.',
          tr: 'Modal fiilli edilgen cümlenin doğru kuruluşunu belirleyin.',
          ar: 'اختر الصيغة الصحيحة للجملة المبنية للمجهول مع الفعل المساعد.',
          es: 'Selecciona la forma correcta de la oración pasiva con verbo modal.'
        },
        prompt: 'Formen Sie den Satz ins Passiv um: "Man muss die Fehlerquelle sofort analysieren."',
        options: [
          'Die Fehlerquelle muss sofort analysiert werden.',
          'Die Fehlerquelle muss werden sofort analysiert.',
          'Die Fehlerquelle wird sofort analysiert gemusst.',
          'Sofort muss analysiert die Fehlerquelle werden.'
        ],
        correctAnswer: 'Die Fehlerquelle muss sofort analysiert werden.',
        explanation: {
          en: 'Correct formula: Subject (Die Fehlerquelle) + modal (muss) + adverbial (sofort) + Partizip II (analysiert) + infinitive (werden).',
          fa: 'فرمول صحیح: فاعل (Die Fehlerquelle) + فعل مدال (muss) + قید (sofort) + اسم مفعول (analysiert) + مصدر (werden).',
          prs: 'فرمول درست: فاعل + فعل مدال + قید + صفت مفعولی + مصدر werden.',
          tr: 'Doğru formül: Özne (Die Fehlerquelle) + modal fiil (muss) + Partizip II (analysiert) + werden.',
          ar: 'المعادلة الصحيحة: نائب الفاعل + الفعل المساعد (muss) + الظرف + اسم المفعول (analysiert) + المصدر (werden).',
          es: 'Fórmula correcta: Sujeto (Die Fehlerquelle) + modal (muss) + adverbio + participio (analysiert) + infinitivo (werden).'
        }
      }
    ]
  },
  {
    id: 'b2_1_lek2',
    lektionNumber: 2,
    level: 'B2.1',
    title: 'Gesundheitswesen, Medizin und Patientenberatung',
    subTitle: 'Krankenhausalltag, Anamnese und der Konjunktiv II für Ratschläge und Hypothesen (B2)',
    topic: 'Ärztliche Konsultation, Symptombeschreibung, Patientenaufklärung und Konjunktiv II',
    fotoHoergeschichte: {
      title: 'Foto-Hörgeschichte: In der Universitätsklinik Heidelberg',
      imagePrompt: 'A modern medical consultation room at Heidelberg University Hospital where a compassionate specialist explains diagnostic test results to a patient.',
      imageTheme: 'Universitätsklinikum Heidelberg',
      audioDuration: '02:50',
      transcript: [
        { speaker: 'Dr. Al-Mansoor', text: 'Guten Tag, Herr Weber. Nehmen Sie bitte Platz. Wie geht es Ihnen heute mit den verschriebenen Medikamenten?' },
        { speaker: 'Herr Weber', text: 'Guten Tag, Herr Doktor. Die Schmerzen im Knie haben nachgelassen, aber ich verspüre gelegentlich Schwindelgefühle.' },
        { speaker: 'Dr. Al-Mansoor', text: 'An Ihrer Stelle würde ich die Dosierung am Morgen um die Hälfte reduzieren und reichlich Wasser trinken.' },
        { speaker: 'Herr Weber', text: 'Wäre eine physiotherapeutische Behandlung zusätzlich ratsam?' },
        { speaker: 'Dr. Al-Mansoor', text: 'Ja, zweifellos. Ich stelle Ihnen umgehend eine Überweisung für zehn Einheiten Krankengymnastik aus.' }
      ],
      summary: {
        en: 'A medical consultation at Heidelberg University Clinic where the doctor adjusts medication and prescribes physiotherapy using Konjunktiv II.',
        fa: 'یک جلسه ویزیت پزشکی در کلینیک دانشگاهی هایدلبرگ که در آن پزشک دوز دارو را تعدیل کرده و فیزیوتراپی تجویز می‌کند.',
        prs: 'یک جلسه معاینه طبی در شفاخانه پوهنتون هایدلبرگ که داکتر مقدار دوا را تنظیم نموده و نسخه فیزیوتراپی صادر می‌کند.',
        tr: 'Heidelberg Üniversite Kliniği\'nde doktorun ilaç dozunu ayarladığı ve fizik tedavi önerdiği muayene.',
        ar: 'استشارة طبية في مستشفى هايدلبرغ الجامعي يقوم فيها الطبيب بتعديل جرعة الدواء وتوجيه المريض للعلاج الطبيعي.',
        es: 'Consulta en el Hospital Universitario de Heidelberg donde el médico ajusta la medicación con Konjunktiv II.'
      }
    },
    sectionA: {
      title: 'Mussawi A: Sprechen & Dialog',
      focus: 'Sprechen & Hören (Das Anamnesegespräch)',
      description: {
        en: 'Describe symptoms accurately, understand medical instructions, and ask clarifying questions.',
        fa: 'توصیف دقیق علائم بیماری، درک دستورات دارویی پزشک و طرح پرسش‌های شفاف‌ساز.',
        prs: 'تشریح دقیق علایم مریضی، فهمیدن دستورالعمل‌های داکتر و پرسان کردن سوالات ضروری.',
        tr: 'Belirtileri açıkça tarif etme, tıbbi talimatları anlama ve netleştirici sorular sorma.',
        ar: 'وصف الأعراض بدقة، فهم التعليمات الطبية وطرح الأسئلة الاستيضاحية.',
        es: 'Descripción de síntomas, comprensión de indicaciones médicas y preguntas de seguimiento.'
      },
      content: 'Ich leide unter anhaltenden Kopfschmerzen. / An Ihrer Stelle würde ich einen Facharzt konsultieren.',
      audioText: 'Bei plötzlichen Beschwerden sollten Sie unverzüglich den ärztlichen Bereitschaftsdienst unter 116117 anrufen.',
      practiceTasks: [
        'Führen Sie ein simuliertes Anamnesegespräch beim Allgemeinarzt durch.',
        'Erklären Sie einem Patienten die Einnahmehinweise für ein Antibiotikum.'
      ]
    },
    sectionB: {
      title: 'Mussawi B: Wortschatz & Hören',
      focus: 'Hören & Wortschatz (Medizinische Fachterminologie & Anatomie)',
      description: {
        en: 'Vocabulary of diagnostics, organs, symptoms, and medical treatment in German clinics.',
        fa: 'واژگان تخصصی تشخیص بیماری، اندام‌ها، علائم و درمان‌های بالینی در بیمارستان‌های آلمان.',
        prs: 'اصطلاحات مسلکی تشخیص، اعضای بدن، علایم امراض و تداوی در کلینیک‌های آلمان.',
        tr: 'Alman kliniklerinde tanı, organlar, belirtiler ve tedaviye dair terminoloji.',
        ar: 'مصطلحات التشخيص، الأعضاء، الأعراض والعلاجات السريرية في المشافي الألمانية.',
        es: 'Vocabulario de diagnóstico, órganos, síntomas y tratamientos médicos.'
      },
      content: 'die Diagnose, die Nebenwirkung, die Überweisung, der Befund, die Anästhesie.',
      practiceTasks: [
        'Ordnen Sie Fachbegriffe den entsprechenden medizinischen Abteilungen zu.',
        'Formulieren Sie Beipackzettel-Warnhinweise verständlich um.'
      ]
    },
    sectionC: {
      title: 'Mussawi C: Alltagskommunikation',
      focus: 'Sprechen & Dialoge (Fachkollegiale Übergabe im Schichtdienst)',
      description: {
        en: 'Handover protocols between healthcare professionals and patient documentation.',
        fa: 'گزارش تحویل شیفت میان کادر درمان و مستندسازی پرونده بیمار.',
        prs: 'تسلیم‌دهی شیفت کاری میان داکتران و نرس‌ها و درج معلومات در دوسیه مریض.',
        tr: 'Sağlık çalışanları arasında vardiya devir teslimi ve hasta dosyası belgeleme.',
        ar: 'تسليم المناوبة بين الكوادر الطبية وتوثيق ملفات المرضى بدقة.',
        es: 'Entrega de guardia hospitalaria y documentación clínica entre profesionales.'
      },
      content: 'Frau Müller auf Station 3 zeigt stabile Vitalwerte; die Medikation wurde angepasst.',
      audioText: 'Der Patient wurde heute Morgen operiert und befindet sich nun im Aufwachraum.',
      practiceTasks: [
        'Simulieren Sie eine Schichtübergabe auf der chirurgischen Station.',
        'Verfassen Sie einen kurzen Pflegebericht über den postoperativen Verlauf.'
      ]
    },
    sectionD: {
      title: 'Mussawi D: Leseverstehen & Text',
      focus: 'Lesen & Textanalyse (Fachartikel & Aufklärungsbögen)',
      description: {
        en: 'Analyze informed consent forms and medical articles from Deutsches Ärzteblatt.',
        fa: 'تحلیل برگه‌های رضایت‌نامه درمانی و مقالات تخصصی نشریات پزشکی آلمان.',
        prs: 'خواندن و درک ورقه‌های رضایت‌نامه عملیات و مقالات ژورنال‌های طبی.',
        tr: 'Aydınlatılmış onam formlarını ve tıp dergisi makalelerini inceleme.',
        ar: 'تحليل استمارات الموافقة الطبية المستنيرة والمقالات من الدوريات الصحية.',
        es: 'Análisis de consentimientos informados y artículos de revistas médicas.'
      },
      content: 'Auszug aus einem Aufklärungsbogen zur Knieendoprothetik.',
      practiceTasks: [
        'Ermitteln Sie die im Text aufgeführten Risikofaktoren.',
        'Formulieren Sie Kontraindikationen für eine Medikamentenverabreichung.'
      ]
    },
    sectionE: {
      title: 'Mussawi E: Grammatik & Schreiben',
      focus: 'Grammatik & Schreiben (Konjunktiv II: Ratschläge & Irreale Konditionalsätze)',
      description: {
        en: 'Form polite advice, diplomatic suggestions, and unreal conditionals with "wäre", "hätte", and "würde + Infinitiv".',
        fa: 'بیان مشاوره‌های محترمانه، پیشنهادهای دیپلماتیک و جملات شرطی غیرواقعی با wäre، hätte و würde + Infinitiv.',
        prs: 'بیان توصیه‌های مودبانه و جملات شرطی فرضی با افعال کمکی Konjunktiv II.',
        tr: 'Konjunktiv II ile kibar tavsiyeler, diplomatik öneriler ve gerçek dışı şart cümleleri.',
        ar: 'تقديم النصائح اللبقة والافتراضات غير الواقعية باستخدام صيغة Konjunktiv II.',
        es: 'Consejos diplomáticos y oraciones condicionales irreales con Konjunktiv II.'
      },
      content: 'Ratschläge: "Sie sollten...", "An Ihrer Stelle würde ich...", "Es wäre ratsam, wenn...".',
      grammarRule: {
        id: 'b2_1_konjunktiv2_rule',
        level: 'B2.1',
        germanTitle: 'Der Konjunktiv II für Empfehlungen und Ratschläge',
        formula: 'Subjekt + sollte / würde + Infinitiv am Satzende',
        explanation: {
          en: 'For polite recommendations and medical advice, German speakers use the modal verb "sollten" or "würde + Infinitiv". For "sein" and "haben", use "wäre" and "hätte".',
          fa: 'برای توصیه‌های محترمانه و پزشکی، از فعل مدال "sollten" یا ترکیب "würde + مصدر" استفاده می‌شود. برای sein و haben مستقیماً از wäre و hätte بهره گرفته می‌شود.',
          prs: 'برای ارائه مشوره مودبانه، از sollten یا ترکیب würde با مصدر در آخر جمله استفاده می‌شود.',
          tr: 'Kibar tavsiyelerde "sollten" veya "würde + mastar", "sein" için "wäre", "haben" için "hätte" kullanılır.',
          ar: 'للإرشاد المهذب والنصائح الطبية يستخدم الفعل sollten أو تركيب würde مع المصدر في النهاية.',
          es: 'Para recomendaciones educadas se emplea "sollten" o "würde + infinitivo", y "wäre/hätte" para ser/tener.'
        },
        examples: [
          {
            german: 'An Ihrer Stelle würde ich vor der Einnahme noch Rücksprache mit der Kardiologin halten.',
            formulaBreakdown: 'An Ihrer Stelle + würde (K II) + ich + vor der Einnahme + Rücksprache halten (Infinitiv).',
            literalTranslation: {
              en: 'In your place would I before taking further consultation with the cardiologist hold.',
              fa: 'اگر جای شما بودم، قبل از مصرف دارو مجدداً با متخصص قلب مشورت می‌کردم.',
              prs: 'اگر من به جای شما می‌بودم، پیش از خوردن دوا با داکتر قلب مشوره می‌کردم.',
              tr: 'Sizin yerinizde olsam ilacı almadan önce kardiyologla tekrar görüşürdüm.',
              ar: 'لو كنت مكانك لاستشرت طبيبة القلب مجدداً قبل تناول الدواء.',
              es: 'En su lugar consultaría de nuevo con la cardióloga antes de la toma.'
            },
            fluentTranslation: {
              en: 'If I were you, I would consult the cardiologist again before taking this medication.',
              fa: 'پیشنهاد می‌کنم پیش از مصرف این دارو، حتماً نظر پزشک متخصص قلب را جویا شوید.',
              prs: 'بهتر است قبل از نوشیدن این دوا، یک بار دیگر با داکتر متخصص قلب صحبت نمایید.',
              tr: 'Yerinizde olsam, ilacı kullanmadan önce kardiyoloji uzmanına danışırdım.',
              ar: 'من الأفضل لو استشرت أخصائية أمراض القلب مرة أخرى قبل الشروع في تناول العلاج.',
              es: 'Le aconsejo que antes de tomar el fármaco consulte nuevamente con su cardióloga.'
            }
          }
        ]
      },
      practiceTasks: [
        'Formulieren Sie fünf medizinische Ratschläge mit "Sie sollten..." oder "Es wäre besser, wenn...".',
        'Schreiben Sie eine ärztliche Empfehlung an einen Patienten mit Bluthochdruck.'
      ]
    },
    vocabularies: [
      { id: 'b2_1_v4', word: 'die Anamnese', article: 'die', plural: 'die Anamnesen', ipa: '/anaˈmneːzə/', translation: { en: 'medical history / anamnesis', fa: 'شرح‌حال پزشکی بیمار', prs: 'تاریخچه صحی مریض', tr: 'hasta öyküsü / anamnez', ar: 'السيرة المرضية / الاستجواب الطبي', es: 'anamnesis / historial médico' } },
      { id: 'b2_1_v5', word: 'die Überweisung', article: 'die', plural: 'die Überweisungen', ipa: '/yːbɐˈvaɪ̯zʊŋ/', translation: { en: 'medical referral', fa: 'برگه ارجاع به پزشک متخصص', prs: 'برگه راجع ساختن به متخصص', tr: 'sevk belgesi', ar: 'إحالة طبية', es: 'volante de derivación médica' } },
      { id: 'b2_1_v6', word: 'die Nebenwirkung', article: 'die', plural: 'die Nebenwirkungen', ipa: '/ˈneːbn̩ˌvɪʁkʊŋ/', translation: { en: 'side effect', fa: 'عوارض جانبی دارو', prs: 'تاثیرات جانبی دوا', tr: 'yan etki', ar: 'الأثر الجانبي', es: 'efecto secundario' } }
    ],
    exercises: [
      {
        id: 'ex_b2_1_2',
        type: 'multiple_choice',
        instruction: {
          en: 'Select the polite recommendation with Konjunktiv II.',
          fa: 'توصیه محترمانه را با استفاده از Konjunktiv II انتخاب کنید.',
          prs: 'توصیه مودبانه را با ساختار Konjunktiv II برگزینید.',
          tr: 'Konjunktiv II ile ifade edilmiş kibar tavsiyeyi seçiniz.',
          ar: 'اختر النصيحة المهذبة المصوغة بأسلوب Konjunktiv II.',
          es: 'Selecciona la recomendación cortés formulada con Konjunktiv II.'
        },
        prompt: 'Welcher Satz drückt einen höflichen ärztlichen Ratschlag aus?',
        options: [
          'Sie sollten sich nach dem Eingriff mindestens drei Tage schonen.',
          'Sie müssen sich nach dem Eingriff schonen.',
          'Sie schonen sich nach dem Eingriff sofort.',
          'Schonen Sie sich gefälligst nach dem Eingriff.'
        ],
        correctAnswer: 'Sie sollten sich nach dem Eingriff mindestens drei Tage schonen.',
        explanation: {
          en: '"Sollten" expresses a considerate, professional medical recommendation without appearing overly blunt.',
          fa: 'کاربرد "sollten" توصیه‌ای مشفقانه و پزشکی را بدون حالت تحکمی و خشن منتقل می‌کند.',
          prs: 'کلمه sollten یک توصیه دلسوزانه مسلکی را به شیوه مودبانه بیان می‌کند.',
          tr: '"Sollten" yapısı emredici olmadan profesyonel bir tıbbi tavsiye sunar.',
          ar: 'يعبر الفعل sollten عن نصيحة طبية حكيمة ومهنية دون صيغة أمر جافة.',
          es: '"Sollten" modula la recomendación de forma profesional y atenta sin sonar imperativa.'
        }
      }
    ]
  },
  {
    id: 'b2_1_lek3',
    lektionNumber: 3,
    level: 'B2.1',
    title: 'Recht, Mietverträge und Verbraucherschutz',
    subTitle: 'Mietrecht, Kündigungsfristen, Nebenkostenabrechnung und Partizipialattribute (B2)',
    topic: 'Wohnungsübergabeprotokoll, Mieterverein, Klauseln in AGB und Partizip I/II',
    fotoHoergeschichte: {
      title: 'Foto-Hörgeschichte: Bei der Wohnungsübergabe in Berlin-Kreuzberg',
      imagePrompt: 'A bright Altbau apartment in Berlin where a tenant and a landlord complete an apartment handover protocol checklist.',
      imageTheme: 'Berlin Wohnungsübergabe',
      audioDuration: '02:45',
      transcript: [
        { speaker: 'Frau Neumann (Vermieterin)', text: 'Guten Tag, Herr Karimi. Hier ist das offizielle Wohnungsübergabeprotokoll. Gehen wir alle Räume gemeinsam durch?' },
        { speaker: 'Herr Karimi (Mieter)', text: 'Sehr gern. Mir ist aufgefallen, dass der im Flur angebrachte Rauchmelder defekt zu sein scheint.' },
        { speaker: 'Frau Neumann', text: 'Gut, dass Sie das ansprechen. Ich notiere das im Protokoll. Die Hausverwaltung wird den Austausch umgehend veranlassen.' },
        { speaker: 'Herr Karimi', text: 'Bis zu welchem Stichtag erhalte ich die jährliche Nebenkostenabrechnung?' },
        { speaker: 'Frau Neumann', text: 'Spätestens zwölf Monate nach Ende des jeweiligen Abrechnungszeitraums.' }
      ],
      summary: {
        en: 'A formal apartment handover in Berlin where the tenant inspects the premises and clarifies utility bill deadlines according to German tenancy law.',
        fa: 'تحویل رسمی آپارتمان در برلین که در آن مستاجر نقایص ملک را در صورت‌جلسه ثبت کرده و مهلت دریافت صورت‌حساب شارژ را جویا می‌شود.',
        prs: 'تسلیم‌گیری رسمی خانه در برلین که کرایه‌نشین موارد را در پروتوکول درج نموده و درباره مصارف بل‌های سالانه معلومات می‌گیرد.',
        tr: 'Berlin\'de kiracının teslim tutanağını doldurduğu ve aidat hesaplama sürelerini sorduğu ev teslimi.',
        ar: 'تسليم شقة رسمي في برلين يقوم فيه المستأجر بتدوين الملاحظات والاستفسار عن حساب التكاليف الإضافية.',
        es: 'Entrega formal de vivienda en Berlín con revisión de protocolo y plazos legales de gastos comunes.'
      }
    },
    sectionA: {
      title: 'Mussawi A: Sprechen & Dialog',
      focus: 'Sprechen & Hören (Wohnungsbesichtigung & Mietberatung)',
      description: {
        en: 'Negotiate tenancy agreements, contest unfair charges, and document apartment handover protocols.',
        fa: 'مذاکره قرارداد اجاره، اعتراض به هزینه‌های غیرمنصفانه و تنظیم صورت‌جلسه تحویل آپارتمان.',
        prs: 'بحث روی قرارداد کرایه خانه، اعتراض به بل‌های نادرست و خانه‌پری صورت‌جلسه تسلیمی.',
        tr: 'Kira sözleşmelerini müzakere etme, haksız giderlere itiraz ve teslim tutanağı tutma.',
        ar: 'التفاوض بشأن عقود الإيجار، الاعتراض على التكاليف غير المبررة وتوثيق محضر التسليم.',
        es: 'Negociación de contratos de arrendamiento, reclamación de gastos y actas de entrega.'
      },
      content: 'Die Kündigungsfrist beträgt drei Monate. / Wir verlangen die Beseitigung der im Protokoll vermerkten Mängel.',
      audioText: 'Laut Gesetz ist der Vermieter verpflichtet, die Kaution getrennt von seinem Privatvermögen anzulegen.',
      practiceTasks: [
        'Formulieren Sie eine schriftliche Mängelanzeige an den Vermieter.',
        'Spielen Sie ein Streitgespräch über die Rückzahlung der Mietkaution.'
      ]
    },
    sectionB: {
      title: 'Mussawi B: Wortschatz & Hören',
      focus: 'Hören & Wortschatz (Mietrecht & Vertragssprache)',
      description: {
        en: 'Legal terminology of leasing, consumer rights, security deposits, and building regulations.',
        fa: 'واژگان حقوقی اجاره، حقوق مصرف‌کننده، ودیعه مسکن و مقررات ساختمانی.',
        prs: 'لغات حقوقی قرارداد کرایه، ضمانت بانکی (Kaution) و قوانین حقوق مستاجر.',
        tr: 'Kira hukuku, tüketici hakları, depozito ve bina yönetmeliği kavramları.',
        ar: 'المصطلحات القانونية للإيجار، حقوق المستهلك، التأمين المالي ولوائح السكن.',
        es: 'Términos jurídicos de arrendamiento, fianza, derechos del inquilino y normativa.'
      },
      content: 'die Mietkaution, die Nebenkostenabrechnung, die Schönheitsreparatur, die Kündigungsfrist, die Abmahnung.',
      practiceTasks: [
        'Prüfen Sie eine Muster-Nebenkostenabrechnung auf unzulässige Posten.',
        'Verfassen Sie einen Widerspruch gegen eine unbegründete Mieterhöhung.'
      ]
    },
    sectionC: {
      title: 'Mussawi C: Alltagskommunikation',
      focus: 'Sprechen & Dialoge (Beratung beim Mieterverein)',
      description: {
        en: 'Legal consultation at a tenants association, analyzing disputed contract clauses.',
        fa: 'مشاوره حقوقی در انجمن حمایت از مستاجران و بررسی بندهای مناقشه‌برانگیز قرارداد.',
        prs: 'مشوره با اتحادیه کرایه‌نشینان (Mieterverein) در مورد فیصله بندهای پیچیده قرارداد.',
        tr: 'Kiracılar derneğinde hukuki danışmanlık alma ve tartışmalı maddeleri analiz etme.',
        ar: 'الاستشارة القانونية لدى جمعية حماية المستأجرين وتحليل بنود العقود الخلافية.',
        es: 'Asesoría en la asociación de inquilinos y análisis de cláusulas contractuales.'
      },
      content: 'Ist diese Klausel über Schönheitsreparaturen rechtlich wirksam?',
      audioText: 'Der Bundesgerichtshof hat starre Renovierungsfristen in Mietverträgen für unwirksam erklärt.',
      practiceTasks: [
        'Simulieren Sie ein Beratungsgespräch beim Mieterverein.',
        'Erläutern Sie die Rechtslage bei einer Kündigung wegen Eigenbedarfs.'
      ]
    },
    sectionD: {
      title: 'Mussawi D: Leseverstehen & Text',
      focus: 'Lesen & Textanalyse (Mietvertrag & Gerichtsurteile)',
      description: {
        en: 'Examine standard rental contracts and court rulings from the Federal Court of Justice (BGH).',
        fa: 'بررسی قراردادهای استاندارد اجاره و آرای دیوان عالی فدرال آلمان.',
        prs: 'خواندن قراردادهای ستندرد و احکام محکمه عالی فدرال آلمان (BGH).',
        tr: 'Standart kira kontratlarını ve Federal Mahkeme içtihatlarını inceleme.',
        ar: 'دراسة عقود الإيجار النموذجية وأحكام محكمة العدل الاتحادية العليا.',
        es: 'Examen de contratos de alquiler tipo y sentencias del Tribunal Supremo Federal.'
      },
      content: 'Auszug aus einem Formularmietvertrag zur Umlagefähigkeit von Betriebskosten.',
      practiceTasks: [
        'Identifizieren Sie unwirksame Formularklauseln im vorliegenden Vertrag.',
        'Ermitteln Sie die Frist zur fristlosen Kündigung bei Zahlungsverzug.'
      ]
    },
    sectionE: {
      title: 'Mussawi E: Grammatik & Schreiben',
      focus: 'Grammatik & Schreiben (Partizip I und II als Adjektive vor dem Nomen)',
      description: {
        en: 'Use Participle I (present/active) and Participle II (past/passive) with appropriate adjective endings before nouns.',
        fa: 'کاربرد صفت‌های برآمده از صفت فاعلی (Partizip I) و صفت مفعولی (Partizip II) همراه با پسوند صرف صفت.',
        prs: 'استفاده از Partizip I و Partizip II به عنوان صفت پیش از اسم با پسوندهای مناسب صرفی.',
        tr: 'Partizip I ve Partizip II yapılarının sıfat çekim ekleriyle isim önünde kullanımı.',
        ar: 'استخدام اسم الفاعل (Partizip I) واسم المفعول (Partizip II) كنعوت تسبق الأسماء مع علامات الإعراب.',
        es: 'Uso del participio I y II como adjetivos atributivos con declinación correspondiente.'
      },
      content: 'Partizip I (aktivisch/andauernd): "der steigende Mietpreis" / Partizip II (passivisch/abgeschlossen): "die bezahlte Kaution".',
      grammarRule: {
        id: 'b2_1_partizip_adjektiv',
        level: 'B2.1',
        germanTitle: 'Partizip I und II als Adjektivattribute',
        formula: 'Partizip I = Verbstamm + d + Adjektivendung | Partizip II = ge-...-t/-en + Adjektivendung',
        explanation: {
          en: 'Participle I (Infinitiv + d) expresses an active, ongoing action ("der bellende Hund"). Participle II expresses a completed or passive state ("die renovierte Wohnung"). Both take standard adjective endings.',
          fa: 'صفت فاعلی (مصدر + d) بیانگر عملی جاری و فاعلی است (مانند der steigende Mietpreis). صفت مفعولی نشان‌دهنده عملی پایان‌یافته یا مجهول است (مانند die renovierte Wohnung). هر دو از قواعد صرف صفت تبعیت می‌کنند.',
          prs: 'صفت Partizip I جریان یک کار فعال را نشان می‌دهد و Partizip II کار تکمیل‌شده یا مجهول را بیان می‌دارد.',
          tr: 'Partizip I (mastar + d) devam eden aktif bir eylemi, Partizip II ise tamamlanmış edilgen bir durumu niteler.',
          ar: 'يعبر اسم الفاعل (المصدر + d) عن حدث مستمر ونشط، بينما يعبر اسم المفعول عن حدث منجز أو مبني للمجهول.',
          es: 'El participio I expresa acción continua y activa; el participio II indica estado concluido o pasivo.'
        },
        examples: [
          {
            german: 'Die im Mietvertrag vereinbarte Kaution muss in drei gleichen Raten gezahlt werden.',
            formulaBreakdown: 'Die (Artikel) + im Mietvertrag vereinbarte (Partizip II mit Endung -e) + Kaution (Nomen).',
            literalTranslation: {
              en: 'The in lease agreed deposit must in three equal installments paid be.',
              fa: 'ودیعه توافق‌شده در قرارداد اجاره باید در سه قسط مساوی پرداخت شود.',
              prs: 'ضمانت پولی توافق‌شده در قرارداد باید در سه قسط مساوی تحویل داده شود.',
              tr: 'Kira sözleşmesinde kararlaştırılan depozito üç eşit taksitte ödenmelidir.',
              ar: 'يجب سداد مبلغ التأمين المتفق عليه في العقد على ثلاث دفعات متساوية.',
              es: 'La fianza pactada en el contrato debe abonarse en tres plazos iguales.'
            },
            fluentTranslation: {
              en: 'The rental security deposit agreed upon in the lease can be paid in three equal monthly installments.',
              fa: 'ودیعه مسکن مندرج در قرارداد اجاره می‌تواند در سه قسط مساوی پرداخت گردد.',
              prs: 'پول ضمانت خانه که در قرارداد آمده است، قابل پرداخت در سه ماه پیاپی می‌باشد.',
              tr: 'Kira kontratında belirtilen depozito tutarı üç eşit taksitte ödenebilir.',
              ar: 'يجوز دفع مبلغ الضمان المالي المحدد في العقد على ثلاثة أقساط شهرية متساوية.',
              es: 'El depósito de fianza estipulado en el contrato de alquiler puede pagarse en tres cuotas iguales.'
            }
          }
        ]
      },
      practiceTasks: [
        'Bilden Sie attributive Partizipien: "die Preise, die steigen" -> "die steigenden Preise".',
        'Verfassen Sie einen formellen Brief an den Vermieter bezüglich einer defekten Heizung.'
      ]
    },
    vocabularies: [
      { id: 'b2_1_v7', word: 'die Mietkaution', article: 'die', plural: 'die Mietkautionen', ipa: '/ˈmiːtkaʊ̯ˌt͡si̯oːn/', translation: { en: 'rental security deposit', fa: 'ودیعه اجاره خانه', prs: 'پول ضمانت کرایه خانه', tr: 'kira depozitosu', ar: 'مبلغ تأمين الإيجار', es: 'fianza de arrendamiento' } },
      { id: 'b2_1_v8', word: 'die Nebenkosten', article: 'die', plural: 'die Nebenkosten', ipa: '/ˈneːbn̩ˌkɔstn̩/', translation: { en: 'additional costs / utilities', fa: 'هزینه‌های جانبی و شارژ ساختمان', prs: 'مصارف جانبی و بل‌های آب و گاز', tr: 'yan giderler / aidat', ar: 'التكاليف الإضافية والخدمات', es: 'gastos de comunidad y suministros' } },
      { id: 'b2_1_v9', word: 'die Kündigungsfrist', article: 'die', plural: 'die Kündigungsfristen', ipa: '/ˈkʏndɪɡʊŋsˌfʁɪst/', translation: { en: 'notice period for termination', fa: 'مهلت اخطار فسخ قرارداد', prs: 'مدت اطلاع قبلی برای فسخ قرارداد', tr: 'ihbar / fesih süresi', ar: 'مهلة الإشعار بإنهاء العقد', es: 'plazo de preaviso de rescisión' } }
    ],
    exercises: [
      {
        id: 'ex_b2_1_3',
        type: 'fill_blank',
        instruction: {
          en: 'Insert the correct Participle I attribute.',
          fa: 'صفت فاعلی (Partizip I) مناسب را وارد کنید.',
          prs: 'صفت فاعلی درست را در جای خالی بنویسید.',
          tr: 'Doğru Partizip I sıfatını yerleştiriniz.',
          ar: 'ضع صيغة اسم الفاعل (Partizip I) الصحيحة في الفراغ.',
          es: 'Inserta el participio I correspondiente como adjetivo.'
        },
        prompt: 'Die ständig _____ (steigen) Mietpreise in Großstädten stellen ein großes soziales Problem dar.',
        options: ['steigenden', 'gestiegenen', 'steigende', 'steigend'],
        correctAnswer: 'steigenden',
        explanation: {
          en: 'Plural Accusative / Nominative with definite article "Die" requires weak adjective ending "-en": "die ständig steigenden Mietpreise".',
          fa: 'برای اسم جمع دارای آرتیکل معین "Die"، پسوند صفت ضعیف "-en" الزامی است: die ständig steigenden Mietpreise.',
          prs: 'برای اسم جمع با آرتیکل معین، پسوند صفت en می‌گیرد: steigenden.',
          tr: 'Belirli artikel "Die" ile çoğul durumda sıfat "-en" ekini alır: "steigenden".',
          ar: 'في صيغة الجمع مع أداة التعريف "Die" تأخذ الصفة اللاحقة "-en": "steigenden".',
          es: 'En plural con artículo determinado "Die", el adjetivo adopta la terminación débil "-en": "steigenden".'
        }
      }
    ]
  }
];
