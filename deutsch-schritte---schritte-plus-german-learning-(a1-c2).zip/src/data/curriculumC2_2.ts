import { Lesson } from '../types';

export const CURRICULUM_C2_2: Lesson[] = [
  {
    id: 'c2_2_lek8',
    lektionNumber: 8,
    level: 'C2.2',
    title: 'Forensische Rhetorik, Jurisprudenz und Konjunktiv I',
    subTitle: 'Verfassungsrechtlicher Diskurs, Gutachtenstil und indirekte Rede im Journalismus',
    topic: 'Bundesverfassungsgericht, Normenkontrolle, Konjunktiv I und forensische Beweisführung',
    fotoHoergeschichte: {
      title: 'Foto-Hörgeschichte: Die mündliche Verhandlung vor dem Bundesverfassungsgericht in Karlsruhe',
      imagePrompt: 'The majestic red-carpeted courtroom of the Federal Constitutional Court in Karlsruhe where eight judges in scarlet robes listen to a constitutional law scholar.',
      imageTheme: 'Karlsruhe Bundesverfassungsgericht',
      audioDuration: '03:30',
      transcript: [
        { speaker: 'Präsident des Senats', text: 'Wir treten ein in die mündliche Verhandlung zur Verfassungsmäßigkeit der streitgegenständlichen Sicherheitsgesetze.' },
        { speaker: 'Prof. Dr. Dr. von Althaus', text: 'Die Bundesregierung trug vor, die Maßnahmen seien zur Abwehr existenzieller Bedrohungen unumgänglich gewesen und verletzten nicht den Wesensgehalt der Grundrechte.' },
        { speaker: 'Richterin Dr. Stern', text: 'Der Beschwerdeführer macht demgegenüber geltend, der Staat greife unverhältnismäßig tief in das Fernmeldegeheimnis ein.' },
        { speaker: 'Prof. Dr. Dr. von Althaus', text: 'Gleichwohl sei zu konzedieren, dass die Vorratsdatenspeicherung ohne richterlichen Vorbehalt verfassungsrechtlich kaum Bestand haben könne.' },
        { speaker: 'Präsident des Senats', text: 'Wir werden die Vereinbarkeit der Normen mit dem Verhältnismäßigkeitsprinzip eingehend prüfen.' }
      ],
      summary: {
        en: 'A historic oral hearing before the Federal Constitutional Court in Karlsruhe showcases virtuoso legal German and the systematic deployment of Konjunktiv I for indirect speech.',
        fa: 'جلسه استماع شفاهی در دادگاه قانون اساسی فدرال در کارلسروهه، کاربست تسلط‌یافته کُنیونکتیو ۱ در نقل قول غیرمستقیم و زبان حقوقی پیشرفته را به نمایش می‌گذارد.',
        prs: 'جلسه رسمی استماع در محکمه عالی قانون اساسی آلمان در کارلسروهه با زبان حقوقی فوق‌العاده رفیع و استعمال دقیق کُنیونکتیو ۱ برای نقل قول غیرمستقیم برگزار می‌گردد.',
        tr: 'Karlsruhe\'deki Federal Anayasa Mahkemesi duruşmasında, dolaylı anlatım için Konjunktiv I ve yüksek hukuk dili kullanılır.',
        ar: 'جلسة استماع شفوية في المحكمة الدستورية العليا في كارلسروه تعرض بلاغة قانونية رفيعة وصيغة Konjunktiv I للنقل غير المباشر.',
        es: 'Audiencia ante el Tribunal Constitucional Federal en Karlsruhe que demuestra el dominio magistral del Konjunktiv I y la retórica jurídica.'
      }
    },
    sectionA: {
      title: 'Mussawi A: Sprechen & Dialog',
      focus: 'Sprechen & Hören (Forensische Beweisführung & Plädoyer)',
      description: {
        en: 'Deliver an articulate legal plea, refute counterarguments with rhetorical precision, and balance constitutional values.',
        fa: 'ارائه لایحه دفاعیه حقوقی، ابطال استدلال‌های طرف مقابل با دقت بلاغی و توزین ارزش‌های بنیادین قانون اساسی.',
        prs: 'ارائه دفاعیه حقوقی با فصاحت بلاغی عالی، رد کردن ادعاهای مقابل و استدلال بر اساس اصول قانون اساسی.',
        tr: 'Hukuki savunma yapma, retorik inceliklerle karşı argümanları çürütme ve anayasal değerleri tartma.',
        ar: 'إلقاء مرافعة قضائية بليغة، تفنيد حجج الخصوم بدقة والموازنة بين المبادئ الدستورية.',
        es: 'Presentación de alegatos jurídicos, refutación retórica y ponderación de principios constitucionales.'
      },
      content: 'Die Verhältnismäßigkeit im engeren Sinne / Der Verfassungsgrundsatz der Rechtsstaatlichkeit / Die Beweislast tragen.',
      audioText: 'Es widerspricht dem Wesenskern unseres Rechtsstaatsprinzips, Grundrechte unter dem Vorwand präventiver Gefahrenabwehr schrittweise auszuhöhlen.',
      practiceTasks: [
        'Formulieren Sie ein juristisches Plädoyer gegen einen unverhältnismäßigen Eingriff in die Privatsphäre.',
        'Wenden Sie die juristische Dreiteilung der Verhältnismäßigkeit (geeignet, erforderlich, angemessen) an.'
      ]
    },
    sectionB: {
      title: 'Mussawi B: Wortschatz & Hören',
      focus: 'Hören & Wortschatz (Verfassungsrecht & Judikative)',
      description: {
        en: 'Master sophisticated terminology of constitutional jurisdiction: proportionality test, precedence, jurisprudence, and legislative competence.',
        fa: 'تسلط بر ترمینولوژی صلاحیت‌های قانون اساسی: اصل تناسب، وحدت رویه قضایی، تفسیر هنجاری و اختیارات قانون‌گذاری.',
        prs: 'یادگیری اصطلاحات بلند حقوقی و قضایی: اصل تناسب جرم و جزا، تفسیر قانون، رویه قضایی و صلاحیت‌های پارلمان.',
        tr: 'Anayasa yargısı terimleri: ölçülülük ilkesi, içtihat, norm denetimi ve yasama yetkisi.',
        ar: 'إتقان المصطلحات الدستورية المعقدة: مبدأ التناسب، السوابق القضائية، والرقابة على دستورية القوانين.',
        es: 'Terminología jurídica de derecho constitucional: principio de proporcionalidad, jurisprudencia y control de normas.'
      },
      content: 'die Normenkontrolle, der Verhältnismäßigkeitsgrundsatz, die Judikatur, die Subsumtion, das Präjudiz.',
      audioText: 'Die ständige Rechtsprechung des Bundesverfassungsgerichts verlangt, dass jeder Grundrechtseingriff zwingend einem legitimen Zweck dienen muss.',
      practiceTasks: [
        'Subsumieren Sie einen Sachverhalt unter einen abstrakten Straftatbestand.',
        'Erläutern Sie die Funktion einer konkreten Normenkontrolle im deutschen Rechtssystem.'
      ]
    },
    sectionC: {
      title: 'Mussawi C: Alltagskommunikation',
      focus: 'Sprechen & Dialoge (Diplomatische Schlichtung & Disput)',
      description: {
        en: 'Arbitrate high-stakes international disputes, formulate binding treaties, and employ non-violent diplomatic rhetoric.',
        fa: 'داوری مناقشات بین‌المللی حساس، تنظیم معاهدات الزام‌آور و به‌کارگیری بلاغت دیپلماتیک صلح‌آمیز.',
        prs: 'حکمیت در منازعات حساس بین‌المللی، ترتیبات عهدنامه‌های حقوقی و تکلم با دیپلوماسی ظریف.',
        tr: 'Yüksek riskli uluslararası anlaşmazlıklarda arabuluculuk yapma ve diplomatik metin üretme.',
        ar: 'التحكيم في النزاعات الدولية الكبرى، صياغة المعاهدات الملزمة، واستخدام الدبلوماسية الرفيعة.',
        es: 'Arbitraje de disputas internacionales de alto nivel, tratados vinculantes y diplomacia formal.'
      },
      content: 'Einen Konsens aushandeln / Völkerrechtliche Verbindlichkeit / Unabdingbare Vertragsklauseln / Reziprozität.',
      audioText: 'Die Vertragsparteien bekräftigen ihren unerschütterlichen Willen, bestehende Differenzen ausschließlich auf friedlichem, völkerrechtskonformem Wege beizulegen.',
      practiceTasks: [
        'Leiten Sie eine diplomatische Schlichtungsverhandlung mit zwei streitenden Delegationen.',
        'Entwerfen Sie eine Präambel für eine zwischenstaatliche Kooperationsvereinbarung.'
      ]
    },
    sectionD: {
      title: 'Mussawi D: Leseverstehen & Text',
      focus: 'Lesen & Textanalyse (Verfassungsgerichtsurteile & Gesetzeskommentare)',
      description: {
        en: 'Dissect decisions of the Federal Constitutional Court featuring intricate hypotaxis, specialized terminology, and abstract argumentation.',
        fa: 'کالبدشکافی آرای دادگاه قانون اساسی فدرال با ساختارهای نحوی تودرتو (Hypotaxe)، اصطلاحات تخصصی و استدلال‌های تجریدی.',
        prs: 'تحلیل عمیق فیصله‌های قضایی محکمه قانون اساسی آلمان با جملات ترکیبی بسیار طویل و زبان حقوقی منسجم.',
        tr: 'Federal Anayasa Mahkemesi kararlarını, karmaşık yan cümle hiyerarşisini (Hypotaxe) ve soyut hukuki dili analiz etme.',
        ar: 'تحليل قرارات المحكمة الدستورية العليا ذات الجمل المركبة المتداخلة والمفاهيم التجريدية العميقة.',
        es: 'Análisis de sentencias del Tribunal Constitucional con sintaxis hipotáctica compleja y argumentación abstracta.'
      },
      content: 'Leitsatz aus einer grundlegenden Entscheidung des Bundesverfassungsgerichts.',
      readingText: {
        type: 'Urteil des Bundesverfassungsgerichts',
        title: 'BVerfG, Urteil des Ersten Senats zum Grundrecht auf Gewährleistung der Vertraulichkeit informationstechnischer Systeme',
        body: 'Das allgemeine Persönlichkeitsrecht umfasst das Grundrecht auf Gewährleistung der Vertraulichkeit und Integrität informationstechnischer Systeme, soweit der Schutz nicht durch das Fernmeldegeheimnis oder das Recht auf Unverletzlichkeit der Wohnung abgedeckt wird. Ein heimlicher Zugriff auf informationstechnische Systeme, mittels dessen die Nutzung des Systems überwacht und dessen Speichermedien ausgelesen werden können, ist verfassungsrechtlich nur dann zulässig, wenn tatsächliche Anhaltspunkte einer konkreten Gefahr für ein überragend wichtiges Rechtsgut vorliegen.'
      },
      practiceTasks: [
        'Extrahieren Sie die verfassungsrechtlichen Voraussetzungen für einen staatlichen Eingriff in IT-Systeme.',
        'Erklären Sie, was unter dem "überragend wichtigen Rechtsgut" verfassungsrechtlich zu verstehen ist.'
      ]
    },
    sectionE: {
      title: 'Mussawi E: Grammatik & Schreiben',
      focus: 'Grammatik & Schreiben (Konjunktiv I in der indirekten Rede & journalistischer Qualitätsstil)',
      description: {
        en: 'Master the systematic use of Konjunktiv I in indirect discourse to report statements with complete journalistic detachment and objectivity.',
        fa: 'تسلط کامل بر کاربرد کُنیونکتیو ۱ در نقل قول غیرمستقیم جهت گزارش بی‌طرفانه و حرفه‌ای بیانات دیگران در سبک ژورنالیستی و نگارش C2.',
        prs: 'یادگیری کامل حالت التزامی ۱ (Konjunktiv I) در نقل قول غیرمستقیم برای گزارش‌های رسمی، ژورنالیزم مسلکی و عدم جانبداری در متن.',
        tr: 'Dolaylı anlatımda Konjunktiv I kullanımı: Gazetecilikte ve resmi dilde tarafsız aktarım kuralları.',
        ar: 'إتقان صيغة Konjunktiv I في نقل الحديث غير المباشر لضمان الحياد الصحفي التام والموضوعية.',
        es: 'Uso riguroso del Konjunktiv I en el estilo indirecto para garantizar objetividad y distanciamiento periodístico.'
      },
      content: 'er habe, sie sei, es gebe, sie seien, er werde, man müsse; Ersatzformen mit Konjunktiv II bei Formengleichheit.',
      grammarRule: {
        id: 'c2_2_konjunktiv1_rule',
        level: 'C2.2',
        germanTitle: 'Konjunktiv I in der indirekten Rede (Journalismus & Berichterstattung)',
        formula: 'Verbstamm + e / est / e / en / et / en (z.B. er sage, sie habe, es sei, man wisse)',
        explanation: {
          en: 'Konjunktiv I is used in serious journalism and academic reports to indicate that the speaker is reporting someone else\'s statement without endorsing or disputing its truth. If the Konjunktiv I form is identical to the Indikativ (e.g. in 1st person singular or 3rd person plural), use Konjunktiv II or "würde" as a replacement.',
          fa: 'در روزنامه‌نگاری حرفه‌ای و متون دانشگاهی C2، از Konjunktiv I استفاده می‌شود تا نشان داده شود که سخن نقل‌شده متعلق به فرد دیگری است و نویسنده صحت آن را مستقیماً تایید یا تکذیب نمی‌کند. اگر شکل Konjunktiv I با زمان حال عادی یکسان باشد، از Konjunktiv II جایگزین استفاده می‌شود.',
          prs: 'در سبک رسمی و ژورنالیزم عالی آلمانی، برای نقل قول سخنان دیگران بدون پذیرش مسوولیت درستی آن، از Konjunktiv I کار گرفته می‌شود. در صورتی که شکل آن با شکل زمان حال یکسان باشد، از Konjunktiv II استفاده می‌گردد.',
          tr: 'C2 seviyesinde ciddi basında ve hukuki metinlerde başkasının sözünü tarafsızca aktarmak için Konjunktiv I kullanılır.',
          ar: 'تستخدم صيغة Konjunktiv I في الصحافة الرصينة لنقل تصريحات الآخرين بحياد مطلق وتجرد تام.',
          es: 'El Konjunktiv I se emplea en el periodismo culto para citar declaraciones ajenas manteniendo un distanciamiento asertivo.'
        },
        examples: [
          {
            german: 'Der Regierungssprecher erklärte, der Minister habe alle Vorwürfe entschieden zurückgewiesen.',
            formulaBreakdown: 'Der Regierungssprecher erklärte + der Minister (Subjekt) + habe (Konjunktiv I von haben) + zurückgewiesen (Partizip II).',
            literalTranslation: {
              en: 'The government-spokesperson declared, the minister have all allegations decisively rejected.',
              fa: 'سخنگوی دولت اظهار داشت که وزیر همه اتهامات را با قاطعیت رد کرده است (به نقل از وی).',
              prs: 'سخنگوی حکومت اعلام کرد که وزیر تمام اتهامات وارده را با قاطعیت رد نموده است.',
              tr: 'Hükümet sözcüsü, bakanın tüm suçlamaları kesin bir dille reddettiğini bildirdi.',
              ar: 'صرّح المتحدث باسم الحكومة بأن الوزير قد نفى جميع الاتهامات الموجهة إليه جملة وتفصيلاً.',
              es: 'El portavoz del gobierno declaró que el ministro había rechazado categóricamente todas las acusaciones.'
            },
            fluentTranslation: {
              en: 'The government spokesperson declared that the minister had decisively rejected all allegations.',
              fa: 'سخنگوی دولت اعلام کرد که به گفته وزیر، تمام اتهامات وارده به طور قاطعانه رد شده‌اند.',
              prs: 'سخنگوی دولت اظهار داشت که وزیر محترم تمامی ادعاها و اتهامات را با قاطعیت تمام بی‌اساس خوانده است.',
              tr: 'Hükümet sözcüsü, bakanın iddiaların tamamını kesin bir dille yalanladığını açıkladı.',
              ar: 'أكد الناطق باسم الحكومة أن الوزير نفى بصورة حاسمة كافة الادعاءات بحسب قوله.',
              es: 'El portavoz gubernamental indicó que el ministro rechazaba de plano cualquier imputación.'
            }
          },
          {
            german: 'Die Sachverständigen betonten, die Reformen seien alternativlos und müssten unverzüglich greifen.',
            formulaBreakdown: 'Die Sachverständigen betonten + die Reformen (S) + seien (Konj. I von sein) + alternativlos + und müssten (Konj. II als Ersatz für Konj. I) greifen.',
            literalTranslation: {
              en: 'The experts emphasized, the reforms be without-alternative and must immediately take-effect.',
              fa: 'کارشناسان تاکید کردند که اصلاحات بدون جایگزین هستند و باید بلافاصله اثرگذار شوند.',
              prs: 'متخصصین مسلکی تاکید ورزیدند که این اصلاحات یگانه راه چاره بوده و باید فوراً عملی گردند.',
              tr: 'Bilirkişiler, reformların alternatifsiz olduğunu ve derhal yürürlüğe girmesi gerektiğini vurguladılar.',
              ar: 'شدد الخبراء على أن الإصلاحات لا بديل عنها ويجب أن تؤتي ثمارها دون إبطاء.',
              es: 'Los peritos recalcaron que las reformas carecían de alternativa y debían surtir efecto de inmediato.'
            },
            fluentTranslation: {
              en: 'The experts emphasized that the reforms were without alternative and had to take effect immediately.',
              fa: 'کارشناسان اقتصادی خاطرنشان ساختند که به زعم آنان اصلاحات هیچ جایگزینی ندارد و اجرای فوری آن ضروری است.',
              prs: 'کارشناسان تصریح نمودند که به باور ایشان این ریفورم‌ها بدیل دیگری نداشته و تطبیق عاجل آنها الزامی می‌باشد.',
              tr: 'Uzmanlar, söz konusu reform paketinin zorunlu olduğunu ve bir an önce hayata geçirilmesi gerektiğini kaydettiler.',
              ar: 'أوضح الخبراء المستقلون أن حزمة الإصلاحات حتمية ولا مناص من تطبيقها الفوري.',
              es: 'Los expertos insistieron en que el paquete de reformas resultaba inaplazable y de obligada ejecución.'
            }
          }
        ]
      },
      practiceTasks: [
        'Verwandeln Sie eine direkte Politikerrede (im Indikativ) in einen objektiven Zeitungsbericht im Konjunktiv I.',
        'Wann muss der Konjunktiv I durch den Konjunktiv II ersetzt werden? Erklären Sie die Regel an einem Beispiel.'
      ]
    },
    vocabularies: [
      { id: 'c2_2_v1', word: 'das Präjudiz', article: 'das', plural: 'die Präjudizien', ipa: '/pʁɛjuˈdiːt͡s/', translation: { en: 'legal precedent', fa: 'سابقه قضایی الزام‌آور / رویه قضایی', prs: 'رویه قضایی قبلی / فیصله دارای سابقه', tr: 'hukuki emsal / içtihat', ar: 'السابقة القضائية الملزمة', es: 'precedente vinculante' } },
      { id: 'c2_2_v2', word: 'die Normenkontrolle', article: 'die', plural: 'die Normenkontrollen', ipa: '/ˈnɔʁmənkɔnˌtʁɔlə/', translation: { en: 'judicial review of legislation', fa: 'نظارت قضایی بر انطباق با قانون اساسی', prs: 'بررسی مطابقت قوانین با قانون اساسی', tr: 'norm denetimi', ar: 'الرقابة القضائية على دستورية القوانين', es: 'control de constitucionalidad' } },
      { id: 'c2_2_v3', word: 'die Subsumtion', article: 'die', plural: 'die Subsumtionen', ipa: '/zʊpzʊmˈpt͡si̯oːn/', translation: { en: 'subsumption (applying law to facts)', fa: 'تطبیق مصداق بر حکم کلی قانون', prs: 'انطباق واقعه بر حکم قانون', tr: 'hukuki niteleme / sübsümsiyon', ar: 'تكييف الوقائع وفق النص القانوني', es: 'subsunción jurídica' } },
      { id: 'c2_2_v4', word: 'die Verhältnismäßigkeit', article: 'die', plural: 'die Verhältnismäßigkeiten', ipa: '/fɛɐ̯ˈhɛltnɪsˌmɛːsɪçkaɪ̯t/', translation: { en: 'proportionality', fa: 'اصل تناسب حقوقی', prs: 'اصل تناسب قانونی', tr: 'ölçülülük ilkesi', ar: 'مبدأ التناسب الدستوري', es: 'principio de proporcionalidad' } },
      { id: 'c2_2_v5', word: 'die Judikatur', article: 'die', plural: 'die Judikaturen', ipa: '/judikaˈtuːɐ̯/', translation: { en: 'case law / judiciary rulings', fa: 'آرای قضایی / رویه دادگاه‌ها', prs: 'مجموعه فیصله‌ها و رویه‌های قضایی', tr: 'yargı içtihadı', ar: 'الاجتهاد القضائي المستقر', es: 'jurisprudencia consolidada' } }
    ],
    videoClip: {
      title: 'Mündliche Verhandlung vor dem Bundesverfassungsgericht',
      scenario: 'Verfassungsrichter in Karlsruhe verhandeln im roten Talar über die Vereinbarkeit eines Bundesgesetzes mit den Grundrechten.',
      category: 'interview',
      duration: '03:15',
      speakers: ['Präsident des Gerichts', 'Bundesbeauftragter'],
      keyPhrases: [
        'Es stehe außer Frage, dass der Eingriff verfassungsrechtlich zu rechtfertigen sei.',
        'Die Judikatur des Senats fordere eine strikte Verhältnismäßigkeitsprüfung.',
        'Der Beschwerdeführer mache geltend, in seinem Grundrecht verletzt worden zu sein.'
      ],
      germanTranscript: [
        'Präsident des Gerichts: Die mündliche Verhandlung des Ersten Senats über die Normenkontrolle ist eröffnet.',
        'Bundesbeauftragter: Hoher Senat, die Bundesregierung vertritt die Auffassung, das Gesetz sei verfassungskonform und verletze keine Grundrechte.',
        'Präsident des Gerichts: Die Prozessbevollmächtigten der Kläger wenden ein, der Eingriff in das Fernmeldegeheimnis sei unverhältnismäßig.',
        'Bundesbeauftragter: Zur Abwehr schwerer Gefahren für das Gemeinwesen sei eine zeitlich befristete Befugniserweiterung freilich unerlässlich.',
        'Präsident des Gerichts: Das Gericht wird prüfen, inwieweit die gesetzlichen Schutzvorkehrungen dem Grundsatz der Verhältnismäßigkeit genügen.'
      ],
      translatedTranscript: [
        {
          en: 'Court President: The oral hearing of the First Senate on judicial review is hereby opened.',
          fa: 'رئیس دادگاه: جلسه دادرسی شفاهی شعبه اول دادگاه قانون اساسی پیرامون انطباق مصوبه آغاز می‌شود.',
          prs: 'رییس محکمه: جلسه علنی استماعیه دیوان اول محکمه عالی قانون اساسی پیرامون مطابقت مصوبه با قانون اساسی رسماً آغاز می‌گردد.',
          tr: 'Mahkeme Başkanı: Birinci Daire\'nin norm denetimine ilişkin sözlü duruşması açılmıştır.',
          ar: 'رئيس المحكمة: تُفتتح جلسة المرافعة الشفوية للدائرة الأولى بشأن الرقابة على دستورية القوانين.',
          es: 'Presidente del Tribunal: Se abre la vista oral del Primer Senado sobre el control de constitucionalidad.'
        },
        {
          en: 'Federal Representative: Esteemed Senate, the Federal Government maintains that the law is constitutional and infringes upon no fundamental rights.',
          fa: 'نماینده دولت فدرال: قضات عالی‌مقام، دولت فدرال بر این باور است که مصوبه منطبق بر قانون اساسی بوده و حقوق اساسی را نقض نمی‌کند.',
          prs: 'نماینده حکومت فدرال: عالی‌جنابان، موقف دولت فدرال این است که این قانون مطابق قانون اساسی بوده و حقوق بنیادی اتباع را نقض نمی‌کند.',
          tr: 'Federal Temsilci: Yüce Divan, Federal Hükümet yasanın anayasaya uygun olduğu ve hiçbir temel hakkı ihlal etmediği görüşündedir.',
          ar: 'الممثل الفيدرالي: هيئة المحكمة الموقرة، تؤكد الحكومة الاتحادية أن القانون دستوري ولا ينتهك أي حقوق أساسية.',
          es: 'Representante Federal: Alto Tribunal, el Gobierno Federal sostiene que la ley es conforme a la Constitución.'
        },
        {
          en: 'Court President: The plaintiffs\' legal representatives contend that the intrusion into telecommunications secrecy is disproportionate.',
          fa: 'رئیس دادگاه: وکلای شاکیان مدعی هستند که نقض محرمانگی ارتباطات مخابراتی نامتناسب و فراتر از حد مجاز است.',
          prs: 'رییس محکمه: وکلای مدافع عارضین استدلال می‌کنند که مداخله در محرمیت مخابرات خلاف اصل تناسب و مفرط است.',
          tr: 'Mahkeme Başkanı: Davacı vekilleri, haberleşme gizliliğine yapılan müdahalenin ölçüsüz olduğunu ileri sürmektedir.',
          ar: 'رئيس المحكمة: يحتج وكلاء المدعين بأن التدخل في سرية الاتصالات السلكية واللاسلكية يتجاوز مبدأ التناسب.',
          es: 'Presidente del Tribunal: Los letrados de los demandantes objetan que la intromisión es desproporcionada.'
        },
        {
          en: 'Federal Representative: To avert grave dangers to the public interest, a temporary expansion of powers is indeed imperative.',
          fa: 'نماینده دولت فدرال: به منظور دفع خطرات وخیم از منافع عمومی، گسترش موقت اختیارات مسلماً اجتناب‌ناپذیر است.',
          prs: 'نماینده حکومت فدرال: جهت جلوگیری از خطرات شدید متوجه منافع عامه، اعطای اختیارات محدود موقت مسلماً ضروری می‌باشد.',
          tr: 'Federal Temsilci: Kamu düzenine yönelik ağır tehlikeleri önlemek amacıyla yetkilerin süreli genişletilmesi elbette elzemdir.',
          ar: 'الممثل الفيدرالي: لدرء الأخطار الجسيمة عن الصالح العام، فإن التوسيع المؤقت للصلاحيات أمر لا مناص منه حقاً.',
          es: 'Representante Federal: Para conjurar graves peligros contra el bien común, la ampliación temporal de competencias resulta sin duda imprescindible.'
        },
        {
          en: 'Court President: The court will examine the extent to which statutory safeguards satisfy the principle of proportionality.',
          fa: 'رئیس دادگاه: دادگاه بررسی خواهد کرد که تدابیر قانونی تا چه اندازه اصل تناسب را برآورده می‌سازند.',
          prs: 'رییس محکمه: محکمه بررسی همه‌جانبه خواهد نمود که تدابیر احتیاطی در قانون تا چه حد معیار تناسب را تامین می‌نماید.',
          tr: 'Mahkeme Başkanı: Mahkeme, yasal koruma önlemlerinin ölçülülük ilkesini ne ölçüde karşıladığını tetkik edecektir.',
          ar: 'رئيس المحكمة: ستفحص المحكمة مدى كفاية الضمانات القانونية لاستيفاء مبدأ التناسب الدستوري.',
          es: 'Presidente del Tribunal: El tribunal examinará en qué medida las salvaguardas legales satisfacen el principio de proporcionalidad.'
        }
      ]
    },
    examTip: {
      standard: 'C2 (Goethe-Zertifikat C2: Großes Deutsches Sprachdiplom)',
      module: 'Schreiben & Sprechen (Akademisch-professionelle Höchststufe)',
      tip: {
        en: 'At the C2 level (GDS), master the fine distinction between Konjunktiv I and Konjunktiv II. Using Konjunktiv I in reports demonstrates authoritative command of register, distancing the author from claims without taking a subjective stance.',
        fa: 'در آزمون C2 گوته، تمایز دقیق کُنیونکتیو ۱ و ۲ تعیین‌کننده نمره عالی است. استفاده از کُنیونکتیو ۱ بی‌طرفی و بلوغ فکری-نگارشی شما را نشان می‌دهد.',
        prs: 'در عالی‌ترین سطح امتحان زبان آلمانی (C2 گوته)، تسلط بر Konjunktiv I و کاربرد آن در نقل قول‌ها نشان‌دهنده کمال بلاغت و تسلط کامل شماست.',
        tr: 'C2 sınavında Konjunktiv I ve II arasındaki ince ayrımı kusursuzca uygulamak en yüksek puanı almanın anahtarıdır.',
        ar: 'في المستوى C2 يبرهن التمييز الدقيق بين صيغتي Konjunktiv I و II على التمكن اللغوي والوعي البلاغي الرفيع.',
        es: 'En el nivel C2 (GDS), el uso certero del Konjunktiv I para la distancia asertiva acredita el dominio nativo superior.'
      }
    }
  },
  {
    id: 'c2_2_lek9',
    lektionNumber: 9,
    level: 'C2.2',
    title: 'Epistemologie, Dialektik und modaler Infinitiv',
    subTitle: 'Kritische Philosophie, Erkenntnistheorie und der modale Infinitiv (scheinen / drohen / pflegen zu)',
    topic: 'Kantische Erkenntniskritik, Dialektik, modaler Infinitiv und epistemologische Begriffsanalyse',
    fotoHoergeschichte: {
      title: 'Foto-Hörgeschichte: Das internationale Philosophie-Symposion in Heidelberg',
      imagePrompt: 'The historic Old Aula of Heidelberg University where international philosophers beneath oil paintings debate dialectical epistemology and cognitive science.',
      imageTheme: 'Heidelberg Alte Aula',
      audioDuration: '03:25',
      transcript: [
        { speaker: 'Prof. Dr. Dr. h.c. Radbruch', text: 'Wir stehen vor der Frage, inwiefern empirische Erkenntnis a priori durch die kategorialen Strukturen des menschlichen Verstandes konstituiert wird.' },
        { speaker: 'Prof. Elena Rostova', text: 'Die neurowissenschaftlichen Befunde scheinen Kants transzendentale Deduktion in einem gänzlich neuen Lichte erscheinen zu lassen.' },
        { speaker: 'Prof. Dr. Dr. h.c. Radbruch', text: 'Gleichwohl droht ein solches Vorgehen den kategorialen Unterschied zwischen Genesis und Geltung einzuebnen.' },
        { speaker: 'Prof. Elena Rostova', text: 'Man pflegt zu übersehen, dass Dialektik kein starres System ist, sondern ein lebendiger Prozess immanenter Kritik.' },
        { speaker: 'Prof. Dr. Dr. h.c. Radbruch', text: 'Dies führt uns unmittelbar zur Frage nach den Grenzen menschlicher Vernunft.' }
      ],
      summary: {
        en: 'A world-class philosophical symposium in Heidelberg explores Kantian epistemology and dialectics, employing modal infinitives with "scheinen", "drohen", and "pflegen".',
        fa: 'همایش جهانی فلسفه در هایدلبرگ به شناخت‌شناسی کانت و دیالکتیک با استفاده از افعال وجهی مصدری (scheinen zu، drohen zu) می‌پردازد.',
        prs: 'سیمینار بین‌المللی فلسفه در پوهنتون هایدلبرگ موضوعات شناخت‌شناسی و دیالکتیک را با استفاده از افعال ترکیبی مصدری بسیار فاخر به بحث می‌گیرد.',
        tr: 'Heidelberg Üniversitesi\'ndeki felsefe sempozyumunda Kant\'ın bilgi teorisi modal mastar yapılarıyla (scheinen/drohen zu) tartışılır.',
        ar: 'ندوة فلسفية كبرى في جامعة هايدلبرغ تناقش نظرية المعرفة والديالكتيك باستخدام المصدر الشرطي المتقدم.',
        es: 'Simposio de filosofía en Heidelberg que explora la epistemología kantiana y la dialéctica mediante infinitivos modales complejos.'
      }
    },
    sectionA: {
      title: 'Mussawi A: Sprechen & Dialog',
      focus: 'Sprechen & Hören (Philosophischer Diskurs & Argumentationsanalyse)',
      description: {
        en: 'Deconstruct syllogisms, identify logical fallacies, and sustain high-altitude philosophical inquiry.',
        fa: 'کالبدشکافی قیاس‌های منطقی، شناسایی مغالطات و پیشبرد مباحثات عمیق فلسفی به زبان آلمانی فاخر.',
        prs: 'تحلیل قیاس‌های منطقی، افشای مغالطات کلامی و پیشبرد بحث‌های فلسفی عمیق.',
        tr: 'Kıyasları çözümleme, mantık safsatalarını tespit etme ve derin felsefi sorgulama yürütme.',
        ar: 'تفكيك الأقيسة المنطقية وكشف المغالطات وإدارة الحوارات الفلسفية التجريدية المعمقة.',
        es: 'Deconstrucción de silogismos, detección de falacias lógicas y debate filosófico de alto calado.'
      },
      content: 'Das Syllogismus / Die Antinomie / Der Zirkelschluss / A priori und A posteriori.',
      audioText: 'Wer behauptet, die Welt bestehe ausschließlich aus materiellen Teilchen, droht die konstitutive Rolle des wahrnehmenden Subjekts vollkommen auszublenden.',
      practiceTasks: [
        'Dekonstruieren Sie einen populären logischen Fehlschluss (z.B. Argumentum ad hominem).',
        'Verteidigen Sie eine erkenntnistheoretische These im akademischen Disput.'
      ]
    },
    sectionB: {
      title: 'Mussawi B: Wortschatz & Hören',
      focus: 'Hören & Wortschatz (Erkenntnistheorie & Ontologie)',
      description: {
        en: 'Vocabulary of epistemology: transcendence, immanence, category, apodictic, heuristic, and dialectic.',
        fa: 'واژگان شناخت‌شناسی و هستی‌شناسی: استعلا، درون‌ماندگاری، مقوله، ضروری و یقینی (آپودیکتیک)، اکتشافی و دیالکتیک.',
        prs: 'لغات فلسفی شناخت‌شناسی: استعلا، مقولات عقل، ضرورت منطقی، دیالکتیک و تحلیل مفاهیم تجریدی.',
        tr: 'Epistemoloji ve ontoloji söz dağarcığı: aşkınlık, içkinlik, apodiktik, sezgisel ve diyalektik.',
        ar: 'مفردات نظرية المعرفة والأنطولوجيا: التعالي، المحايثة، المقولات، والبرهان القطعي.',
        es: 'Léxico de teoría del conocimiento y ontología: trascendental, inmanente, apodíctico y heurístico.'
      },
      content: 'die Epistemologie, die Immanenz, die Transzendenz, das Apodiktische, die Antinomie, die Heuristik.',
      audioText: 'Kants Einsicht, dass Gedanken ohne Inhalt blind und Anschauungen ohne Begriffe leer sind, bildet den Ausgangspunkt der modernen Kritischen Theorie.',
      practiceTasks: [
        'Erläutern Sie Kants Unterscheidung zwischen "a priori" und "a posteriori" Urteilen.',
        'Verfassen Sie eine Abhandlung über den Begriff der "Dialektik" bei Hegel.'
      ]
    },
    sectionC: {
      title: 'Mussawi C: Alltagskommunikation',
      focus: 'Sprechen & Dialoge (Dialektische Synthese & sokratischer Dialog)',
      description: {
        en: 'Practice the Socratic method, lead interlocutors to uncover inherent contradictions, and synthesize theses.',
        fa: 'تمرین روش سقراطی (مامایی اندیشه)، هدایت مخاطب به کشف تناقضات درونی و دستیابی به سنتز دیالکتیکی.',
        prs: 'تمرین شیوه سقراطی در گفتگو، آشکار ساختن تناقضات استدلال و رسیدن به نتیجه منطقی جامع.',
        tr: 'Sokratik yöntemi uygulama, muhatabın çelişkilerini keşfetmesini sağlama ve sentez oluşturma.',
        ar: 'ممارسة المنهج السقراطي وتوجيه المحاورين لكشف التناقضات والوصول إلى تركيب تركيبي ناضج.',
        es: 'Práctica del método socrático, mayéutica y síntesis dialéctica de postulados contrarios.'
      },
      content: 'These, Antithese, Synthese / Widerspruch / Sokratische Ironie / Maieutik.',
      audioText: 'Wenn wir Ihre Ausgangsthese bis zur letzten Konsequenz durchdenken, gelangen wir unausweichlich zu einer Antinomie, die sich nur dialektisch aufheben lässt.',
      practiceTasks: [
        'Führen Sie einen sokratischen Dialog über das Wesen der Gerechtigkeit.',
        'Formulieren Sie zu einer These eine fundierte Antithese und führen Sie beide in einer Synthese zusammen.'
      ]
    },
    sectionD: {
      title: 'Mussawi D: Leseverstehen & Text',
      focus: 'Lesen & Textanalyse (Klassischer philosophischer Text)',
      description: {
        en: 'Analyze canonical texts from German philosophy (Kant, Hegel, Adorno) with syntactic mastery and contextual depth.',
        fa: 'تحلیل متون بنیادین فلسفه آلمان (کانت، هگل، آدورنو) با تسلط کامل بر هیرارشی دستوری و لایه‌های معنایی.',
        prs: 'خواندن و درک عمیق متون فیلسوفان بزرگ آلمانی با جملات طولانی و مفاهیم سنگین فکری.',
        tr: 'Alman felsefesinin başyapıtlarını (Kant, Hegel, Adorno) dilbilgisel ve kavramsal derinliğiyle okuma.',
        ar: 'تحليل أمهات النصوص الفلسفية الألمانية بمفرداتها الجزلة وتراكيبها اللغوية الفريدة.',
        es: 'Lectura comentada de textos canónicos del pensamiento alemán con rigor filológico y conceptual.'
      },
      content: 'Auszug aus Theodor W. Adornos "Negative Dialektik".',
      readingText: {
        type: 'Philosophische Abhandlung',
        title: 'Theodor W. Adorno: Aus der Einleitung zur Negativen Dialektik',
        body: 'Philosophie, die einmal überholt schien, erhält sich am Leben, weil der Augenblick ihrer Verwirklichung versäumt ward. Das blöde Urteil, das sie für abgetan erklärt, wird zum Komplizen der Realität, die das Versprechen nicht einlöste. Kraft des Gedankens, der sich nicht mit dem Vorfindlichen abfindet, bleibt Philosophie dem Nichtidentischen verpflichtet. Sie weigert sich, das Daseiende als das Vernünftige zu glorifizieren, und beharrt auf der unversöhnten Differenz von Begriff und Sache.'
      },
      practiceTasks: [
        'Interpretieren Sie Adornos These: "Philosophie erhält sich am Leben, weil der Augenblick ihrer Verwirklichung versäumt ward".',
        'Was versteht Adorno unter dem "Nichtidentischen"?'
      ]
    },
    sectionE: {
      title: 'Mussawi E: Grammatik & Schreiben',
      focus: 'Grammatik & Schreiben (Der modale Infinitiv: scheinen / drohen / versprechen / pflegen zu + Infinitiv)',
      description: {
        en: 'Master modal infinitive constructions that express nuanced epistemic modalities and probability.',
        fa: 'تسلط بر ساختارهای مصدری وجهی با scheinen zu (به نظر رسیدن)، drohen zu (در معرض خطر بودن)، و pflegen zu (عادت داشتن/معمول بودن).',
        prs: 'یادگیری افعال مصدری وجهی (scheinen zu، drohen zu، pflegen zu) برای ابراز احتمالات و ظرافت‌های معنایی سطح C2.',
        tr: 'Modal mastar yapıları: scheinen/drohen/pflegen zu + mastar ile olasılık ve üslup inceliği.',
        ar: 'إتقان صيغ المصدر الشرطي بأفعال مثل scheinen و drohen لإضفاء أقصى درجات الدقة على الكلام.',
        es: 'Dominio de infinitivos modales con "scheinen", "drohen" y "pflegen" para expresar modalidades epistémicas sutiles.'
      },
      content: '"Er scheint zu schlafen" (= Er schläft anscheinend) / "Das Projekt droht zu scheitern" (= Es besteht akute Gefahr).',
      grammarRule: {
        id: 'c2_2_modaler_infinitiv_rule',
        level: 'C2.2',
        germanTitle: 'Der modale Infinitiv (scheinen, drohen, versprechen, pflegen zu)',
        formula: 'Subjekt + konjugiertes Verb (scheint / droht / pflegt) + ... + zu + Infinitiv (Satzende)',
        explanation: {
          en: 'Modal infinitive constructions function as subjective stance markers. "Scheinen zu" expresses an apparent impression; "drohen zu" signals an imminent negative outcome; "pflegen zu" expresses an established intellectual or cultural habit.',
          fa: 'افعال شبه‌وجهی با zu + مصدر برای نشان دادن موضع ذهنی و ارزیابی گوینده استفاده می‌شوند: scheinen zu بیانگر ظاهر قضیه است؛ drohen zu خطری قریب‌الوقوع را هشدار می‌دهد؛ pflegen zu یک سنت، روال معمول یا عادت را بازگو می‌کند.',
          prs: 'این ساختار برای بیان احتمالات و قضاوت ذهنی به کار می‌رود: scheinen zu یعنی به نظر می‌رسد، drohen zu یعنی در معرض خطر رخ دادن امری ناگوار بودن، و pflegen zu یعنی معمول داشتن یا رسم بودن کاری.',
          tr: 'C2 düzeyinde öznel değerlendirme için kullanılır: scheinen zu (öyle görünmek), drohen zu (olumsuz bir ihtimalin yaklaşması), pflegen zu (adet edinmek).',
          ar: 'تراكيب مصدرية وظيفية تعبر عن الظن والترجيح: scheinen (يبدو أنه)، drohen (يُخشى أن / يهدد بـ)، pflegen (دأب على).',
          es: 'Infinitivos modales de distanciamiento epistémico: "scheinen zu" (parecer), "drohen zu" (amenazar con) y "pflegen zu" (acostumbrar a).'
        },
        examples: [
          {
            german: 'Die empirischen Befunde scheinen die theoretische Annahme vollends zu bestätigen.',
            formulaBreakdown: 'Die empirischen Befunde (Subjekt) + scheinen (V1) + die Annahme + zu bestätigen (zu + Infinitiv).',
            literalTranslation: {
              en: 'The empirical findings seem the theoretical assumption completely to confirm.',
              fa: 'یافته‌های تجربی به نظر می‌رسد که فرض نظری را به طور کامل تایید می‌کنند.',
              prs: 'شواهد و ارقام تجربی طوری به نظر می‌رسند که ادعای تیوریک را کاملاً تایید می‌نمایند.',
              tr: 'Deneysel bulgular teorik varsayımı tamamen doğrular gibi görünmektedir.',
              ar: 'يبدو أن النتائج التجريبية تؤكد تماماً الفرضية النظرية.',
              es: 'Los hallazgos empíricos parecen corroborar plenamente el postulado teórico.'
            },
            fluentTranslation: {
              en: 'The empirical findings appear to confirm the theoretical hypothesis in its entirety.',
              fa: 'داده‌های پژوهش‌های تجربی ظاهراً فرضیه تئوریک را به طور همه‌جانبه به اثبات می‌رسانند.',
              prs: 'معلومات به دست آمده از تحقیق عملاً فرضیه علمی را به گونه جامع تایید و ثابت می‌نماید.',
              tr: 'Empirik veriler teorik hipotezi bütünüyle doğrular niteliktedir.',
              ar: 'تُظهر الشواهد التجريبية تأكيداً قاطعاً للفرضية العلمية المطروحة.',
              es: 'Los datos empíricos apuntan a una ratificación cabal de la hipótesis de partida.'
            }
          },
          {
            german: 'Durch die geopolitische Eskalation droht das globale Finanzsystem zu kollabieren.',
            formulaBreakdown: 'Durch die Eskalation + droht (V1 drohen) + das Finanzsystem (S) + zu kollabieren (zu + Infinitiv).',
            literalTranslation: {
              en: 'Through the geopolitical escalation threatens the global financial-system to collapse.',
              fa: 'در اثر تشدید بحران ژئوپلیتیک، سیستم مالی جهانی در معرض فروپاشی قرار گرفته است.',
              prs: 'به سبب بحران جغرافیای سیاسی، نظام پولی جهانی در معرض خطر سقوط قرار دارد.',
              tr: 'Jeopolitik gerilim nedeniyle küresel finans sistemi çökme tehlikesiyle karşı karşıyadır.',
              ar: 'بسبب التصعيد الجيوسياسي، يوشك النظام المالي العالمي على الانهيار.',
              es: 'Debido a la escalada geopolítica, el sistema financiero global amenaza con colapsar.'
            },
            fluentTranslation: {
              en: 'As a result of geopolitical escalation, the global financial system is in imminent danger of collapse.',
              fa: 'به دنبال بالا گرفتن تنش‌های ژئوپلیتیک، ساختار مالی بین‌المللی با خطر جدی فروپاشی مواجه شده است.',
              prs: 'در پی افزایش تنش‌های منطقوی و جهانی، نظام مالی جهان با خطر سقوط روبه‌رو گردیده است.',
              tr: 'Jeopolitik tırmanış sebebiyle küresel finansal düzenin çöküş tehlikesi kapıdadır.',
              ar: 'تُنذر الأزمة الجيوسياسية المتصاعدة بانهيار وشيك للمنظومة المالية العالمية.',
              es: 'La intensificación del conflicto geopolítico pone al sistema financiero internacional al borde del abismo.'
            }
          }
        ]
      },
      practiceTasks: [
        'Formulieren Sie eine wissenschaftliche Vermutung mit "scheinen + zu + Infinitiv".',
        'Beschreiben Sie eine drohende Klimakatastrophe mit "drohen + zu + Infinitiv".'
      ]
    },
    vocabularies: [
      { id: 'c2_2_v6', word: 'die Antinomie', article: 'die', plural: 'die Antinomien', ipa: '/antinoˈmiː/', translation: { en: 'antinomy / paradox of reason', fa: 'تناقض غیرقابل حل در عقل محض (آنتی‌نومی)', prs: 'تناقض لاینحل عقلی', tr: 'antinomi / çatışkı', ar: 'التناقض العقلي المستعصي / الأنتينوميا', es: 'antinomia' } },
      { id: 'c2_2_v7', word: 'die Immanenz', article: 'die', plural: 'die Immanenzen', ipa: '/ɪmaˈnɛnt͡s/', translation: { en: 'immanence', fa: 'درون‌ماندگاری / حلول در جهان محسوس', prs: 'درون‌ذاتی بودن / پیوستگی به جهان', tr: 'içkinlik', ar: 'المحايثة / الحضور الداخلي', es: 'inmanencia' } },
      { id: 'c2_2_v8', word: 'das Axiom', article: 'das', plural: 'die Axiome', ipa: '/aˈksi̯oːm/', translation: { en: 'axiom', fa: 'بدیهی اولی / اصل موضوعه', prs: 'اصل بدیهی و اثبات‌ناپذیر', tr: 'belit / aksiyom', ar: 'البديهية الأولية / الأصل الموضوع', es: 'axioma' } },
      { id: 'c2_2_v9', word: 'die Deduktion', article: 'die', plural: 'die Deduktionen', ipa: '/dedʊkˈtsi̯oːn/', translation: { en: 'deduction', fa: 'استنتاج قیاسی (از کل به جزء)', prs: 'استدلال قیاسی و منطقی', tr: 'tümdengelim', ar: 'الاستدلال الاستنباطي', es: 'deducción lógica' } },
      { id: 'c2_2_v10', word: 'die Heuristik', article: 'die', plural: 'die Heuristiken', ipa: '/hɔɪ̯ˈʁɪstɪk/', translation: { en: 'heuristics', fa: 'روش اکتشافی و حل مسئله', prs: 'شیوه رهیابی و کشف راه حل', tr: 'sezgisel yöntem / buluşçuluk', ar: 'الاستدلال الاستكشافي / الهيورستيك', es: 'heurística' } }
    ],
    videoClip: {
      title: 'Philosophisches Quartett: Epistemologie und Realitätskonstruktion',
      scenario: 'Philosophen und Neurowissenschaftler debattieren über den ontologischen Status des menschlichen Bewusstseins.',
      category: 'interview',
      duration: '03:20',
      speakers: ['Diskussionsleiterin', 'Philosoph'],
      keyPhrases: [
        'Die Sinneswahrnehmung scheint die Realität lediglich zu rekonstruieren.',
        'Freilich bedarf jedes epistemologische Axiom kritischer Prüfung.',
        'Gewissermaßen konstruiert das Gehirn seine eigene Phänomenologie.'
      ],
      germanTranscript: [
        'Diskussionsleiterin: Herr Kollege, scheint die neurowissenschaftliche Forschung die traditionelle Philosophie des Geistes zu widerlegen?',
        'Philosoph: Mitnichten. Die empirischen Befunde scheinen vielmehr zu bestätigen, dass unser kognitiver Apparat Wirklichkeit aktiv konstituiert.',
        'Diskussionsleiterin: Gilt dies freilich auch für logische Axiome und mathematische Wahrheiten?',
        'Philosoph: Hier berühren wir die Grenze des Empirismus: Gewisse Grundkategorien des Denkens scheinen a priori vorgegeben zu sein.',
        'Diskussionsleiterin: Eine faszinierende Denkfigur, die Kant bereits in der Kritik der reinen Vernunft meisterhaft antizipierte.'
      ],
      translatedTranscript: [
        {
          en: 'Host: Colleague, does neuroscience research seem to refute traditional philosophy of mind?',
          fa: 'مدیر نشست: همکار گرامی، آیا پژوهش‌های علوم اعصاب فلسفه سنتی ذهن را باطل می‌نمایند؟',
          prs: 'گرداننده مباحثه: همکار محترم، آیا تحقیقات جدید علوم عصبی نظریات فلسفه سنتی عقل و روان را نقض می‌نماید؟',
          tr: 'Moderatör: Değerli meslektaşım, sinirbilimsel araştırmalar geleneksel zihin felsefesini çürütüyor gibi mi görünüyor?',
          ar: 'مديرة الحوار: زميلي الفاضل، هل تبدو أبحاث علم الأعصاب داحضة لفلسفة العقل الكلاسيكية؟',
          es: 'Moderadora: Estimado colega, ¿parecen las neurociencias refutar la filosofía tradicional de la mente?'
        },
        {
          en: 'Philosopher: By no means. Empirical findings rather seem to corroborate that our cognitive apparatus actively constitutes reality.',
          fa: 'فیلسوف: ابداً. بلکه شواهد تجربی به نظر می‌رسد اثبات می‌کنند دستگاه شناختی ما فعالانه واقعیت را می‌سازد.',
          prs: 'فیلسوف: هرگز نی. یافته‌های تجربی بالعکس نشان می‌دهند که دستگاه شناخت انسان واقعیت را فعالانه بازآفرینی می‌کند.',
          tr: 'Filozof: Kesinlikle hayır. Ampirik bulgular bilişsel aygıtımızın gerçekliği aktif olarak inşa ettiğini doğrular görünmektedir.',
          ar: 'الفيلسوف: كلا على الإطلاق. بل يبدو أن الشواهد التجريبية تؤكد أن جهازنا الإدراكي يركب الواقع بفاعلية.',
          es: 'Filósofo: De ningún modo. Los hallazgos empíricos parecen corroborar que nuestro aparato cognitivo constituye activamente la realidad.'
        },
        {
          en: 'Host: Does this admittedly also apply to logical axioms and mathematical truths?',
          fa: 'مدیر نشست: آیا این امر البته شامل اصول موضوعه منطقی و حقایق ریاضیاتی نیز می‌شود؟',
          prs: 'گرداننده مباحثه: آیا این وضعیت البته درباره اصول موضوعه منطق و حقایق ریاضیات هم صدق می‌کند؟',
          tr: 'Moderatör: Bu durum kuşkusuz mantıksal aksiyomlar ve matematiksel doğrular için de geçerli midir?',
          ar: 'مديرة الحوار: وهل ينطبق هذا بطبيعة الحال على البديهيات المنطقية والحقائق الرياضية؟',
          es: 'Moderadora: ¿Es esto aplicable también a los axiomas lógicos y verdades matemáticas?'
        },
        {
          en: 'Philosopher: Here we touch the boundary of empiricism: certain fundamental categories of thought seem to be given a priori.',
          fa: 'فیلسوف: اینجا مرز تجربه‌گرایی است: برخی مقولات بنیادین تفکر به نظر می‌رسد پیشینی (a priori) باشند.',
          prs: 'فیلسوف: اینجا به سرحد علم تجربی می‌رسیم: برخی از مفاهیم و مقولات اساسی عقل به صورت پیشینی (a priori) در ذات انسان موجود معلوم می‌شوند.',
          tr: 'Filozof: Burada ampirizmin sınırına ulaşıyoruz: Düşüncenin kimi temel kategorileri a priori verilmiş gibi görünmektedir.',
          ar: 'الفيلسوف: هنا نلامس تخوم المذهب التجريبي: فثمة مقولات تفكير أساسية تبدو معطاة بصورة قبلية مسبقة.',
          es: 'Filósofo: Aquí rozamos los límites del empirismo: ciertas categorías fundamentales del pensar parecen dadas a priori.'
        },
        {
          en: 'Host: A fascinating thought construct that Kant already masterfully anticipated in the Critique of Pure Reason.',
          fa: 'مدیر نشست: تفکری شگفت‌انگیز که کانت قبلاً در نقد عقل محض به استادی آن را پیش‌بینی کرده بود.',
          prs: 'گرداننده مباحثه: یک تفکر بسیار ژرف که ایمانوئل کانت قبلاً در کتاب سنجش خرد ناب به استادی پیش‌بینی کرده بود.',
          tr: 'Moderatör: Kant\'ın Saf Aklın Eleştirisi\'nde zaten ustalıkla öngördüğü büyüleyici bir düşünce yapısı.',
          ar: 'مديرة الحوار: بناء فكري ساحر استشرفه كانط ببراعة فائقة في نقد العقل الخالص.',
          es: 'Moderadora: Una construcción teórica fascinante que Kant ya anticipó magistralmente en la Crítica de la razón pura.'
        }
      ]
    },
    examTip: {
      standard: 'C2 (Goethe-Zertifikat C2: GDS)',
      module: 'Mündliche Prüfung (Vortrag & Fachgespräch)',
      tip: {
        en: 'In the C2 monologue and discussion, avoid blunt assertions. Employing "scheinen... zu" and modal particles ("freilich", "wohl", "ja", "gewissermaßen") demonstrates the sophisticated epistemological humility characteristic of cultivated German intellect.',
        fa: 'در آزمون شفاهی C2 از اظهارنظرهای قاطعانه و صفر و صدی بپرهیزید. استفاده از "scheinen zu" و حروف قیدی ظریف (مانند gewissermaßen یا freilich) نشانه پختگی زبانی و فکری شماست.',
        prs: 'در بخش صحبت امتحان C2 هرگز احکام مطلق ندهید. به کار بردن scheinen zu و کلمات ادبی مانند gewissermaßen یا freilich نشان‌دهنده عمق تفکر و ادب اکادمیک شماست.',
        tr: 'C2 sözlü sınavında kesin yargılar yerine "scheinen zu" ve modal edatlar kullanarak incelikli bir entelektüel üslup yakalayın.',
        ar: 'في العرض الشفوي لمستوى C2 تجنب الأحكام القاطعة واستخدم أدوات الترجيح لإظهار الرصانة الفكرية واللغوية.',
        es: 'En el examen oral de C2, la prudencia argumentativa mediante "scheinen... zu" y partículas modales es señal de maestría.'
      }
    }
  },
  {
    id: 'c2_2_lek10',
    lektionNumber: 10,
    level: 'C2.2',
    title: 'Virtuoser Stil, Sprachästhetik und Gerundiva',
    subTitle: 'Literarische Ästhetik, sprachliche Nuancierung und prädikative Gerundiva (die zu lösenden Aufgaben)',
    topic: 'Stilistik, Hermeneutik, Sprachkritik und Gerundivkonstruktionen im höchsten Register',
    fotoHoergeschichte: {
      title: 'Foto-Hörgeschichte: Die Verleihung des Georg-Büchner-Preises in Darmstadt',
      imagePrompt: 'The Darmstadt theater hall during the prestigious Georg Büchner Prize literature ceremony where laureates and critics discuss modern prose aesthetics.',
      imageTheme: 'Darmstadt Büchner-Preis',
      audioDuration: '03:40',
      transcript: [
        { speaker: 'Laudatorin', text: 'Wir ehren heute eine Schriftstellerin, deren Werk durch eine unvergleichliche stilistische Brillanz besticht.' },
        { speaker: 'Preisträgerin', text: 'Sprache ist für mich kein bloßes Transportmittel für vorgefertigte Gedanken, sondern der Resonanzraum des Unsagbaren.' },
        { speaker: 'Laudatorin', text: 'Die von ihr zu bewältigenden ästhetischen Herausforderungen führten zu einer vollkommenen Erneuerung des literarischen Satzbaus.' },
        { speaker: 'Preisträgerin', text: 'In einer Zeit grassierender Verflachung der Kommunikation sind die feinen Nuancen des Wortes um jeden Preis zu verteidigen.' },
        { speaker: 'Laudatorin', text: 'Mit diesem Bekenntnis zur Sprachschönheit überreichen wir Ihnen den Georg-Büchner-Preis.' }
      ],
      summary: {
        en: 'The prestigious Georg Büchner Prize ceremony in Darmstadt celebrates the artistic zenith of German prose and poetry, illustrating gerundive constructions (die zu bewältigenden Herausforderungen).',
        fa: 'مراسم اهدای معتبرترین جایزه ادبی آلمان (گئورگ بوشنر) در دارمشتات، اوج زیبایی‌شناسی زبان آلمانی و ساختار گروندیو پیشرفته را نشان می‌دهد.',
        prs: 'محفل تفویض عالی‌ترین جایزه ادبی آلمان در دارمشتات با بیانات بی‌نهایت ادیبانه و استعمال ساختارهای ویژه گروندیو (Gerundivum) برگزار می‌شود.',
        tr: 'Darmstadt\'taki prestijli Georg Büchner Edebiyat Ödülü töreninde üslup zarafeti ve Gerundivum yapıları sergilenir.',
        ar: 'حفل تسليم جائزة غيورغ بوشنر الأدبية في دارمشتات يعكس قمة البلاغة اللغوية والتراكيب الصرفية المعقدة.',
        es: 'La ceremonia del Premio Georg Büchner en Darmstadt rinde homenaje a la estética prosística y las construcciones de gerundivo pasivo.'
      }
    },
    sectionA: {
      title: 'Mussawi A: Sprechen & Dialog',
      focus: 'Sprechen & Hören (Literarische Ästhetik & Laudatio)',
      description: {
        en: 'Deliver an eloquent eulogy (Laudatio), analyze poetic meters, cadence, and aesthetic word choice.',
        fa: 'ایراد خطابه ستایش‌آمیز ادبی (لائوداتیو)، تحلیل وزن‌های عروضی، آهنگ کلام و واژه‌گزینی هنرمندانه.',
        prs: 'ایراد سخنرانی با شکوه ادبی، تحلیل وزن و موسیقی کلام در زبان آلمانی و کاربرد واژگان فاخر.',
        tr: 'Kutlama ve övgü konuşması (Laudatio) yapma, edebi ahenk ve estetik sözcük seçimi.',
        ar: 'إلقاء خطاب الثناء الأدبي الرفيع وتحليل الإيقاع البلاغي والجماليات النصية.',
        es: 'Pronunciación de panegíricos y discursos de homenaje con cadencia estilística y recursos poéticos.'
      },
      content: 'Die Laudatio / Die Sprachgewalt / Das Sprachgefühl / Die Polysemie / Der Wohlklang (Euphemismus).',
      audioText: 'Es zeugt von wahrer Meisterschaft, dem Unaussprechlichen durch die präzise Fügung des Wortes eine sinnlich erfahrbare Gestalt zu verleihen.',
      practiceTasks: [
        'Verfassen und tragen Sie eine zweiminütige feierliche Lobrede (Laudatio) auf einen Schriftsteller vor.',
        'Analysieren Sie den rhythmischen Satzbau einer ausgewählten literarischen Passage.'
      ]
    },
    sectionB: {
      title: 'Mussawi B: Wortschatz & Hören',
      focus: 'Hören & Wortschatz (Stilistik & Poetik)',
      description: {
        en: 'Master terminology of rhetoric: alliteration, chiasmus, oxymoron, hendiadys, hyperbaton, and zeugma.',
        fa: 'تسلط بر آرایه‌های ادبی زبان آلمانی: جناس آوایی، ترتیبات متقاطع (Chiasmus)، متناقض‌نما (Oxymoron)، و زئوگما.',
        prs: 'یادگیری آرایه‌های بدیعی و ادبی در زبان آلمانی: جناس، صنعت تضاد، تناسب لفظی و تصویرسازی شعری.',
        tr: 'Retorik sanatları sözlüğü: aliterasyon, kiazmus, oksimoron, zeugma ve hiperbaton.',
        ar: 'مفردات البلاغة وعلم البيان: الجناس، الطباق، المقابلة، التضمين والإيجاز.',
        es: 'Figuras retóricas y estilísticas avanzadas: aliteración, quiasmo, oxímoron y zeugma.'
      },
      content: 'das Oxymoron, der Chiasmus, das Zeugma, die Alliteration, das Hyperbaton, die Metonymie.',
      audioText: 'Das Oxymoron verbindet zwei einander scheinbar ausschließende Begriffe zu einer pointierten, neue Bedeutungshorizonte eröffnenden Einheit.',
      practiceTasks: [
        'Identifizieren Sie in drei Gedichtzeilen die rhetorischen Stilfiguren.',
        'Wenden Sie einen Chiasmus in einer eigenen philosophischen Sentenz an.'
      ]
    },
    sectionC: {
      title: 'Mussawi C: Alltagskommunikation',
      focus: 'Sprechen & Dialoge (Sprachkritik & Kulturpessimismus)',
      description: {
        en: 'Debate the evolution of language, Anglicisms, gender-neutral forms, and digital brevity versus linguistic depth.',
        fa: 'مناظره پیرامون دگرگونی زبان، ورود واژگان بیگانه، نگارش فراگیر جنسیتی و تقابل فشردگی دیجیتال با عمق زبانی.',
        prs: 'مباحثه درباره تحول زبان، تاثیرات لغات خارجی و نگهداری از غنا و اصالت ادبی زبان در عصر مدرن.',
        tr: 'Dilin evrimi, yabancı sözcükler, cinsiyetsiz dil tartışmaları ve dijital iletişimin dile etkisi.',
        ar: 'الجدل حول تطور اللغة وتأثير الرقمنة والاقتراض اللغوي على فصاحة التعبير وأصالته.',
        es: 'Debate sobre la evolución lingüística, anglicismos y la tensión entre síntesis digital y riqueza expresiva.'
      },
      content: 'Der Sprachwandel / Das Sprachgefühl / Der Purismus / Sprachverfall versus Sprachdynamik.',
      audioText: 'Ob wir den rezenten Wandel als bedauerlichen Sprachverfall beklagen oder als vitale Anpassung an die Beschleunigung der Moderne begreifen, berührt das Selbstverständnis einer Kulturnation.',
      practiceTasks: [
        'Verteidigen Sie die These, dass Sprache ein lebendiger, sich unaufhörlich wandelnder Organismus ist.',
        'Kritisieren Sie die Verarmung des Wortschatzes durch digitale Kurznachrichten.'
      ]
    },
    sectionD: {
      title: 'Mussawi D: Leseverstehen & Text',
      focus: 'Lesen & Textanalyse (Literarische Meisterprosa)',
      description: {
        en: 'Analyze virtuosic German prose (Thomas Mann, Franz Kafka, Ingeborg Bachmann) with microscopic attention to cadence, syntax, and atmosphere.',
        fa: 'تحلیل نثر فاخر و شاهکارهای ادبی آلمانی (توماس مان، فرانتس کافکا، اینگه‌بورگ باخمان) با دقت میکروسکوپی به ریتم و جو داستان.',
        prs: 'خواندن و تحلیل ادبیات اصیل و شاهکارهای نثر آلمانی با توجه دقیق به آهنگ جملات و زیبایی تصاویر.',
        tr: 'Klasik Alman edebiyatı başyapıtlarını (Thomas Mann, Kafka, Bachmann) mikroskobik üslup tahliliyle okuma.',
        ar: 'تحليل عيون النثر الألماني الرفيع (توماس مان، كافكا) بتركيز فائق على النغم والجو الشعوري.',
        es: 'Análisis filológico y estilístico de obras cumbres de la literatura alemana (Mann, Kafka, Bachmann).'
      },
      content: 'Auszug aus Thomas Manns Meistererzählung.',
      readingText: {
        type: 'Literarische Novelle',
        title: 'Thomas Mann: Der Tod in Venedig (Auszug)',
        body: 'Denn die Schönheit, mein Phaidros, die Schönheit allein ist lieblich und sichtbar zugleich: sie ist, merke das wohl! die einzige Gestalt des Geistigen, welche wir sinnlich empfangen, sinnlich ertragen können. Oder was würde aus uns, wenn das Göttliche sonst, wenn Vernunft und Tugend und Wahrheit uns sinnlich erschienen? Würden wir nicht vergehen und verbrennen vor Liebe, wie Semele einstmals vor dem Zeugnis des Zeus? So ist die Schönheit der Weg des Fühlenden zum Geiste, - nur der Weg, ein Mittel nur, kleiner Phaidros...'
      },
      practiceTasks: [
        'Erläutern Sie die platonische Dreieinigkeit von Schönheit, Sinnlichkeit und Geist im Text.',
        'Analysieren Sie Manns Periodenbau: Wie steigert sich die rhythmische Kadenz zum Ende des Abschnitts?'
      ]
    },
    sectionE: {
      title: 'Mussawi E: Grammatik & Schreiben',
      focus: 'Grammatik & Schreiben (Prädikative Gerundiva / das Gerundivum: zu + Partizip I vor dem Nomen)',
      description: {
        en: 'Master the Gerundivum, an aristocratic syntactic structure expressing necessary or possible future actions with utmost density.',
        fa: 'تسلط بر ساختار گروندیو (Gerundivum): صفت فاعلی با zu پیش از اسم برای بیان کارهای ضروری یا قابل انجام در اوج ایجاز ادبی.',
        prs: 'یادگیری گروندیو (Gerundivum): zu + صفت فاعلی در نقش صفت برای کارهایی که باید انجام داده شوند (مانند die zu lösenden Aufgaben).',
        tr: 'Gerundivum yapısı: zu + Partizip I ile kurulan, zorunluluk veya olasılık bildiren en üst düzey sıfat tamlaması.',
        ar: 'إتقان تركيب اسم المفعول المستقبلي (الجرونديفوم): zu + اسم الفاعل للتعبير عن الوجوب أو الإمكان بأعلى درجات الإيجاز.',
        es: 'Dominio del gerundivo pasivo (zu + Partizip I) para denotar necesidad o posibilidad con máxima concisión.'
      },
      content: 'Relativsatz: "Die Aufgaben, die gelöst werden müssen" -> Gerundivum: "Die zu lösenden Aufgaben".',
      grammarRule: {
        id: 'c2_2_gerundivum_rule',
        level: 'C2.2',
        germanTitle: 'Das Gerundivum (zu + Partizip I als attributive Passivalternative)',
        formula: 'Artikel + [Erweiterungen] + zu + Partizip I (dekliniert) + Nomen',
        explanation: {
          en: 'The Gerundivum combines the particle "zu" with Partizip I (infinitive + d + adjective ending). It replaces a passive relative clause containing a modal verb of necessity (müssen / sollen) or possibility (können). It represents the highest syntactic density in written standard German.',
          fa: 'گروندیو از ترکیب "zu" به علاوه Partizip I با پایانه‌های صفتی ساخته می‌شود. این ساختار جایگزین یک جمله موصولی مجهول دارای فعل وجهی (müssen یا können) می‌شود و بالاترین درجه تراکم و فخامت نحوی را در زبان نوشتاری آلمانی ایجاد می‌کند.',
          prs: 'گروندیو با یکجا کردن zu و Partizip I با پسوندهای صفتی ساخته می‌شود و جایگزین جملات مجهول با فعل müssen یا können می‌گردد و نهایت فصاحت و اختصار زیبا در زبان آلمانی است.',
          tr: 'Gerundivum, "zu" edatı ve Partizip I\'in artikel ile isim arasında sıfat olarak kullanılmasıdır. "Yapılması gereken" veya "yapılabilen" anlamını verir.',
          ar: 'الجرونديفوم يدمج بين zu واسم الفاعل كصفة للاسم ويعوض جملة موصولة مبنية للمجهول تعبر عن الوجوب أو الإمكانية.',
          es: 'El gerundivo (zu + Partizip I flexionado) sustituye oraciones pasivas con verbos modales de obligación o posibilidad, aportando una densidad sintáctica insuperable.'
        },
        examples: [
          {
            german: 'Die unverzüglich zu ergreifenden Maßnahmen wurden vom Kabinett beschlossen.',
            formulaBreakdown: 'Die (Art.) + unverzüglich zu ergreifenden (Gerundivum = die unverzüglich ergriffen werden müssen) + Maßnahmen (Nomen).',
            literalTranslation: {
              en: 'The immediately to-be-taken measures were by-the cabinet decided.',
              fa: 'تدابیر باید فوراً اتخاذ شونده توسط هیئت دولت به تصویب رسید.',
              prs: 'اقدامات عاجلی که باید روی دست گرفته شوند، از سوی کابینه حکومت تصویب گردیدند.',
              tr: 'Derhal alınması gereken tedbirler kabine tarafından karara bağlandı.',
              ar: 'أقر مجلس الوزراء الإجراءات التي يتعين اتخاذها على الفور دون تأخير.',
              es: 'El gabinete ministerial aprobó las medidas de inaplazable adopción.'
            },
            fluentTranslation: {
              en: 'The measures that must be implemented without delay were adopted by the cabinet.',
              fa: 'اقدامات فوری و لازمی که اجرای آن‌ها اجتناب‌ناپذیر بود، به تصویب هیئت وزیران رسید.',
              prs: 'تدابیر فوری و لازمی که باید تطبیق گردند، به تصویب اعضای کابینه رسیدند.',
              tr: 'Vakit kaybetmeksizin hayata geçirilmesi icap eden önlemler bakanlar kurulunca kabul edildi.',
              ar: 'صادق مجلس الوزراء على التدابير الواجبة التنفيذ بصورة فورية.',
              es: 'Las medidas de obligada y urgente aplicación fueron ratificadas por el consejo de ministros.'
            }
          },
          {
            german: 'Hierbei handelt es sich um ein kaum zu überschätzendes Risiko für den Frieden.',
            formulaBreakdown: 'um ein (Art.) + kaum zu überschätzendes (Gerundivum = das kaum überschätzt werden kann) + Risiko (Nomen).',
            literalTranslation: {
              en: 'About an scarcely to-be-overestimated risk for the peace.',
              fa: 'پیرامون خطری به سختی قابل دست بالا گرفته شدن برای صلح (خطری فوق‌العاده عظیم که هر چقدر مهم شمرده شود کم است).',
              prs: 'این موضوع یک خطر بی‌اندازه بزرگ برای صلح است که نمی‌توان در اهمیت آن اغراق نمود.',
              tr: 'Bu durum, barış için kesinlikle abartılamayacak (son derece büyük) bir risktir.',
              ar: 'يمثل هذا خطراً على السلام لا يمكن المبالغة في حجم خطورته بأي حال.',
              es: 'Se trata de un riesgo para la paz que difícilmente podría sobrestimarse.'
            },
            fluentTranslation: {
              en: 'This constitutes a risk to peace that can hardly be overstated.',
              fa: 'این مسئله خطری آنچنان عظیم برای صلح به شمار می‌رود که هرگز نمی‌توان در اهمیت و بزرگی آن اغراق کرد.',
              prs: 'این امر خطری بی‌نهایت جدی برای صلح جهانی محسوب می‌شود که اهمیت مهار آن فوق‌العاده بالا است.',
              tr: 'Bu, küresel barış adına küçümsenemeyecek derecede devasa bir tehdittir.',
              ar: 'يشكل هذا تهديداً جسيماً للسلام لا يمكن التهوين من شأنه مطلقاً.',
              es: 'Esto representa una amenaza para la paz cuya gravedad resulta imposible exagerar.'
            }
          }
        ]
      },
      practiceTasks: [
        'Verwandeln Sie den Relativsatz "die Kriterien, die von allen Bewerbern erfüllt werden müssen" in ein Gerundivum.',
        'Bilden Sie einen juristischen Schlusssatz mit "die zu tilgende Schuld".'
      ]
    },
    vocabularies: [
      { id: 'c2_2_v11', word: 'das Gerundivum', article: 'das', plural: 'die Gerundiva', ipa: '/ɡeʁʊnˈdiːvʊm/', translation: { en: 'gerundive (modal passive participle)', fa: 'گروندیو / اسم مفعول وجهی الزام‌آور', prs: 'گروندیو / صفت فاعلی وجهی با zu', tr: 'gerundivum', ar: 'الجرونديفوم / نعت الوجوب المصدري', es: 'gerundivo pasivo' } },
      { id: 'c2_2_v12', word: 'die Laudatio', article: 'die', plural: 'die Laudationes', ipa: '/laʊ̯ˈdaːt͡si̯o/', translation: { en: 'eulogy / speech of honor', fa: 'خطابه ستایش‌آمیز / مدح‌نامه رسمی', prs: 'خطابه تقدیر و ستایش رسمی', tr: 'övgü konuşması / laudatio', ar: 'خطاب الثناء والتكريم الرسمي', es: 'panegírico / discurso laudatorio' } },
      { id: 'c2_2_v13', word: 'die Polysemie', article: 'die', plural: 'die Polysemien', ipa: '/polyzeˈmiː/', translation: { en: 'polysemy (multiple meanings)', fa: 'چندمعنایی واژگانی', prs: 'چندمعنایی کلمات', tr: 'çokanlamlılık', ar: 'المشترك اللفظي / تعدد المعاني', es: 'polisemia' } },
      { id: 'c2_2_v14', word: 'der Chiasmus', article: 'der', plural: 'die Chiasmen', ipa: '/çiˈasmʊs/', translation: { en: 'chiasmus (cross-inversion of clauses)', fa: 'صنعت قلب و عکس / تقاطع ساختاری کلام', prs: 'صنعت عکس و تقاطع کلمات در جمله', tr: 'çaprazlama / kiazmus', ar: 'المقابلة العكسية في البلاغة', es: 'quiasmo' } },
      { id: 'c2_2_v15', word: 'das Euphemismus', article: 'das', plural: 'die Euphemismen', ipa: '/ɔɪ̯feˈmɪsmʊs/', translation: { en: 'euphemism', fa: 'حسن تعبیر / بهگویی', prs: 'حسن تعبیر / کلام ملایم به جای تند', tr: 'güzeladlandırma / örtmece', ar: 'حسن التعبير / التلطيف اللفظي', es: 'eufemismo' } }
    ],
    videoClip: {
      title: 'Die Festrede: Kulturpreisverleihung und Laudatio',
      scenario: 'Eine renommierte Literaturkritikerin hält im Festspielhaus eine virtuose Laudatio zur Verleihung des Georg-Büchner-Preises.',
      category: 'interview',
      duration: '03:15',
      speakers: ['Laudatorin', 'Preisträger'],
      keyPhrases: [
        'Die zu würdigenden Verdienste des Preisträgers sind unermesslich.',
        'Ein virtuoser Stil zeichnet die zu meisternden Passagen aus.',
        'In den zu lesenden Zeilen spiegelt sich die Epoche.'
      ],
      germanTranscript: [
        'Laudatorin: Sehr geehrte Festgäste, die heute zu feiernden literarischen Schöpfungen unseres Preisträgers verlangen nach höchstem Respekt.',
        'Preisträger: Ich danke der Deutschen Akademie für Sprache und Dichtung für diese unverhoffte Ehrung.',
        'Laudatorin: In seinen Werken sind die zu bewältigenden existentiellen Krisen mit unnachahmlicher stilistischer Prägnanz verdichtet.',
        'Preisträger: Das Schreiben ist ein unablässiges Ringen um die adäquate Formulierung der nie ganz zu erfassenden Wahrheit.',
        'Laudatorin: Und genau diese unbestechliche poetische Wahrhaftigkeit ist es, die heute mit dem Büchner-Preis ausgezeichnet wird.'
      ],
      translatedTranscript: [
        {
          en: 'Eulogist: Distinguished guests, the literary creations of our laureate to be celebrated today command the utmost respect.',
          fa: 'خطیب مدح: میهمانان ارجمند، آفرینش‌های ادبی شایسته تجلیل برگزیده امروز ما مستلزم بالاترین احترام است.',
          prs: 'سخنران مراسم تقدیر: مهمانان عالی‌قدر، شاهکارهای ادبی که امروز مورد ستایش قرار می‌گیرند مستحق عالی‌ترین احترام و تحسین می‌باشند.',
          tr: 'Övgü Konuşmacısı: Saygıdeğer davetliler, bugün ödüllendirilen yazarımızın kutlanmaya layık edebi yaratımları en derin saygıyı hak etmektedir.',
          ar: 'صاحبة الثناء: ضيوفنا الكرام، إن الإبداعات الأدبية الجديرة بالاحتفاء لكاتبنا الفائز اليوم تفرض أسمى درجات التقدير والاحترام.',
          es: 'Laudadora: Distinguidos invitados, las creaciones literarias que hoy celebramos de nuestro premiado reclaman el más hondo respeto.'
        },
        {
          en: 'Laureate: I thank the German Academy for Language and Literature for this unexpected honor.',
          fa: 'برنده جایزه: از فرهنگستان زبان و شعر آلمان برای این افتخار نامنتظره بی‌نهایت سپاسگزارم.',
          prs: 'برنده جایزه: از اکادمی زبان و ادبیات آلمان به خاطر این افتخار بزرگ و نامنتظره قلباً سپاسگزاری می‌نمایم.',
          tr: 'Ödül Sahibi: Bu beklenmedik onur için Alman Dil ve Şiir Akademisi\'ne en içten şükranlarımı sunarım.',
          ar: 'الفائز بالجائزة: أتقدم بجزيل الشكر للأكاديمية الألمانية للغة والشعر على هذا التكريم البهيج غير المتوقع.',
          es: 'Galardonado: Agradezco a la Academia Alemana de la Lengua y la Poesía este inesperado honor.'
        },
        {
          en: 'Eulogist: In his works, the existential crises to be surmounted are condensed with inimitable stylistic precision.',
          fa: 'خطیب مدح: در آثار او بحران‌های وجودی لازم برای چیرگی با دقت سبک‌شناختی بی‌نظیری فشرده شده‌اند.',
          prs: 'سخنران تقدیر: در آثار این نویسنده، بحران‌های اگزیستانسیل زندگی با فصاحت و بلاغت کم‌نظیر ادبی بازتاب یافته‌اند.',
          tr: 'Övgü Konuşmacısı: Eserlerinde üstesinden gelinmesi gereken varoluşsal krizler taklit edilemez bir üslup titizliğiyle damıtılmıştır.',
          ar: 'صاحبة الثناء: تتكثف في أعماله الأزمات الوجودية الواجب التغلب عليها بإيجاز أسلوبي بديع لا يُضاهى.',
          es: 'Laudadora: En sus obras, las crisis existenciales que han de superarse se condensan con una precisión estilística inimitable.'
        },
        {
          en: 'Laureate: Writing is an incessant struggle for the adequate phrasing of the truth that can never be fully grasped.',
          fa: 'برنده جایزه: نوشتن تلاشی مداوم برای یافتن بیان متناسب حقیقتی است که هرگز کاملاً صید نمی‌شود.',
          prs: 'برنده جایزه: نویسندگی عبارت از یک مبارزه بی‌وقفه برای بیان کلمات شایسته‌ای است که حقیقت بی‌پایان را بازگو کنند.',
          tr: 'Ödül Sahibi: Yazmak, hiçbir zaman bütünüyle kavranamayacak hakikati layıkıyla ifade edebilmek için verilen aralıksız bir mücadeledir.',
          ar: 'الفائز بالجائزة: الكتابة هي كفاح مستمر من أجل التعبير الأمثل عن الحقيقة التي لا يمكن إدراكها كلياً.',
          es: 'Galardonado: Escribir es una lucha incesante por encontrar la expresión cabal de la verdad inaprensible.'
        },
        {
          en: 'Eulogist: And it is precisely this incorruptible poetic veracity that is honored today with the Büchner Prize.',
          fa: 'خطیب مدح: و دقیقاً همین حقیقت‌گویی زلال شاعرانه است که امروز با جایزه بوشنر تجلیل می‌شود.',
          prs: 'سخنران تقدیر: و دقیقاً همین حقیقت‌گویی ادبی فسادناپذیر است که امروز با اهدای جایزه گئورگ بوشنر ارج گذاشته می‌شود.',
          tr: 'Övgü Konuşmacısı: Ve bugün Büchner Ödülü ile taçlandırılan tam da bu tavizsiz şairane doğruluktur.',
          ar: 'صاحبة الثناء: وهذا الصدق الشعري النزيه بالتحديد هو ما يُتوّج اليوم بجائزة غيورغ بوشنر المرموقة.',
          es: 'Laudadora: Y es precisamente esa incorruptible veracidad poética la que hoy se corona con el Premio Büchner.'
        }
      ]
    },
    examTip: {
      standard: 'C2 (Goethe-Zertifikat C2: GDS)',
      module: 'Gesamtexamen (GDS Prädikat "Sehr Gut")',
      tip: {
        en: 'To obtain the highest distinction ("Sehr gut") on the Goethe C2 exam, actively showcase Gerundivum structures ("die zu treffenden Entscheidungen") in both your essay and the literary oral discussion. This marks the boundary between mere fluency and native intellectual excellence.',
        fa: 'برای کسب رتبه عالی (Sehr gut) در آزمون C2 گوته، حتماً ساختارهای Gerundivum (مانند die zu treffenden Entscheidungen) را در نگارش مقاله و مصاحبه ادبی به کار ببرید. این کار تسلط شما را هم‌سطح فرهیختگان بومی آلمانی نشان می‌دهد.',
        prs: 'برای به دست آوردن نمره عالی (Sehr Gut) در بالاترین دیپلوم زبان آلمانی گوته (C2)، استعمال ساختارهای Gerundivum در بخش مقاله و صحبت نشان‌دهنده کمال فصاحت شما در حد عالی‌ترین نویسندگان آلمانی است.',
        tr: 'Goethe C2 sınavında "Sehr gut" derecesi almak için hem kompozisyonda hem de sözlüde Gerundivum yapılarını ustaca kullanın.',
        ar: 'للحصول على درجة "ممتاز" في اختبار Goethe C2، وظّف تراكيب الجرونديفوم في مقالك ونقاشك الشفوي لإثبات البلاغة الأكاديمية.',
        es: 'Para alcanzar la calificación de "Sobresaliente" en el C2 del Goethe-Institut, exhibe construcciones de gerundivo en tu expresión escrita y oral.'
      }
    }
  }
];
