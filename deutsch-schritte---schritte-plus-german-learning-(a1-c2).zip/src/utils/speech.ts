// Audio synthesis engine using High German (Hochdeutsch) Web Speech API & Web Audio fallback
// Features pleasant, warm, melodic natural voices and automatic gender-aware dual-voice dialogue support

let currentUtterance: SpeechSynthesisUtterance | null = null;
let speechSafetyTimer: ReturnType<typeof setTimeout> | null = null;
let cachedVoices: SpeechSynthesisVoice[] = [];
let preferredGender: 'female' | 'male' = 'female';
let explicitlySelectedVoice: SpeechSynthesisVoice | null = null;

// Female voice name patterns across macOS, iOS, Windows, Android, Linux, Chrome
const FEMALE_VOICE_REGEX = /marlene|anna|petra|katja|hedda|helena|amelie|vicki|sara|claudia|eva|gudrun|steffi|katrin|zira|samantha|yolanda|sabina|karin|victoria|female|weiblich|woman|frau|natural.*female|female.*natural|de-de-x-deb|de-de-x-dea|de-de-x-ded|de-de-x-gfb/i;
// Male voice name patterns
const MALE_VOICE_REGEX = /stefan|markus|hans|klaus|dieter|yannick|conrad|male|männlich|martin|frank|jörg|michael|paul|thomas|male.*natural|natural.*male|de-de-x-deg|de-de-x-def|de-de-x-dee|de-de-x-gfa/i;
// High quality / Neural / Natural voice indicators
const NATURAL_VOICE_REGEX = /natural|neural|online|enhanced|premium|google|apple|siri|wavenet/i;

// Initialize voices cache
if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
  const loadVoices = () => {
    try {
      cachedVoices = window.speechSynthesis.getVoices();
    } catch (e) {
      console.warn('Could not load speech voices:', e);
    }
  };
  loadVoices();
  if (window.speechSynthesis.onvoiceschanged !== undefined) {
    window.speechSynthesis.onvoiceschanged = loadVoices;
  }
}

/**
 * Returns all available German voices on the system.
 */
export const getAvailableGermanVoices = (): SpeechSynthesisVoice[] => {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) return [];
  const voices = cachedVoices.length > 0 ? cachedVoices : window.speechSynthesis.getVoices();
  return voices.filter(v => v.lang.toLowerCase().startsWith('de') || v.lang.toLowerCase().includes('de-'));
};

/**
 * Finds the optimal voice for a specific gender, prioritizing pleasant, natural, high-definition neural voices.
 */
export const getBestGermanVoiceByGender = (gender: 'female' | 'male'): SpeechSynthesisVoice | null => {
  if (explicitlySelectedVoice && preferredGender === gender) {
    return explicitlySelectedVoice;
  }

  const germanVoices = getAvailableGermanVoices();
  if (germanVoices.length === 0) {
    const allVoices = cachedVoices.length > 0 ? cachedVoices : (typeof window !== 'undefined' && 'speechSynthesis' in window ? window.speechSynthesis.getVoices() : []);
    if (gender === 'female') {
      return allVoices.find(v => FEMALE_VOICE_REGEX.test(v.name)) || allVoices[0] || null;
    } else {
      return allVoices.find(v => MALE_VOICE_REGEX.test(v.name)) || allVoices[0] || null;
    }
  }

  if (gender === 'female') {
    // 1. Natural/Enhanced female German voice (e.g. Google Deutsch Female, Microsoft Katja Online (Natural), Apple Anna Enhanced)
    const naturalFemale = germanVoices.find(v => 
      FEMALE_VOICE_REGEX.test(v.name) && 
      NATURAL_VOICE_REGEX.test(v.name) && 
      !MALE_VOICE_REGEX.test(v.name)
    );
    if (naturalFemale) return naturalFemale;

    // 2. Any explicit female German voice
    const explicitFemale = germanVoices.find(v => FEMALE_VOICE_REGEX.test(v.name) && !MALE_VOICE_REGEX.test(v.name));
    if (explicitFemale) return explicitFemale;

    // 3. Any non-male German voice
    const nonMale = germanVoices.find(v => !MALE_VOICE_REGEX.test(v.name));
    if (nonMale) return nonMale;

    return germanVoices[0] || null;
  } else {
    // Male Voice
    // 1. Natural/Enhanced male German voice (e.g. Microsoft Conrad Online (Natural), Google Deutsch Male, Apple Markus Enhanced)
    const naturalMale = germanVoices.find(v => 
      MALE_VOICE_REGEX.test(v.name) && 
      NATURAL_VOICE_REGEX.test(v.name)
    );
    if (naturalMale) return naturalMale;

    // 2. Explicit male German voice
    const explicitMale = germanVoices.find(v => MALE_VOICE_REGEX.test(v.name));
    if (explicitMale) return explicitMale;

    // 3. Secondary German voice if available
    if (germanVoices.length > 1) {
      return germanVoices[1];
    }
    return germanVoices[0] || null;
  }
};

/**
 * Finds the optimal voice, respecting user preferred gender
 */
export const getBestGermanVoice = (): SpeechSynthesisVoice | null => {
  return getBestGermanVoiceByGender(preferredGender);
};

export const setVoiceGenderPreference = (gender: 'female' | 'male') => {
  preferredGender = gender;
};

export const getVoiceGenderPreference = (): 'female' | 'male' => {
  return preferredGender;
};

export const setSelectedVoice = (voice: SpeechSynthesisVoice | null) => {
  explicitlySelectedVoice = voice;
};

/**
 * Detects whether a speaker in a German dialogue is female or male
 * based on German titles, honorifics, feminine endings (-in, -innen), names, and roles.
 */
const FEMALE_TITLES_AND_ENDINGS = /\b(frau|fr\.|fräulein|dame|mutter|mama|tochter|schwester|oma|grossmutter|großmutter|tante|freundin|partnerin|chefin|leiterin|kollegin|lehrerin|dozentin|schülerin|studentin|ärztin|patientin|kundin|verkäuferin|kellnerin|arzthelferin|assistentin|beraterin|bürgermeisterin|präsidentin|richterin|moderatorin|laudatorin|zugbegleiterin|passantin|vorsitzende|redakteurin|korrespondentin|spezialistin|vermieterin|mieterin|hausverwalterin|preisträgerin|mitarbeiterin|expertin|teilnehmerin|nachbarin|apothekerin|sekretärin|trainerin|fahrerin)\b/i;

const FEMALE_NAMES = /\b(anna|maria|maryam|zahra|samira|sarah|sara|elena|susanne|petra|lena|sabine|lisa|lili|julia|laura|emma|mia|sofia|sophie|katharina|christine|monika|claudia|barbara|eva|steffi|katrin|lara|fatima|niloufar|yasmin|layla|beate|nadia|karin|ursula|mona|simone|melanie|birgit|nicole|heike|tanja|angelika|ingrid|marion|karoline|frieda|greta|annegret|hildegard|chen|sommer|schultze|demir|rahimi|al-mansur|al-mansoor|rostova|klein)\b/i;

const MALE_TITLES = /\b(herr|herrn|hr\.|mann|vater|papa|sohn|bruder|opa|grossvater|großvater|onkel|junge|freund|partner|chef|leiter|kollege|lehrer|dozent|schüler|student|arzt|patient|kunde|verkäufer|kellner|arzthelfer|assistent|berater|bürgermeister|präsident|richter|moderator|laudator|zugbegleiter|passant|vorsitzender|redakteur|korrespondent|spezialist|vermieter|mieter|hausverwalter|fitnesstrainer|trainer|bankberater|ingenieur|polizist|fahrer|gast|reisender|reisende|mitarbeiter|experte|teilnehmer|nachbar|apotheker|sekretär)\b/i;

const MALE_NAMES = /\b(sayed|bashir|lukas|thomas|sami|jonas|marc|markus|ahmad|david|ali|reza|kenan|soran|mohammad|stefan|jan|michael|andreas|peter|klaus|hans|frank|christian|martin|max|felix|leon|daniel|paul|oliver|moritz|florian|alex|sebastian|tobias|werner|wolfgang|paco|walter|tim|hasan|jörg|dieter|heinz|günter|jürgen|manfred|uwe|bernd|herbert|ralf|carsten|jens|dirk|becker|weber|wagner|schmidt|meyer|fischer|karimi|yilmaz|schneider|bergmann|franke|hartmann|radbruch|weizsäcker|gadamer|berger|lindner|nematullah|özdemir|krause)\b/i;

export const detectSpeakerGender = (speakerName: string, fallbackIndex: number = 0): 'female' | 'male' => {
  if (!speakerName) {
    return fallbackIndex % 2 === 0 ? 'male' : 'female';
  }

  const cleanName = speakerName.trim();

  // 1. Explicit female check (titles, feminine occupational endings, names)
  const hasFemaleTitle = FEMALE_TITLES_AND_ENDINGS.test(cleanName);
  const hasFemaleName = FEMALE_NAMES.test(cleanName);
  // In German, noun suffixes ending with 'in' (e.g. Kundin, Patientin, Ärztin) indicate female
  const hasFeminineSuffix = /(in|innen)\b/i.test(cleanName) && !/\b(martin|erwin|benjamin|kevin|robin|colin|justin)\b/i.test(cleanName);

  // 2. Explicit male check
  const hasMaleTitle = MALE_TITLES.test(cleanName);
  const hasMaleName = MALE_NAMES.test(cleanName);

  if ((hasFemaleTitle || hasFemaleName || hasFeminineSuffix) && !hasMaleTitle) {
    return 'female';
  }

  if (hasMaleTitle || hasMaleName) {
    return 'male';
  }

  // Handle generic labels like "Person A" vs "Person B", "Sprecher 1" vs "Sprecher 2"
  if (/(\bA\b|\b1\b|erste)/i.test(cleanName)) {
    return 'female';
  }
  if (/(\bB\b|\b2\b|zweite)/i.test(cleanName)) {
    return 'male';
  }

  // Fallback: alternate based on index to ensure 2 distinct voices in a dialogue
  return fallbackIndex % 2 === 0 ? 'male' : 'female';
};

// Gentle, melodic acoustic chime using Web Audio API to create a pleasant, warm listening experience
export const playAcousticCue = (frequency: number = 523.25, durationMs: number = 90) => {
  try {
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioContextClass) return;
    const ctx = new AudioContextClass();
    
    // Create dual-tone soft chime (C5 + E5 harmonic for warm musicality)
    const osc1 = ctx.createOscillator();
    const osc2 = ctx.createOscillator();
    const gain = ctx.createGain();

    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(frequency, ctx.currentTime);

    osc2.type = 'sine';
    osc2.frequency.setValueAtTime(frequency * 1.25, ctx.currentTime); // major third harmonic

    gain.gain.setValueAtTime(0.018, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + durationMs / 1000);

    osc1.connect(gain);
    osc2.connect(gain);
    gain.connect(ctx.destination);

    osc1.start();
    osc2.start();
    osc1.stop(ctx.currentTime + durationMs / 1000);
    osc2.stop(ctx.currentTime + durationMs / 1000);
  } catch (e) {
    // AudioContext might be blocked until user interacts
  }
};

/**
 * Pre-processes text for natural, human-like speech pacing with natural breath pauses
 */
const prepareNaturalSpeechText = (rawText: string): string => {
  return rawText
    .replace(/[*_~`#]/g, '')
    // Clean brackets
    .replace(/\[.*?\]/g, '')
    // Expand slashes with spaces for clear pronunciation
    .replace(/\s*\/\s*/g, ' oder ')
    // Ensure commas have slight spacing
    .replace(/,/g, ', ')
    .replace(/\s+/g, ' ')
    .trim();
};

/**
 * Plays German text using a specific gender voice and optimized pitch/timbre for natural, pleasant sound.
 */
export const playHighGermanAudioWithGender = (
  text: string,
  gender: 'female' | 'male',
  rate: number = 0.9,
  onEnd?: () => void,
  onBoundary?: (charIndex: number) => void,
  pitchOffset: number = 0
) => {
  // Clear any existing safety timer
  if (speechSafetyTimer) {
    clearTimeout(speechSafetyTimer);
    speechSafetyTimer = null;
  }

  let endCalled = false;
  const safeEnd = () => {
    if (speechSafetyTimer) {
      clearTimeout(speechSafetyTimer);
      speechSafetyTimer = null;
    }
    if (!endCalled) {
      endCalled = true;
      currentUtterance = null;
      if (onEnd) onEnd();
    }
  };

  // Play subtle, warm acoustic chime
  playAcousticCue(gender === 'female' ? 587.33 : 440.0, 60);

  if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
    console.warn('SpeechSynthesis is not supported in this browser environment.');
    safeEnd();
    return;
  }

  try {
    window.speechSynthesis.cancel();
    if (window.speechSynthesis.paused) {
      window.speechSynthesis.resume();
    }

    const cleanText = prepareNaturalSpeechText(text);
    if (!cleanText) {
      safeEnd();
      return;
    }

    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.lang = 'de-DE';
    
    // Natural, pleasant speech rate: gently paced for learners
    const baseRate = Math.max(0.65, Math.min(1.3, rate * 0.94));
    utterance.rate = gender === 'female' ? baseRate * 1.01 : baseRate * 0.95;

    // Pick best voice for the chosen gender
    const voice = getBestGermanVoiceByGender(gender);
    if (voice) {
      utterance.voice = voice;
    }

    // Melodic, warm pitch tuning:
    // Female: pleasant, clear German didactic tone (~1.22 - 1.28)
    // Male: deep, resonant, calm baritone (~0.76 - 0.84)
    const otherVoice = getBestGermanVoiceByGender(gender === 'female' ? 'male' : 'female');
    const isSharedVoice = !voice || !otherVoice || voice.name === otherVoice.name;

    if (gender === 'female') {
      const basePitch = isSharedVoice ? 1.24 : 1.15;
      utterance.pitch = Math.min(1.5, Math.max(1.0, basePitch + pitchOffset));
    } else {
      const basePitch = isSharedVoice ? 0.78 : 0.84;
      utterance.pitch = Math.max(0.5, Math.min(0.95, basePitch + pitchOffset));
    }
    utterance.volume = 1.0;

    utterance.onend = () => {
      safeEnd();
    };

    utterance.onerror = (e) => {
      console.warn('Speech synthesis notice:', e);
      safeEnd();
    };

    if (onBoundary) {
      utterance.onboundary = (event) => {
        if (event.name === 'word') {
          onBoundary(event.charIndex);
        }
      };
    }

    // Dynamic safety timeout with buffer
    const estimatedMs = Math.max(2000, (cleanText.length * 85) / baseRate);
    speechSafetyTimer = setTimeout(() => {
      safeEnd();
    }, estimatedMs + 1800);

    currentUtterance = utterance;
    (window as unknown as { __speechUtterance?: SpeechSynthesisUtterance }).__speechUtterance = utterance;

    window.speechSynthesis.speak(utterance);
  } catch (err) {
    console.error('Error starting speech synthesis:', err);
    safeEnd();
  }
};

/**
 * Standard German playback respecting user preferred voice gender
 */
export const playHighGermanAudio = (
  text: string, 
  rate: number = 0.9, 
  onEnd?: () => void,
  onBoundary?: (charIndex: number) => void
) => {
  playHighGermanAudioWithGender(text, preferredGender, rate, onEnd, onBoundary);
};

/**
 * Dedicated Dialogue Turn player that automatically detects speaker gender
 * and applies the appropriate female or male natural voice.
 */
export const playDialogueTurn = (
  speaker: string,
  text: string,
  rate: number = 0.9,
  onEnd?: () => void,
  fallbackIndex: number = 0
) => {
  const gender = detectSpeakerGender(speaker, fallbackIndex);
  // Differentiate pitch slightly if two of the same gender speak sequentially
  const subtleOffset = (fallbackIndex % 2 === 1) ? 0.05 : -0.03;
  playHighGermanAudioWithGender(text, gender, rate, onEnd, undefined, subtleOffset);
};

export const stopGermanAudio = () => {
  if (speechSafetyTimer) {
    clearTimeout(speechSafetyTimer);
    speechSafetyTimer = null;
  }
  if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
    try {
      window.speechSynthesis.cancel();
    } catch (e) {
      // ignore
    }
    currentUtterance = null;
  }
};

export const stopSpeech = stopGermanAudio;

export const isAudioSpeaking = () => {
  if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
    return window.speechSynthesis.speaking;
  }
  return false;
};


